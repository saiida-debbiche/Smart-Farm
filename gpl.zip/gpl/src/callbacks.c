#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "plantation.h"

int x;
int y;
int z;
void
on_button_afflplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview1;
    GtkWidget *window1;

window1=lookup_widget(objet,"gpl");
treeview1=lookup_widget(objet,"treeview_lplv");

afficher(treeview1);
}


void
on_button_ajplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window2;
    window1=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window1);
    window2=create_ajplv();
    gtk_widget_show(window2);
}


void
on_button_mdfplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window3;
    window3=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window3);
    window1=create_mdfplv();
    gtk_widget_show(window1);
}


void
on_button_spplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *windowsp;
    window1=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window1);
    windowsp=create_spplv();
    gtk_widget_show(windowsp);
}


void
on_button_rechplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window2;
    window1=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window1);
    window2=create_rechplv();
    gtk_widget_show(window2);
}


void
on_button_retplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_treeview_lplv_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* type;
	gchar* quantite;
	gchar* jour_pl;
        gchar* mois_pl;
        gchar* annee_pl;
	gchar* jour_ir;
        gchar* mois_ir;
        gchar* annee_ir;
	gchar* temperature;
	gchar* humidite;
	gchar* zone;
	plantation n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &type , 3, &quantite , 4, &jour_pl, 5, &mois_pl, 6, &annee_pl , 7, &jour_ir , 8, &mois_ir , 9, &annee_ir , 10, &temperature, 11, &humidite , 12, &zone ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.type,type);
                strcpy(n.quantite,quantite);
                n.date_plantation.jour=jour_pl;
                n.date_plantation.mois=mois_pl;
                n.date_plantation.annee=annee_pl;
                n.date_irrigation.jour=jour_ir;
                n.date_irrigation.mois=mois_ir;
                n.date_irrigation.annee=annee_ir;
		strcpy(n.temperature,temperature);
                strcpy(n.humidite,humidite);
                strcpy(n.zone,zone);


                
                afficher(treeview);
}
}


void
on_checkbutton_sdzaaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=1;
}
}


void
on_checkbutton_sdzbaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=2;
}
}


void
on_checkbutton_sdzcaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=3;
}
}


void
on_checkbutton_sdzdaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=4;
}
}


void
on_button_sdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  plantation n;

  GtkWidget *window3;
  GtkWidget *window1;
  GtkWidget *input1, *input2, *input3, *input4, *input5;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *jir,*mir,*air;
  GtkWidget *type;

window3=lookup_widget(objet,"mdfplv");
input1=lookup_widget(objet,"combobox_sdidmdf");
input2=lookup_widget(objet,"entry_sdnommdf");
type=lookup_widget(objet,"combobox_sdtpmdf");
input3=lookup_widget(objet,"entry_sdqnmdf");
jour=lookup_widget(objet,"spinbutton_sdjdpmdf");
mois=lookup_widget(objet,"spinbutton_sdmdpmdf");
annee=lookup_widget(objet,"spinbutton_sdadpmdf");
jir=lookup_widget(objet,"spinbutton_sdjdimdf");
mir=lookup_widget(objet,"spinbutton_sdmdimdf");
air=lookup_widget(objet,"spinbutton_sdadimdf");
input4=lookup_widget(objet,"entry_sdtmmdf");
input5=lookup_widget(objet,"entry_sdhmmdf");
strcpy(n.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));
n.date_plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_plantation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
n.date_irrigation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jir));
n.date_irrigation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mir));
n.date_irrigation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(air));
strcpy(n.temperature,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.humidite,gtk_entry_get_text(GTK_ENTRY(input5)));
if(y==1)
{strcpy(n.zone,"zone-A");}
else
if(y==2)
{strcpy(n.zone,"zone-B");}
else
if(y==3)
{strcpy(n.zone,"zone-C");}
else
if(y==3)
{strcpy(n.zone,"zone-D");}

modifier(n);

    gtk_widget_destroy(window3);
    window1=create_scspplv();
    gtk_widget_show(window1);
}


void
on_button_sdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    window4=lookup_widget(objet,"mdfplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);

}


void
on_button_sdvlchid_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  plantation n;
  FILE *f;
  GtkWidget *window3;
  GtkWidget *id;
  GtkWidget *input2, *input3, *input4, *input5;
  GtkWidget *output1,*output2;
    char nom1[20];
    char quantite1[20];
    char temperature1[20];
    char humidite1[20];
    char id1[20];
  

window3=lookup_widget(objet,"mdfplv");
id=lookup_widget(objet,"combobox_sdidmdf");
input2=lookup_widget(objet,"entry_sdnommdf");
input3=lookup_widget(objet,"entry_sdqnmdf");
input4=lookup_widget(objet,"entry_sdtmmdf");
input5=lookup_widget(objet,"entry_sdhmmdf");
output1=lookup_widget(objet,"label_sdmsgchid");
output2=lookup_widget(objet,"label_sdanlchid");

strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("plantation.txt","r");
while (fscanf(f,"%s %s %s %s %d %d %d  %d %d %d %s %s %s \n",n.identifiant,n.nom,n.type,n.quantite,&n.date_plantation.jour,&n.date_plantation.mois,&n.date_plantation.annee,&n.date_irrigation.jour,&n.date_irrigation.mois,&n.date_irrigation.annee,n.temperature,n.humidite,n.zone)!=EOF)
{
if(strcmp(n.identifiant,id1)==0)
{ 
strcpy(nom1,n.nom);
strcpy(quantite1,n.quantite);
strcpy(temperature1,n.temperature);
strcpy(humidite1,n.humidite);
}
}
fclose(f);

gtk_entry_set_text(input2,nom1);
gtk_entry_set_text(input3,quantite1);
gtk_entry_set_text(input4,temperature1);
gtk_entry_set_text(input5,humidite1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);

}


void
on_button_sdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
  plantation n;
  FILE *f;
  GtkWidget *window3;
  GtkWidget *id;
  GtkWidget *output1,*output2;
  

window3=lookup_widget(objet,"mdfplv");
id=lookup_widget(objet,"combobox_sdidmdf");
output1=lookup_widget(objet,"label_sdmsgchid");
output2=lookup_widget(objet,"label_sdanlchid");

f=fopen("plantation.txt","r");
while (fscanf(f,"%s %s %s %s %d %d %d  %d %d %d %s %s %s \n",n.identifiant,n.nom,n.type,n.quantite,&n.date_plantation.jour,&n.date_plantation.mois,&n.date_plantation.annee,&n.date_irrigation.jour,&n.date_irrigation.mois,&n.date_irrigation.annee,n.temperature,n.humidite,n.zone)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(n.identifiant));
}

fclose(f);

gtk_widget_hide(output2);
gtk_widget_show (output1);
}


void
on_radiobutton_sdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *window4;
   GtkWidget *output1,*output2,*output3;

window4=lookup_widget(objet,"spplv");
output1=lookup_widget(objet,"label_sdmsgsp");
z=0;

gtk_widget_hide(output1);
}


void
on_radiobutton_sdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window4;
   GtkWidget *output1;

window4=lookup_widget(objet,"spplv");
output1=lookup_widget(objet,"label_sdmsgsp");
z=1;

   gtk_widget_show (output1);

}


void
on_button_sdcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *window4;
   GtkWidget *window1;
   GtkWidget *id;
   GtkWidget *output1,*output2;
   char idsup[20];
   int t;
id=lookup_widget(objet,"entry_sdidsp");
output1=lookup_widget(objet,"label_sdmsgsp");
output2=lookup_widget(objet,"label_sdaltsp");
strcpy(idsup,gtk_entry_get_text(GTK_ENTRY(id)));
t=verif(idsup);
if(t!=1)
{
    gtk_widget_show (output2);
}
else
{
if(z==1)
{
supprimer(idsup);
    gtk_widget_destroy(window4);
    window1=create_scspplv();
    gtk_widget_show(window1);
}


}

}


void
on_button_sdanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    window4=lookup_widget(objet,"spplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
}


void
on_button_sdidrech_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *window1;
   GtkWidget *id,*output1,*output2,*crt;
   GtkWidget *treeview_rechplv;
   char filtre[20];
   char critere[30];
   int t;

window1=lookup_widget(objet,"rechplv");
id=lookup_widget(objet,"entry_sdidrech");
output1=lookup_widget(objet,"label_sdrsrech");
output2=lookup_widget(objet,"labelsdr57");
treeview_rechplv=lookup_widget(objet,"treeview_rechplv");
crt=lookup_widget(objet,"combobox_sdcrrech");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

t=verifrech(filtre);
if(t!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
filtrecritere(treeview_rechplv, critere, filtre);
}
}


void
on_button_okajplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    GtkWidget *treeview_lplv;
    window4=lookup_widget(objet,"scajplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
treeview_lplv=lookup_widget(window1,"treeview_lplv");

afficher(treeview_lplv);
}


void
on_button_okmdfplv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    GtkWidget *treeview_lplv;
    window4=lookup_widget(objet,"scmdfplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
treeview_lplv=lookup_widget(window1,"treeview_lplv");

afficher(treeview_lplv);
}


void
on_button_okspplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    GtkWidget *treeview_lplv;
    window4=lookup_widget(objet,"scspplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
treeview_lplv=lookup_widget(window1,"treeview_lplv");

afficher(treeview_lplv);
}


void
on_checkbutton_sdzamdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=1;
}
}


void
on_checkbutton_sdzbmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=2;
}
}


void
on_checkbutton_sdzcmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=3;
}
}


void
on_checkbutton_sdzdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=4;
}
}


void
on_button_sdanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window2;
    window2=lookup_widget(objet,"ajplv");
    gtk_widget_destroy(window2);
    window1=create_gpl();
    gtk_widget_show(window1);
}


void
on_button_sdcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
 plantation n;

  GtkWidget *window2;
  GtkWidget *window1;
  GtkWidget *input1, *input2, *input3, *input5, *input6;
  GtkWidget *output1, *output2, *output4, *output5, *output6;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *jir,*mir,*air;
  GtkWidget *type;
  char id[20];
  int b=1,v;

  window2=lookup_widget(objet,"ajplv");
  input1=lookup_widget(objet,"entry_sdidaj");
  input2=lookup_widget(objet,"entry_sdnomaj");
  type=lookup_widget(objet,"combobox_sdtpaj");
  input3=lookup_widget(objet,"entry_sdqnaj");
  jour=lookup_widget(objet,"spinbutton_sdjdpaj");
  mois=lookup_widget(objet,"spinbutton_sdmdpaj");
  annee=lookup_widget(objet,"spinbutton_sdadpaj");
  jir=lookup_widget(objet,"spinbutton_sdjdiaj");
  mir=lookup_widget(objet,"spinbutton_sdmdiaj");
  air=lookup_widget(objet,"spinbutton_sdadiaj");
  input5=lookup_widget(objet,"entry_sdtmaj");
  input6=lookup_widget(objet,"entry_sdhmaj");
output1=lookup_widget(objet,"label_sdsnomaj");
output2=lookup_widget(objet,"label_sdsqnaj");
output4=lookup_widget(objet,"label_sdstmaj");
output5=lookup_widget(objet,"label_sdshmaj");
output6=lookup_widget(objet,"label_sdaltaj");

strcpy(n.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
if(strcmp(n.nom,"")==0)
{
gtk_widget_show (output1);
b=0;
}
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));

if(strcmp(n.quantite,"")==0)
{
gtk_widget_show (output2);
b=0;
}

n.date_plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_plantation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
n.date_irrigation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jir));
n.date_irrigation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mir));
n.date_irrigation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(air));

strcpy(n.temperature,gtk_entry_get_text(GTK_ENTRY(input5)));
if(strcmp(n.temperature,"")==0)
{
gtk_widget_show (output4);
b=0;
}

strcpy(n.humidite,gtk_entry_get_text(GTK_ENTRY(input6)));
if(strcmp(n.humidite,"")==0)
{
gtk_widget_show (output5);
b=0;
}

if(x==1)
{strcpy(n.zone,"zone-A");}
else
if(x==2)
{strcpy(n.zone,"zone-B");}
else
if(x==3)
{strcpy(n.zone,"zone-C");}
else
if(x==4)
{strcpy(n.zone,"zone-D");}


v=verif(id);


if (v==1)
{
gtk_widget_show (output6);
}
else
{
  if(b==1)
{
ajouter(n);

    gtk_widget_destroy(window2);
    window1=create_scajplv();
    gtk_widget_show(window1);

}
}

}


void
on_button_sdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *window3;
  GtkWidget *output1,*output2;
output1=lookup_widget(objet,"label_sdmsgchid");
output2=lookup_widget(objet,"label_sdanlchid");

gtk_widget_hide(output1);
gtk_widget_show (output2);

}


void
on_treeview_rechplv_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* type;
	gchar* quantite;
	gchar* jour_pl;
        gchar* mois_pl;
        gchar* annee_pl;
	gchar* jour_ir;
        gchar* mois_ir;
        gchar* annee_ir;
	gchar* temperature;
	gchar* humidite;
	gchar* zone;
	plantation n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &type , 3, &quantite , 4, &jour_pl, 5, &mois_pl, 6, &annee_pl , 7, &jour_ir , 8, &mois_ir , 9, &annee_ir , 10, &temperature, 11, &humidite , 12, &zone ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.type,type);
                strcpy(n.quantite,quantite);
                n.date_plantation.jour=jour_pl;
                n.date_plantation.mois=mois_pl;
                n.date_plantation.annee=annee_pl;
                n.date_irrigation.jour=jour_ir;
                n.date_irrigation.mois=mois_ir;
                n.date_irrigation.annee=annee_ir;
		strcpy(n.temperature,temperature);
                strcpy(n.humidite,humidite);
                strcpy(n.zone,zone);


                
                afficher(treeview);
}
}


void
on_button_sdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window5;
    GtkWidget *window1;
    window1=lookup_widget(objet,"rechplv");
    gtk_widget_destroy(window5);
    window1=create_gpl();
    gtk_widget_show(window1);
}

