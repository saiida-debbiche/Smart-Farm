#include <gtk/gtk.h>


void
on_button_afflplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_spplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_lplv_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_checkbutton_sdzaaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzbaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzcaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzdaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_sdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdvlchid_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_sdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_sdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdidrech_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfplv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okspplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_sdzamdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzbmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzcmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_sdanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_rechplv_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_sdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
