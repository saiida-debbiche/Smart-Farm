#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}date;

typedef struct
{
    char identifiant[20];
    char nom[20];
    char type[20];
    char quantite[20];
    date date_plantation;
    date date_irrigation;
    char temperature[20];
    char humidite[20];
    char zone[20];
}plantation;


void ajouter(plantation n);
void afficher(GtkWidget *liste);
void supprimer(char idsup[]);
void modifier(plantation n);
void chercher(GtkWidget *liste , char idrech[]);
int verif(char id[]);
void filtrecritere(GtkWidget *liste, char critere[], char filtre[]);
int verifrech(char crt[]);


