#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"
#include "capteur.h"

int x,y,z;
int T1[2]={0,0};
int T2[2]={0,0};


void
on_button_ajtcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetreajcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetreajcap=create_ajcap();
    gtk_widget_show(Fenetreajcap);
}


void
on_button_mdfcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetremdfcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetremdfcap=create_mdfcap();
    gtk_widget_show(Fenetremdfcap);
}


void
on_button_suppcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetresuppcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetresuppcap=create_suppcap();
    gtk_widget_show(Fenetresuppcap);
}


void
on_button_retgcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_button_rechcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrerechcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetrerechcap=create_rechcap();
    gtk_widget_show(Fenetrerechcap);
}


void
on_treeview_lcap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* idcapteur;
	gchar* zone_ajout;
	gchar* type;
	gchar* marque;
	gchar* etat_fct;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;

	capteur c;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &idcapteur, 1, &zone_ajout, 2, &type , 3, &marque, 4, &etat_fct, 5, &jour_fct , 6, &mois_fct , 7, &annee_fct ,-1);
  		strcpy(c.idcapteur,idcapteur);
		strcpy(c.zone_ajout,zone_ajout);
		strcpy(c.type,type);
                strcpy(c.marque,marque);
		strcpy(c.etat_fonctionnement,etat_fct);
                c.date_mise_fct.jour=jour_fct;
                c.date_mise_fct.mois=mois_fct;
                c.date_mise_fct.annee=annee_fct;
                
                
                afficher(treeview);
                
}
}


void
on_button_affcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewlcap;

treeviewlcap=lookup_widget(objet,"treeview_lcap");

afficher(treeviewlcap);
}


void
on_button_msfctcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrefctcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetrefctcap=create_fctcap();
    gtk_widget_show(Fenetrefctcap);
}


void
on_button_mscnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  capteur n;
  GtkWidget *Fenetregcap;
  GtkWidget *Fenetreajcap;
  GtkWidget *input1, *input2;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *zone;
  char text1[20]="temperature";
  char text2[20]="humidite";


Fenetregcap=lookup_widget(objet,"gcap");
input1=lookup_widget(objet,"entry_msidaj");
input2=lookup_widget(objet,"entry_msmraj");
zone=lookup_widget(objet,"combobox_msempaj");
jour=lookup_widget(objet,"spinbutton_msjdiaj");
mois=lookup_widget(objet,"spinbutton_msmdiaj");
annee=lookup_widget(objet,"spinbutton_msadiaj");

strcpy(n.idcapteur,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.zone_ajout,gtk_combo_box_get_active_text(GTK_COMBO_BOX(zone)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(x==1)
{strcpy(n.type,text1);}
else
if(x==2)
{strcpy(n.type,text2);}

if(T1[0]==1)
{strcpy(n.etat_fonctionnement,"oui");}
else
if(T1[1]==1)
{strcpy(n.etat_fonctionnement,"non");}

ajouter(n);

    gtk_widget_destroy(Fenetreajcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);

}


void
on_button_msanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetreajcap;
    Fenetreajcap=lookup_widget(objet,"ajcap");
    gtk_widget_destroy(Fenetreajcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_radiobutton_mstajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_radiobutton_mshaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}


void
on_checkbutton_msofctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T1[0]=1;
}
}


void
on_checkbutton_msnfctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T1[1]=1;
}
}


void
on_button_mscnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  capteur n;
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetremdfcap;
  GtkWidget *input1, *input2;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *zone;
  char text1[20]="temperature";
  char text2[20]="humidite";


Fenetremdfcap=lookup_widget(objet,"mdfcap");
input1=lookup_widget(objet,"entry_msidmdf");
input2=lookup_widget(objet,"entry_msmrmdf");
zone=lookup_widget(objet,"combobox_msempmdf");
jour=lookup_widget(objet,"spinbutton_msjdimdf");
mois=lookup_widget(objet,"spinbutton_msmdimdf");
annee=lookup_widget(objet,"spinbutton_msadimdf");

strcpy(n.idcapteur,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.zone_ajout,gtk_combo_box_get_active_text(GTK_COMBO_BOX(zone)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(y==1)
{strcpy(n.type,text1);}
else
if(y==2)
{strcpy(n.type,text2);}

if(T2[0]==1)
{strcpy(n.etat_fonctionnement,"oui");}
else
if(T2[1]==1)
{strcpy(n.etat_fonctionnement,"non");}

modifier(n);

    gtk_widget_destroy(Fenetremdfcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_button_msanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetremdfcap;
    Fenetremdfcap=lookup_widget(objet,"mdfcap");
    gtk_widget_destroy(Fenetremdfcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_radiobutton_mshmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
y=2;
}
}


void
on_radiobutton_mstmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
y=1;
}
}


void
on_checkbutton_msnfctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T2[1]=1;
}
}


void
on_checkbutton_msofctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T2[0]=1;
}
}


void
on_treeview_mstxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* identifiant;
	gchar* zone;
	gchar* type;
	gchar* marque;
	gchar* etat_fct;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;

	capteur n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &zone, 2, &type , 3, &marque, 4, &etat_fct, 5, &jour_fct , 6, &mois_fct , 7, &annee_fct , -1);
  		strcpy(n.idcapteur,identifiant);
		strcpy(n.zone_ajout,zone);
		strcpy(n.type,type);
                strcpy(n.marque,marque);
		strcpy(n.etat_fonctionnement,etat_fct);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;
                
                
                afficher(treeview);
                
}
}


void
on_button_msretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrerechcap;
    Fenetrerechcap=lookup_widget(objet,"rechcap");
    gtk_widget_destroy(Fenetrerechcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_button_mscnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerechcap;
   GtkWidget *id;
   GtkWidget *treeviewrech;
   char idrech[20];

Fenetrerechcap=lookup_widget(objet,"rechcap");
id=lookup_widget(objet,"entry_msidrech");
treeviewrech=lookup_widget(objet,"treeview_mstxtrech");

strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(id)));

chercher(treeviewrech, idrech);
}


void
on_button_mscnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetresuppcap;
    GtkWidget *id;
    char idsp[20];

id=lookup_widget(objet,"entry_msidsp");
strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));

supprimer(idsp);

    gtk_widget_destroy(Fenetresuppcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);

}


void
on_button_msanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetresuppcap;
    Fenetresuppcap=lookup_widget(objet,"suppcap");
    gtk_widget_destroy(Fenetresuppcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_button_msretfct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrefctcap;
    Fenetrefctcap=lookup_widget(objet,"fctcap");
    gtk_widget_destroy(Fenetrefctcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_treeview_mscapfct_row_activated     (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* val;	

	fctcapteur n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview1);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &jour, 2, &mois , 3, &annee, 4, &val ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.val,val);
                n.date_fct.jour=jour;
                n.date_fct.mois=mois;
                n.date_fct.annee=annee;
                affichercapt(treeview1);
                affichercaph(treeview1);
}  
}


void
on_button_mscnffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    fctcapteur n;
    GtkWidget *Fenetrefctcap;
    GtkWidget *id,*jour,*mois,*annee,*val;

Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"entry_msidfct");
val=lookup_widget(objet,"entry_msvlfct");
jour=lookup_widget(objet,"spinbutton_msjdfct");
mois=lookup_widget(objet,"spinbutton_msmdfct");
annee=lookup_widget(objet,"spinbutton_msadfct");

strcpy(n.identifiant,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(n.val,gtk_entry_get_text(GTK_ENTRY(val)));
n.date_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(z==1)
{temperature(n);}
else
if(z==2)
{humidite(n);}
}


void
on_button_msmdffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    fctcapteur n;
    GtkWidget *Fenetrefctcap;
    GtkWidget *id,*jour,*mois,*annee,*val;

Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"entry_msidfct");
val=lookup_widget(objet,"entry_msvlfct");
jour=lookup_widget(objet,"spinbutton_msjdfct");
mois=lookup_widget(objet,"spinbutton_msmdfct");
annee=lookup_widget(objet,"spinbutton_msadfct");

strcpy(n.identifiant,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(n.val,gtk_entry_get_text(GTK_ENTRY(val)));
n.date_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(z==1)
{modifiertmp(n);}
else
if(z==2)
{modifierhmd(n);}
}


void
on_button_msspfcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrefctcap;
   GtkWidget *id;
   char idsp[20];
    Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"entry_msidfct");
strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));
if(z==1)
{supprimertmp(idsp);}
else
if(z==2)
{supprimerhmd(idsp);}
}


void
on_button_msafffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    fctcapteur n;
    GtkWidget *Fenetrefctcap;
    GtkWidget *id;
    GtkWidget *treeviewfct;
    char idcap[20];

Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"entry_msidfctcap");
treeviewfct=lookup_widget(objet,"treeview_mscapfct");

strcpy(idcap,gtk_entry_get_text(GTK_ENTRY(id)));

if(z==1)
{rechcapt(treeviewfct, idcap);}
else
if(z==2)
{rechcaph(treeviewfct, idcap);}

}


void
on_radiobutton_mstfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
z=1;
}
}


void
on_radiobutton_mshfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
z=2;
}
}

