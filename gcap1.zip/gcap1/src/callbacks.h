#include <gtk/gtk.h>


void
on_button_ajtcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_suppcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retgcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_lcap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_affcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msfctcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mscnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mstajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mshaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_msofctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_msnfctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mscnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mshmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mstmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_msnfctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_msofctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview_mstxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_msretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mscnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mscnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msretfct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_mscapfct_row_activated     (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_mscnffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msmdffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msspfcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msafffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mstfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mshfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
