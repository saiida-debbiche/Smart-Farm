#include <gtk/gtk.h>


void
on_button_ajtrp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retgtrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_ltrp_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_kdmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_kdfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_kdanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_kdmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_kdfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_kdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_kdtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_kdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_khcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_khanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdgrch_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdvldchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_kdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_kdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okscajtrp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdftrp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_oksptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);
