#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int x,y,z;

void
on_button_ajtrp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetreajttroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetreajttroup=create_ajttroup();
    gtk_widget_show(Fenetreajttroup);
}


void
on_button_afftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp;
    GtkWidget *Fenetregtroup;

treeview_ltrp=lookup_widget(objet,"treeview_ltrp");
Fenetregtroup=lookup_widget(objet,"gtroup");

afficher(treeview_ltrp);
}


void
on_button_mdftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetremdftroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetremdftroup=create_mdftroup();
    gtk_widget_show(Fenetremdftroup);
}


void
on_button_supptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetresupptroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetresupptroup=create_supptroup();
    gtk_widget_show(Fenetresupptroup);
}


void
on_button_retgtrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_treeview_ltrp_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* type;
	gchar* genre;
	gchar* etat_sanitaire;
	gchar* j_naissance;
	gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_vaccin;
        gchar* m_vaccin;
	gchar* a_vaccin;

	troupeaux n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &type, 2, &genre , 3, &etat_sanitaire, 4, &j_naissance, 5, &m_naissance , 6, &a_naissance , 7, &j_vaccin , 8, &m_vaccin , 9, &a_vaccin ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.type,type);
                strcpy(n.genre,genre);
		strcpy(n.etat,etat_sanitaire);
		n.naissance.jour=j_naissance;
                n.naissance.mois=m_naissance;
                n.naissance.annee=a_naissance;
                n.vaccin.jour=j_vaccin;
                n.vaccin.mois=m_vaccin;
                n.vaccin.annee=a_vaccin;
                
                
                afficher(treeview);
}
}

void
on_radiobutton_kdmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_radiobutton_kdfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}


void
on_button_kdanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetreajttroup;
    Fenetreajttroup=lookup_widget(objet,"ajttroup");
    gtk_widget_destroy(Fenetreajttroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_button_kdcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)

{
  troupeaux n;
  GtkWidget *Fenetreajttroup;
  GtkWidget *Fenetrescajtrp;
  GtkWidget *input;
  GtkWidget *jourdn,*moisdn,*anneedn,*jourvc,*moisvc,*anneevc;
  GtkWidget *type,*etat;
  GtkWidget *output1;
  int v;
  char id[20];

Fenetreajttroup=lookup_widget(objet,"ajttroup");
input=lookup_widget(objet,"entry_kdidajt");
jourdn=lookup_widget(objet,"spinbutton_kdjdnajt");
moisdn=lookup_widget(objet,"spinbutton_kdmdnajt");
anneedn=lookup_widget(objet,"spinbutton_kdadnajt");
type=lookup_widget(objet,"combobox_kdtpaj");
etat=lookup_widget(objet,"combobox_kdesaj");
jourvc=lookup_widget(objet,"spinbutton_kdjdvajt");
moisvc=lookup_widget(objet,"spinbutton_kdmdvajt");
anneevc=lookup_widget(objet,"spinbutton_kdadvajt");
output1=lookup_widget(objet,"label_kdaltaj");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(n.identifiant,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat)));
n.naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourdn));
n.naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisdn));
n.naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneedn));
n.vaccin.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourvc));
n.vaccin.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisvc));
n.vaccin.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneevc));

if(x==1)
{strcpy(n.genre,"Male");}
else
 if(x==2)
{strcpy(n.genre,"Femelle");}

v=verif(id);

if (v==1)
{
gtk_widget_show (output1);
}
else
{
ajouter(n);

    gtk_widget_destroy(Fenetreajttroup);
    Fenetrescajtrp=create_scajtrp();
    gtk_widget_show(Fenetrescajtrp);
}

}


void
on_radiobutton_kdmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
y=1;
}
}


void
on_radiobutton_kdfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
y=2;
}
}


void
on_button_kdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetremdftroup;
    Fenetremdftroup=lookup_widget(objet,"mdftroup");
    gtk_widget_destroy(Fenetremdftroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_button_kdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  troupeaux n;
  GtkWidget *Fenetremdftroup;
  GtkWidget *Fenetrescmdftrp;
  GtkWidget *input;
  GtkWidget *jourdn,*moisdn,*anneedn,*jourvc,*moisvc,*anneevc;
  GtkWidget *type,*etat;
{
Fenetremdftroup=lookup_widget(objet,"mdftroup");
input=lookup_widget(objet,"combobox_kdidmdf");
jourdn=lookup_widget(objet,"spinbutton_kdjdnmdf");
moisdn=lookup_widget(objet,"spinbutton_kdmdnmdf");
anneedn=lookup_widget(objet,"spinbutton_kdadnmdf");
type=lookup_widget(objet,"combobox_kdtpmdf");
etat=lookup_widget(objet,"combobox_kdesmdf");
jourvc=lookup_widget(objet,"spinbutton_kdjdvmdf");
moisvc=lookup_widget(objet,"spinbutton_kdmdvmdf");
anneevc=lookup_widget(objet,"spinbutton_kdadvmdf");

strcpy(n.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat)));
n.naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourdn));
n.naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisdn));
n.naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneedn));
n.vaccin.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourvc));
n.vaccin.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisvc));
n.vaccin.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneevc));
} 
if(y==1)
{strcpy(n.genre,"Male");}
else
 if(y==2)
{strcpy(n.genre,"Femelle");}
 
modifiertrp(n);
 
    gtk_widget_destroy(Fenetremdftroup);
    Fenetrescmdftrp=create_scmdftrp();
    gtk_widget_show(Fenetrescmdftrp);
}


void
on_treeview_kdtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* type;
	gchar* genre;
	gchar* etat_sanitaire;
	gchar* j_naissance;
	gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_vaccin;
        gchar* m_vaccin;
	gchar* a_vaccin;

	troupeaux n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &type, 2, &genre , 3, &etat_sanitaire, 4, &j_naissance, 5, &m_naissance , 6, &a_naissance , 7, &j_vaccin , 8, &m_vaccin , 9, &a_vaccin ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.type,type);
                strcpy(n.genre,genre);
		strcpy(n.etat,etat_sanitaire);
		n.naissance.jour=j_naissance;
                n.naissance.mois=m_naissance;
                n.naissance.annee=a_naissance;
                n.vaccin.jour=j_vaccin;
                n.vaccin.mois=m_vaccin;
                n.vaccin.annee=a_vaccin;
                
                
                affichertrp(treeview);
}
}


void
on_button_kdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
     GtkWidget *Fenetregtroup;
    GtkWidget *Fenetrerechtroup;
    Fenetrerechtroup=lookup_widget(objet,"rechtroup");
    gtk_widget_destroy(Fenetrerechtroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_button_kdcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerechtroup;
   GtkWidget *id,*output1,*output2,*crt;
   GtkWidget *treeviewrech;
   char filtre[20];
   char critere[20];
   int v;
   
Fenetrerechtroup=lookup_widget(objet,"rechtroup");
id=lookup_widget(objet,"entry_kdidrech");
output1=lookup_widget(objet,"label_kdtxtrech");
output2=lookup_widget(objet,"label_kdaltrech");
treeviewrech=lookup_widget(objet,"treeview_kdtxtrech");
crt=lookup_widget(objet,"combobox_kdcrrech");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

v=verifrech(filtre);

if(v!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
filtrecritere(treeviewrech, critere, filtre);
}
}


void
on_button_khcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresupptroup;
   GtkWidget *Fenetrescsptrp;
   GtkWidget *id;
   GtkWidget *output1,*output2;
   char idsp[20];
   int v;

Fenetresupptroup=lookup_widget(objet,"supptroup");
id=lookup_widget(objet,"entry_khidsp");
output1=lookup_widget(objet,"label_khcnfsp");
output2=lookup_widget(objet,"label_kdaltsp");

strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));

v=verif(idsp);
if(v!=1)
{
    gtk_widget_show (output2);
}
else
{
if(z==1)
{
supprimer(idsp);

    gtk_widget_destroy(Fenetresupptroup);
    Fenetrescsptrp=create_scsptrp();
    gtk_widget_show(Fenetrescsptrp);
}
}

}


void
on_button_khanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetresupptroup;
    Fenetresupptroup=lookup_widget(objet,"supptroup");
    gtk_widget_destroy(Fenetresupptroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_button_kdgrch_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
     GtkWidget *Fenetregtroup;
    GtkWidget *Fenetrerechtroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetrerechtroup=create_rechtroup();
    gtk_widget_show(Fenetrerechtroup);
}


void
on_button_kdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
  troupeaux t;
  FILE *f;
  GtkWidget *Fenetremdftroup;
  GtkWidget *id;
  GtkWidget *output1,*output2;

Fenetremdftroup=lookup_widget(objet,"mdftroup");
id=lookup_widget(objet,"combobox_kdidmdf");
output1=lookup_widget(objet,"label_kdchidmdf");
output2=lookup_widget(objet,"label_kdanlchid");

f=fopen("liste_troupeaux.txt","r");
 while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",t.identifiant,t.type,t.genre,t.etat,&t.naissance.jour,&t.naissance.mois,&t.naissance.annee,&t.vaccin.jour,&t.vaccin.mois,&t.vaccin.annee)!=EOF)
       {
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(t.identifiant));
       }
fclose(f);

gtk_widget_hide(output2);
gtk_widget_show (output1);
}


void
on_button_kdvldchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  troupeaux t;
  FILE *f;
    GtkWidget *Fenetremdftroup;
    GtkWidget *output1,*output2,*id,*type;
    char identifiant[20];

Fenetremdftroup=lookup_widget(objet,"mdftroup");
output1=lookup_widget(objet,"label_kdchidmdf");
output2=lookup_widget(objet,"label_kdanlchid");
id=lookup_widget(objet,"combobox_kdidmdf");
type=lookup_widget(objet,"combobox_kdtpmdf");

strcpy(identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("liste_troupeaux.txt","r");
 while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",t.identifiant,t.type,t.genre,t.etat,&t.naissance.jour,&t.naissance.mois,&t.naissance.annee,&t.vaccin.jour,&t.vaccin.mois,&t.vaccin.annee)!=EOF)
       {
if(strcmp(t.identifiant,identifiant)==0)
{ 
gtk_combo_box_append_text (GTK_COMBO_BOX(type),_(t.type));
}
}
fclose(f);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_button_kdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetremdftroup;
    GtkWidget *output1,*output2;

Fenetremdftroup=lookup_widget(objet,"mdftroup");
output1=lookup_widget(objet,"label_kdchidmdf");
output2=lookup_widget(objet,"label_kdanlchid");

gtk_widget_hide(output1);
gtk_widget_show (output2);
}


void
on_radiobutton_kdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresupptroup;
   GtkWidget *output1;

Fenetresupptroup=lookup_widget(objet,"supptroup");
output1=lookup_widget(objet,"label_khcnfsp");
z=0;

gtk_widget_hide(output1);
}


void
on_radiobutton_kdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresupptroup;
   GtkWidget *output1;
   GtkWidget *id;

Fenetresupptroup=lookup_widget(objet,"supptroup");
output1=lookup_widget(objet,"label_khcnfsp");
z=1;

    gtk_widget_show (output1);


}


void
on_button_okscajtrp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp;
    GtkWidget *Fenetrescajtrp;
    GtkWidget *Fenetregtroup;


Fenetrescajtrp=lookup_widget(objet,"scajtrp");
    gtk_widget_destroy(Fenetrescajtrp);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);

treeview_ltrp=lookup_widget(Fenetregtroup,"treeview_ltrp");

afficher(treeview_ltrp);
}


void
on_button_okmdftrp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp;
    GtkWidget *Fenetrescmdftrp;
    GtkWidget *Fenetregtroup;


Fenetrescmdftrp=lookup_widget(objet,"scmdftrp");
    gtk_widget_destroy(Fenetrescmdftrp);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);

treeview_ltrp=lookup_widget(Fenetregtroup,"treeview_ltrp");

afficher(treeview_ltrp);
}


void
on_button_oksptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp;
    GtkWidget *Fenetrescsptrp;
    GtkWidget *Fenetregtroup;

Fenetrescsptrp=lookup_widget(objet,"scsptrp");
    gtk_widget_destroy(Fenetrescsptrp);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);

treeview_ltrp=lookup_widget(Fenetregtroup,"treeview_ltrp");

afficher(treeview_ltrp);
}

