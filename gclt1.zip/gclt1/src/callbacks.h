#include <gtk/gtk.h>


void
on_button_affcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajtcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_suppcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retgcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_lcl_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_rechcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nmmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_nmfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_nmfdajt_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_nmcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nmmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_nmfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_nmfdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_nmcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_nmtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_nmretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmchidmdf_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmvldch_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nmosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nmnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfclt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_scspclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);
