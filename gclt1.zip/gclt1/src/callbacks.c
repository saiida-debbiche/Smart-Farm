#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "file.h"

int x;
int y=0;
int a;
int b=0;
int z;


void
on_button_affcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview_lcl;
GtkWidget *Fenetregclt;

treeview_lcl=lookup_widget(objet,"treeview_lcl");
Fenetregclt=lookup_widget(objet,"gclt");

afficher(treeview_lcl);
}


void
on_button_ajtcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetreajtcl;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetreajtcl=create_ajtcl();
    gtk_widget_show(Fenetreajtcl);
}


void
on_button_mdfcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetremdfcl;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetremdfcl=create_mdfcl();
    gtk_widget_show(Fenetremdfcl);
}


void
on_button_suppcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetresuppclt;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetresuppclt=create_suppclt();
    gtk_widget_show(Fenetresuppclt);
}


void
on_button_retgcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_treeview_lcl_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* sexe;
	gchar* email;
	gchar* tel;
	gchar* fidelite;
        gchar* j_naissance;
        gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_inscri;
        gchar* m_inscri;
	gchar* a_inscri;

	client n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &id, 1, &nom, 2, &prenom , 3, &sexe, 4, &email, 5, &tel , 6, &fidelite , 7, &j_naissance , 8, &m_naissance , 9, &a_naissance , 10, &j_inscri , 11, &m_inscri , 12, &a_inscri ,-1);
  		strcpy(n.id,id);
		strcpy(n.nom,nom);
		strcpy(n.prenom,prenom);
                strcpy(n.sexe,sexe);
		strcpy(n.email,email);
                strcpy(n.numtel,tel);
                strcpy(n.fidelite,fidelite);
                n.dn.j=j_naissance;
                n.dn.m=m_naissance;
                n.dn.a=a_naissance;
                n.da.j=j_inscri;
                n.da.m=m_inscri;
                n.da.a=a_inscri;
                
                
                afficher(treeview);
}
}

void
on_button_rechcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrerechclt;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetrerechclt=create_rechcl();
    gtk_widget_show(Fenetrerechclt);
}


void
on_radiobutton_nmmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_radiobutton_nmfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}


void
on_checkbutton_nmfdajt_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=1;
}
}


void
on_button_nmcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    client n;
    GtkWidget *Fenetresajclt;
    GtkWidget *Fenetreajtcl;
    GtkWidget *input1, *input2, *input3, *input4 , *input5;
    GtkWidget *jdn,*mdn,*adn,*jdi,*mdi,*adi;
    GtkWidget *output1, *output2, *output3, *output4, *output5;
    int b=1,v;
    char id[20];
    
Fenetreajtcl=lookup_widget(objet,"ajtcl");
input1=lookup_widget(objet,"entry_nmnomajt");
input2=lookup_widget(objet,"entry_nmpreajt");
input3=lookup_widget(objet,"entry_nmaeajt");
input4=lookup_widget(objet,"entry_nmidajt");
input5=lookup_widget(objet,"entry_nmtelajt");
jdn=lookup_widget(objet,"spinbuttonnmjdnajt");
mdn=lookup_widget(objet,"spinbutton_nmmdnajt");
adn=lookup_widget(objet,"spinbutton_nmadnajt");
jdi=lookup_widget(objet,"spinbutton_nmjdiajt");
mdi=lookup_widget(objet,"spinbutton_nmmdiajt");
adi=lookup_widget(objet,"spinbutton_nmadiajt");
output1=lookup_widget(objet,"label_nmsnomaj");
output2=lookup_widget(objet,"label_nmspreaj");
output3=lookup_widget(objet,"label_nmsaeaj");
output4=lookup_widget(objet,"label_nmspraj");
output5=lookup_widget(objet,"label_nmaltaj");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
if(strcmp(n.nom,"")==0)
{
gtk_widget_show (output1);
b=0;
}
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
if(strcmp(n.prenom,"")==0)
{
gtk_widget_show (output2);
b=0;
}
strcpy(n.email,gtk_entry_get_text(GTK_ENTRY(input3)));
if(strcmp(n.email,"")==0)
{
gtk_widget_show (output3);
b=0;
}
strcpy(n.id,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(n.numtel,gtk_entry_get_text(GTK_ENTRY(input5)));
if(strcmp(n.numtel,"")==0)
{
gtk_widget_show (output4);
b=0;
}
n.dn.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdn));
n.dn.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdn));
n.dn.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adn));
n.da.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdi));
n.da.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdi));
n.da.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adi));

if(x==1)
{strcpy(n.sexe,"Masculin");}
else
if(x==2)
{strcpy(n.sexe,"Feminin");}

if(y==1)
{strcpy(n.fidelite,"oui");}
else
if(y==0)
{strcpy(n.fidelite,"non");}

v=verif(id);
if (v==1)
{
gtk_widget_show (output5);
}
else
{
  if(b==1)
{
ajouter(n);

    gtk_widget_destroy(Fenetreajtcl);
    Fenetresajclt=create_sajclt();
    gtk_widget_show(Fenetresajclt);
}
}
}


void
on_button_nmanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetreajtcl;
    Fenetreajtcl=lookup_widget(objet,"ajtcl");
    gtk_widget_destroy(Fenetreajtcl);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_radiobutton_nmmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a=1;
}
}


void
on_radiobutton_nmfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a=2;
}
}


void
on_checkbutton_nmfdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
b=1;
}
}


void
on_button_nmcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
   client n;
    GtkWidget *Fenetrescmdfclt;
    GtkWidget *Fenetremdfcl;
    GtkWidget *input1, *input2, *input3, *input4 , *input5;
    GtkWidget *jdn,*mdn,*adn,*jdi,*mdi,*adi;

    Fenetremdfcl=lookup_widget(objet,"mdfcl");

input1=lookup_widget(objet,"entry_nmnommdf");
input2=lookup_widget(objet,"entry_nmpremdf");
input3=lookup_widget(objet,"entry_nmaemdf");
input4=lookup_widget(objet,"combobox_nmidmdf");
input5=lookup_widget(objet,"entry_nmtelmdf");
jdn=lookup_widget(objet,"spinbutton_nmjdnmdf");
mdn=lookup_widget(objet,"spinbutton_nmmdnmdf");
adn=lookup_widget(objet,"spinbutton_nmadnmdf");
jdi=lookup_widget(objet,"spinbutton_nmjdimdf");
mdi=lookup_widget(objet,"spinbutton_nmmdimdf");
adi=lookup_widget(objet,"spinbutton_nmadimdf");

strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.email,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(n.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy(n.numtel,gtk_entry_get_text(GTK_ENTRY(input5)));
n.dn.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdn));
n.dn.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdn));
n.dn.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adn));
n.da.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdi));
n.da.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdi));
n.da.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adi));

if(a==1)
{strcpy(n.sexe,"Masculin");}
else
if(a==2)
{strcpy(n.sexe,"Feminin");}

if(b==1)
{strcpy(n.fidelite,"oui");}
else
if(b==0)
{strcpy(n.fidelite,"non");}
   
   modifier(n);
   
    gtk_widget_destroy(Fenetremdfcl);
    Fenetrescmdfclt=create_scmdfclt();
    gtk_widget_show(Fenetrescmdfclt);
}


void
on_button_nmanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetremdfcl;
    Fenetremdfcl=lookup_widget(objet,"mdfcl");
    gtk_widget_destroy(Fenetremdfcl);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_treeview_nmtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* sexe;
	gchar* email;
	gchar* tel;
	gchar* fidelite;
        gchar* j_naissance;
        gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_inscri;
        gchar* m_inscri;
	gchar* a_inscri;

	client n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &id, 1, &nom, 2, &prenom , 3, &sexe, 4, &email, 5, &tel , 6, &fidelite , 7, &j_naissance , 8, &m_naissance , 9, &a_naissance , 10, &j_inscri , 11, &m_inscri , 12, &a_inscri ,-1);
  		strcpy(n.id,id);
		strcpy(n.nom,nom);
		strcpy(n.prenom,prenom);
                strcpy(n.sexe,sexe);
		strcpy(n.email,email);
                strcpy(n.numtel,tel);
                strcpy(n.fidelite,fidelite);
                n.dn.j=j_naissance;
                n.dn.m=m_naissance;
                n.dn.a=a_naissance;
                n.da.j=j_inscri;
                n.da.m=m_inscri;
                n.da.a=a_inscri;
                
                
                afficher(treeview);
}
}


void
on_button_nmretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrerechclt;
    Fenetrerechclt=lookup_widget(objet,"rechcl");
    gtk_widget_destroy(Fenetrerechclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_button_nmcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerechclt;
   GtkWidget *id,*output1,*output2,*crt;
   GtkWidget *treeviewrech;
   char filtre[20];
   char critere[30];
   int v;
   
Fenetrerechclt=lookup_widget(objet,"rechcl");
id=lookup_widget(objet,"entry_nmidrech");
output1=lookup_widget(objet,"label_nmtxtrech");
output2=lookup_widget(objet,"label_nmaltrech");
treeviewrech=lookup_widget(objet,"treeview_nmtxtrech");
crt=lookup_widget(objet,"combobox_nmcrrech");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

v=verifrech(filtre);
if(v!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
filtrecritere(treeviewrech, critere, filtre);
}
}


void
on_button_nmcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrescspclt;
    GtkWidget *Fenetresuppclt;
    GtkWidget *output1,*output2;
    GtkWidget *id;
    char idsp[20];
    int v;

    Fenetresuppclt=lookup_widget(objet,"suppclt");
    id=lookup_widget(objet,"entry2");
    output1=lookup_widget(objet,"label_nmmsgsp");
    output2=lookup_widget(objet,"label_nmaltsp");
    strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));
v=verif(idsp);
if(v!=1)
{
    gtk_widget_show (output2);
}
else
{
if(z==1)
{
    supprimer(idsp);
    gtk_widget_destroy(Fenetresuppclt);
    Fenetrescspclt=create_scspclt();
    gtk_widget_show(Fenetrescspclt);
}
}

}


void
on_button_nmanlrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetresuppclt;
    Fenetresuppclt=lookup_widget(objet,"suppclt");
    gtk_widget_destroy(Fenetresuppclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_button_nmchidmdf_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  client c;
  FILE *f;
  GtkWidget *Fenetremdfcl;
  GtkWidget *id;
  GtkWidget *output1,*output2;

Fenetremdfcl=lookup_widget(objet,"mdfcl");
id=lookup_widget(objet,"combobox_nmidmdf");
output1=lookup_widget(objet,"label_nmchid");
output2=lookup_widget(objet,"label_nmmsgmdf");

f=fopen("liste_clients.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c.id,c.prenom,c.nom,c.email,c.numtel,c.sexe,c.fidelite,&c.dn.j,&c.dn.m,&c.dn.a,&c.da.j,&c.da.m,&c.da.a)!=EOF)
       {
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(c.id));
       }
fclose(f);
gtk_widget_hide(output2);
gtk_widget_show (output1);
}


void
on_button_nmvldch_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  client c;
  FILE *f;
  GtkWidget *Fenetremdfcl;
  GtkWidget *id;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *output1,*output2;
    char nom1[30];
    char prenom1[30];
    char email1[40];
    char id1[20];
    char tel1[20];

Fenetremdfcl=lookup_widget(objet,"mdfcl");
id=lookup_widget(objet,"combobox_nmidmdf");
input1=lookup_widget(objet,"entry_nmnommdf");
input2=lookup_widget(objet,"entry_nmpremdf");
input3=lookup_widget(objet,"entry_nmaemdf");
input4=lookup_widget(objet,"entry_nmtelmdf");
output1=lookup_widget(objet,"label_nmchid");
output2=lookup_widget(objet,"label_nmmsgmdf");

strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
f=fopen("liste_clients.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c.id,c.prenom,c.nom,c.email,c.numtel,c.sexe,c.fidelite,&c.dn.j,&c.dn.m,&c.dn.a,&c.da.j,&c.da.m,&c.da.a)!=EOF)
       {
if(strcmp(c.id,id1)==0)
{
strcpy(prenom1,c.prenom);
strcpy(nom1,c.nom);
strcpy(email1,c.email);
strcpy(tel1,c.numtel);
}    
        }
fclose(f);

gtk_entry_set_text(input1,nom1);
gtk_entry_set_text(input2,prenom1);
gtk_entry_set_text(input3,email1);
gtk_entry_set_text(input4,tel1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);

}


void
on_button_nmanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetremdfcl;
  GtkWidget *output1,*output2;

Fenetremdfcl=lookup_widget(objet,"mdfcl");
output1=lookup_widget(objet,"label_nmchid");
output2=lookup_widget(objet,"label_nmmsgmdf");

gtk_widget_hide(output1);
gtk_widget_show (output2);
}


void
on_radiobutton_nmosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetresuppclt;
    GtkWidget *output1;
    GtkWidget *id;

   Fenetresuppclt=lookup_widget(objet,"suppclt");
    id=lookup_widget(objet,"entry2");
    output1=lookup_widget(objet,"label_nmmsgsp");
    z=1;

    gtk_widget_show (output1);

}


void
on_radiobutton_nmnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetresuppclt;
    GtkWidget *output1;
    GtkWidget *id;

   Fenetresuppclt=lookup_widget(objet,"suppclt");
    output1=lookup_widget(objet,"label_nmmsgsp");
    z=0;
gtk_widget_hide(output1);
}


void
on_button_okmdfclt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrescmdfclt;
GtkWidget *treeview_lcl;
    Fenetrescmdfclt=lookup_widget(objet,"scmdfclt");
    gtk_widget_destroy(Fenetrescmdfclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
treeview_lcl=lookup_widget(Fenetregclt,"treeview_lcl");

afficher(treeview_lcl);
}


void
on_button_scspclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrescspclt;
GtkWidget *treeview_lcl;
    Fenetrescspclt=lookup_widget(objet,"scspclt");
    gtk_widget_destroy(Fenetrescspclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
treeview_lcl=lookup_widget(Fenetregclt,"treeview_lcl");

afficher(treeview_lcl);
}


void
on_button_okajclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetresajclt;
GtkWidget *treeview_lcl;
    Fenetresajclt=lookup_widget(objet,"sajclt");
    gtk_widget_destroy(Fenetresajclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
treeview_lcl=lookup_widget(Fenetregclt,"treeview_lcl");

afficher(treeview_lcl);
}

