#include "file.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum
{
	EID,
	EPRENOM,
	ENOM,
	ESEXE,
	EEMAIL,
	ENUMTEL,
	EFIDELITE,
	EJN,
	EMN,
	EAN,
	EJI,
	EMI,
	EAI,
	COLUMNS,
};

void ajouter(client c)
{
   FILE *f;
f=fopen("liste_clients.txt","a+") ;
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c.id,c.prenom,c.nom,c.email,c.numtel,c.sexe,c.fidelite,c.dn.j,c.dn.m,c.dn.a,c.da.j,c.da.m,c.da.a);
fclose(f);
}
}

void modifier(client n)
{
char id1[20];
char prenom1[30];
char nom1[30];
char sexe1[20];
char numtel1[20];
char email1[40];
char fidelite1[20];
    int jdn;
    int mdn;
    int adn;
    int jdi;
    int mdi;
    int adi;	

FILE *f;
FILE *f1;

f=fopen("liste_clients.txt","r");
f1=fopen("modif.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d \n",id1,prenom1,nom1,email1,numtel1,sexe1,fidelite1,&jdn,&mdn,&adn,&jdi,&mdi,&adi)!=EOF)
{
if (strcmp(n.id,id1)==0)
	fprintf(f1,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",n.id,n.prenom,n.nom,n.email,n.numtel,n.sexe,n.fidelite,n.dn.j,n.dn.m,n.dn.a,n.da.j,n.da.m,n.da.a);

else
	fprintf(f1,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",id1,prenom1,nom1,email1,numtel1,sexe1,fidelite1,jdn,mdn,adn,jdi,mdi,adi);

}
fclose(f);
fclose(f1);
remove("liste_clients.txt");
rename("modif.txt","liste_clients.txt");
}



void supprimer(char idsp[])
{
client c2;
FILE *f,*g;
f=fopen("liste_clients.txt","r");
g=fopen("tempo.txt","w");

    if (f==NULL || g==NULL)
     return;
else
{
    while (fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c2.id,c2.prenom,c2.nom,c2.email,c2.numtel,c2.sexe,c2.fidelite,&c2.dn.j,&c2.dn.m,&c2.dn.a,&c2.da.j,&c2.da.m,&c2.da.a)!=EOF)
    {
	if(strcmp(c2.id,idsp)!=0)
fprintf(g,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c2.id,c2.prenom,c2.nom,c2.email,c2.numtel,c2.sexe,c2.fidelite,c2.dn.j,c2.dn.m,c2.dn.a,c2.da.j,c2.da.m,c2.da.a);
    }
    }

fclose(f);
fclose(g);
remove("liste_clients.txt");
rename("tempo.txt","liste_clients.txt");
}

void afficher(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

	char id[20];
	char prenom[30];
	char nom[30];
	char sexe[20];
	char numtel[20];
	char email[40];
	char fidelite[20];
	char j_naissance[10];
	char m_naissance[10];
	char a_naissance[10];
	char j_inscri[10];
	char m_inscri[10];
	char a_inscri[10];


store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("numtel",renderer,"text",ENUMTEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("fidelite",renderer,"text",EFIDELITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("j_naissance",renderer,"text",EJN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("m_naissance",renderer,"text",EMN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("a_naissance",renderer,"text",EAN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("j_inscri",renderer,"text",EJI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("m_inscri",renderer,"text",EMI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("a_inscri",renderer,"text",EAI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	


store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("liste_clients.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_clients.txt","a+");
while (fscanf (f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",id,prenom,nom,email,numtel,sexe,fidelite,j_naissance,m_naissance,a_naissance,j_inscri,m_inscri,a_inscri)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,id,EPRENOM,prenom,ENOM,nom,EEMAIL,email,ENUMTEL,numtel,ESEXE,sexe,EFIDELITE,fidelite,EJN,j_naissance,EMN,m_naissance,EAN,a_naissance,EJI,j_inscri,EMI,m_inscri,EAI,a_inscri,-1);

}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

void rechercher(GtkWidget *liste,char idrech[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

	char id[20];
	char prenom[30];
	char nom[30];
	char sexe[20];
	char numtel[20];
	char email[40];
	char fidelite[20];
	char jdi[10];
	char mdi[10];
	char adi[10];
	char jdn[10];
	char mdn[10];
	char adn[10];


store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("numtel",renderer,"text",ENUMTEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("fidelite",renderer,"text",EFIDELITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jdn",renderer,"text",EJN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mdn",renderer,"text",EMN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adn",renderer,"text",EAN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jdi",renderer,"text",EJI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mdi",renderer,"text",EMI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adi",renderer,"text",EAI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	


store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("liste_clients.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_clients.txt","a+");
while (fscanf (f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",id,prenom,nom,email,numtel,sexe,fidelite,jdn,mdn,adn,jdi,mdi,adi)!=EOF)
		{
                  if(strcmp(id,idrech)==0)
            {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,id,EPRENOM,prenom,ENOM,nom,EEMAIL,email,ENUMTEL,numtel,ESEXE,sexe,EFIDELITE,fidelite,EJN,jdn,EMN,mdn,EAN,adn,EJI,jdi,EMI,mdi,EAI,adi,-1);
            }
}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

int verif(char id[])
{
    
    FILE *f=NULL;
    client c;
    int test;
    f=fopen("liste_clients.txt","r");
    test=0;
    if(f!=NULL)
    {
       while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c.id,c.prenom,c.nom,c.email,c.numtel,c.sexe,c.fidelite,&c.dn.j,&c.dn.m,&c.dn.a,&c.da.j,&c.da.m,&c.da.a)!=EOF)
       {
         if(strcmp(c.id,id)==0)
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}

void filtrecritere(GtkWidget *liste, char critere[], char filtre[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

	char id[20];
	char prenom[30];
	char nom[30];
	char sexe[20];
	char numtel[20];
	char email[40];
	char fidelite[20];
	char j_naissance[10];
	char m_naissance[10];
	char a_naissance[10];
	char j_inscri[10];
	char m_inscri[10];
	char a_inscri[10];


store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("numtel",renderer,"text",ENUMTEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("fidelite",renderer,"text",EFIDELITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("j_naissance",renderer,"text",EJN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("m_naissance",renderer,"text",EMN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("a_naissance",renderer,"text",EAN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("j_inscri",renderer,"text",EJI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("m_inscri",renderer,"text",EMI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("a_inscri",renderer,"text",EAI,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	


store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("liste_clients.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_clients.txt","a+");
while (fscanf (f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",id,prenom,nom,email,numtel,sexe,fidelite,j_naissance,m_naissance,a_naissance,j_inscri,m_inscri,a_inscri)!=EOF)		{
             if(strcmp(critere,"identifiant")==0)
{
         if(strcmp(filtre,id)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,id,EPRENOM,prenom,ENOM,nom,EEMAIL,email,ENUMTEL,numtel,ESEXE,sexe,EFIDELITE,fidelite,EJN,j_naissance,EMN,m_naissance,EAN,a_naissance,EJI,j_inscri,EMI,m_inscri,EAI,a_inscri,-1);
}
}
            if(strcmp(critere,"nom")==0)
{
         if(strcmp(filtre,nom)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,id,EPRENOM,prenom,ENOM,nom,EEMAIL,email,ENUMTEL,numtel,ESEXE,sexe,EFIDELITE,fidelite,EJN,j_naissance,EMN,m_naissance,EAN,a_naissance,EJI,j_inscri,EMI,m_inscri,EAI,a_inscri,-1);
}
}
            if(strcmp(critere,"prenom")==0)
{
         if(strcmp(filtre,prenom)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,id,EPRENOM,prenom,ENOM,nom,EEMAIL,email,ENUMTEL,numtel,ESEXE,sexe,EFIDELITE,fidelite,EJN,j_naissance,EMN,m_naissance,EAN,a_naissance,EJI,j_inscri,EMI,m_inscri,EAI,a_inscri,-1);
}
}
            if(strcmp(critere,"fidelite")==0)
{
         if(strcmp(filtre,fidelite)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,id,EPRENOM,prenom,ENOM,nom,EEMAIL,email,ENUMTEL,numtel,ESEXE,sexe,EFIDELITE,fidelite,EJN,j_naissance,EMN,m_naissance,EAN,a_naissance,EJI,j_inscri,EMI,m_inscri,EAI,a_inscri,-1);
}
}
            if(strcmp(critere,"annee_inscription")==0)
{
         if(strcmp(filtre,a_inscri)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,id,EPRENOM,prenom,ENOM,nom,EEMAIL,email,ENUMTEL,numtel,ESEXE,sexe,EFIDELITE,fidelite,EJN,j_naissance,EMN,m_naissance,EAN,a_naissance,EJI,j_inscri,EMI,m_inscri,EAI,a_inscri,-1);
}
}
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

int verifrech(char crt[])
{
    
    FILE *f=NULL;
	char id[20];
	char prenom[30];
	char nom[30];
	char sexe[20];
	char numtel[20];
	char email[40];
	char fidelite[20];
	char j_naissance[10];
	char m_naissance[10];
	char a_naissance[10];
	char j_inscri[10];
	char m_inscri[10];
	char a_inscri[10];
    int test;
    f=fopen("liste_clients.txt","r");
    test=0;
    if(f!=NULL)
    {
 while (fscanf (f,"%s %s %s %s %s %s %s %s %s %s %s %s %s\n",id,prenom,nom,email,numtel,sexe,fidelite,j_naissance,m_naissance,a_naissance,j_inscri,m_inscri,a_inscri)!=EOF)
       {
         if(strcmp(id,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(nom,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(prenom,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(fidelite,crt)==0)
        {
          test=1;
          break;
        }
       if(strcmp(a_inscri,crt)==0)
        {
          test=1;
          break;
        }
       }
     fclose(f);
     }
return(test);
}


