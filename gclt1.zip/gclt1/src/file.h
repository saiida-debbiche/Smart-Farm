#ifndef HEADER_H
#define HEADER_H
#include <string.h>
#include <gtk/gtk.h>
typedef struct
{
int j;
int m;
int a;
}date;

typedef struct
{
char id[20];
char prenom[30];
char nom[30];
char sexe[20];
char numtel[20];
char email[40];
char fidelite[20];
date da;
date dn;
}client;

void ajouter(client c);
void supprimer(char idsp[]);
void rechercher(GtkWidget *liste,char idrech[]);
void modifier(client c);
void afficher(GtkWidget *liste);
int verif(char id[]);
void filtrecritere(GtkWidget *liste, char critere[], char filtre[]);
int verifrech(char crt[]);


#endif // HEADER_H
