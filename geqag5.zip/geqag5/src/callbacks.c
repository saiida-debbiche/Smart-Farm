#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include <time.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"

int x;
int y=0;
int a;
int b=0;
int z;


void
on_treeview_leqag_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* reference;
	gchar* matricule;
	gchar* type;
	gchar* marque;
	gchar* fournisseur;
	gchar* etat_fct;
	gchar* garantie;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;
	gchar* disponibilite;

	equi_agr n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &reference, 1, &matricule, 2, &type , 3, &marque, 4, &fournisseur, 5, &etat_fct , 6, &garantie , 7, &disponibilite , 8, &jour_fct , 9, &mois_fct , 10, &annee_fct ,-1);
  		strcpy(n.reference,reference);
		strcpy(n.matricule,matricule);
		strcpy(n.type,type);
                strcpy(n.marque,marque);
		strcpy(n.fournisseur,fournisseur);
		strcpy(n.etat_fonctionnement,etat_fct);
                strcpy(n.garantie,garantie);
                strcpy(n.disponibilite,disponibilite);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;
                
                supprimertree(n);
                afficher(treeview);
                
}
}


void
on_button_ajteq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetreajeqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetreajeqag=create_ajeqag();
    gtk_widget_show(Fenetreajeqag);
}


void
on_button_mdfeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetremdfeqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetremdfeqag=create_mdfeqag();
    gtk_widget_show(Fenetremdfeqag);

}


void
on_button_suppeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetresuppeqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetresuppeqag=create_suppeqag();
    gtk_widget_show(Fenetresuppeqag);

}


void
on_button_recheq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetrerecheqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetrerecheqag=create_recheqag();
    gtk_widget_show(Fenetrerecheqag);
}


void
on_button_retgeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_button_affeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{

    GtkWidget *treeview_leqag;
    GtkWidget *Fenetregeqag;
   

Fenetregeqag=lookup_widget(objet,"geqagr");
treeview_leqag=lookup_widget(Fenetregeqag,"treeview_leqag");

afficher(treeview_leqag);
}


void
on_button_hgcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;

  GtkWidget *Fenetreajeqag;
  GtkWidget *Fenetrescajeq;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *output1, *output2, *output3, *output6;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *type,*etat_fct;
  char ref[20];
  int b=1,v;

Fenetreajeqag=lookup_widget(objet,"ajeqag");
input1=lookup_widget(objet,"entry_hgrefaj");
input2=lookup_widget(objet,"entry_hgmtaj");
input3=lookup_widget(objet,"entry_hgmraj");
input4=lookup_widget(objet,"entry_hgfsaj");
type=lookup_widget(objet,"combobox_hgtpaj");
etat_fct=lookup_widget(objet,"combobox_hgefctaj");
jour=lookup_widget(objet,"spinbutton_hgjdfaj");
mois=lookup_widget(objet,"spinbutton_hgmdfaj");
annee=lookup_widget(objet,"spinbutton_hgadfaj");
output1=lookup_widget(objet,"label_hgsmataj");
output2=lookup_widget(objet,"label_hgsmraj");
output3=lookup_widget(objet,"label_hgsfsaj");
output6=lookup_widget(objet,"label_hgajsc");

strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.reference,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(n.matricule,gtk_entry_get_text(GTK_ENTRY(input2)));

if(strcmp(n.matricule,"")==0)
{
gtk_widget_show (output1);
b=0;
}

strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input3)));

if(strcmp(n.marque,"")==0)
{
gtk_widget_show (output2);
b=0;
}

strcpy(n.fournisseur,gtk_entry_get_text(GTK_ENTRY(input4)));

if(strcmp(n.fournisseur,"")==0)
{
gtk_widget_show (output3);
b=0;
}

strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat_fonctionnement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat_fct)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(x==1)
{strcpy(n.disponibilite,"oui");}
else
if(x==2)
{strcpy(n.disponibilite,"non");}

if(y==1)
{strcpy(n.garantie,"oui");}
else
if(y==0)
{strcpy(n.garantie,"non");}

v=verif(ref);


if (v==1)
{
gtk_widget_show (output6);
}
else
{
  if(b==1)
{
    ajouter(n);
    gtk_widget_destroy(Fenetreajeqag);
    Fenetrescajeq=create_scajeq();
    gtk_widget_show(Fenetrescajeq);
}
}

}


void
on_button_hganlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetreajeqag;
    Fenetreajeqag=lookup_widget(objet,"ajeqag");
    gtk_widget_destroy(Fenetreajeqag);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);

}


void
on_radiobutton_hgoaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=1;
}
}


void
on_radiobutton_hgnaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
x=2;
}
}


void
on_checkbutton_hgouiaj_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=1;
}
}


void
on_button_hgcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;

  GtkWidget *Fenetremdfeqag;
  GtkWidget *Fenetrescmdfeq;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *type,*etat_fct;


Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
input1=lookup_widget(objet,"combobox_hgrefmdf");
input2=lookup_widget(objet,"entry_hgmtmdf");
input3=lookup_widget(objet,"entry_hgmrmdf");
input4=lookup_widget(objet,"entry_hgfsmdf");
type=lookup_widget(objet,"combobox_hgtpmdf");
etat_fct=lookup_widget(objet,"combobox_hgefctmdf");
jour=lookup_widget(objet,"spinbutton_hgjdfmdf");
mois=lookup_widget(objet,"spinbutton_hgmdfmdf");
annee=lookup_widget(objet,"spinbutton_hgadfmdf");


strcpy(n.reference,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(n.matricule,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(n.fournisseur,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat_fonctionnement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat_fct)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(a==1)
{strcpy(n.disponibilite,"oui");}
else
if(a==2)
{strcpy(n.disponibilite,"non");}

if(b==1)
{strcpy(n.garantie,"oui");}
else
if(b==0)
{strcpy(n.garantie,"non");}

modifier(n);


    gtk_widget_destroy(Fenetremdfeqag);
    Fenetrescmdfeq=create_scmdfeq();
    gtk_widget_show(Fenetrescmdfeq);
}


void
on_button_hganlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetremdfeqag;
    Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
    gtk_widget_destroy(Fenetremdfeqag);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);
}


void
on_checkbutton_hgouimdf_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
b=1;
}
}


void
on_radiobutton_hgomdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a=1;
}
}


void
on_radiobutton_hgnmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a=2;
}
}


void
on_treeview_hgtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* reference;
	gchar* matricule;
	gchar* type;
	gchar* marque;
	gchar* fournisseur;
	gchar* etat_fct;
	gchar* garantie;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;
	gchar* disponibilite;

	equi_agr n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &reference, 1, &matricule, 2, &type , 3, &marque, 4, &fournisseur, 5, &etat_fct , 6, &garantie , 7, &disponibilite , 8, &jour_fct , 9, &mois_fct , 10, &annee_fct ,-1);
  		strcpy(n.reference,reference);
		strcpy(n.matricule,matricule);
		strcpy(n.type,type);
                strcpy(n.marque,marque);
		strcpy(n.fournisseur,fournisseur);
		strcpy(n.etat_fonctionnement,etat_fct);
                strcpy(n.garantie,garantie);
                strcpy(n.disponibilite,disponibilite);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;


         afficher(treeview);
          }
}


void
on_button_hgretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetrerecheqag;
    Fenetrerecheqag=lookup_widget(objet,"recheqag");
    gtk_widget_destroy(Fenetrerecheqag);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);
}


void
on_button_hgcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerecheqag;
   GtkWidget *ref,*output1,*output2,*crt;
   GtkWidget *treeviewrech;
   char filtre[20];
   char critere[30];
   int t;

Fenetrerecheqag=lookup_widget(objet,"recheqag");
ref=lookup_widget(objet,"entry_hgrefrech");
output1=lookup_widget(objet,"label_hgtxtrech");
output2=lookup_widget(objet,"label_hgaltrech");
treeviewrech=lookup_widget(objet,"treeview_hgtxtrech");
crt=lookup_widget(objet,"combobox_hgcrrech");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(ref)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

t=verifrech(filtre);
if(t!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
filtrecritere(treeviewrech, critere, filtre);
}
}


void
on_button_cnfsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *Fenetrescspeq;
   GtkWidget *ref;
   GtkWidget *output1,*output2,*output3;
   char refsp[20];
   int t;
ref=lookup_widget(objet,"entry_hgrefsupp");
output1=lookup_widget(objet,"label_hgalrsp");
output2=lookup_widget(objet,"label_hgflsp");
output3=lookup_widget(objet,"label_hgcnfsp");

strcpy(refsp,gtk_entry_get_text(GTK_ENTRY(ref)));

t=verif(refsp);
if(t!=1)
{
    gtk_widget_show (output2);
}
else
{
if(z==1)
{
    supprimer(refsp);
    gtk_widget_show (output3);
    gtk_widget_destroy(Fenetresuppeq);
    Fenetrescspeq=create_scspeq();
    gtk_widget_show(Fenetrescspeq);
}


}

}


void
on_button_anlsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetresuppeq;

Fenetresuppeq=lookup_widget(objet,"suppeqag");

    gtk_widget_destroy(Fenetresuppeq);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);
}


void
on_button_hgchmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;
  FILE *f;
  GtkWidget *Fenetremdfeqag;
  GtkWidget *id;
  GtkWidget *output1,*output2;
  

Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
id=lookup_widget(objet,"combobox_hgrefmdf");
output1=lookup_widget(objet,"label_hgchmdf");
output2=lookup_widget(objet,"label_hgsmmdf");

f=fopen("liste_des_equipements_agricoles.txt","r");
while (fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d \n",n.reference,n.matricule,n.type,n.marque,n.fournisseur,n.etat_fonctionnement,n.garantie,n.disponibilite,&n.date_mise_fct.jour,&n.date_mise_fct.mois,&n.date_mise_fct.annee)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(n.reference));
}

fclose(f);

gtk_widget_hide(output2);
gtk_widget_show (output1);
}


void
on_button_hganlchmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetremdfeqag;
  GtkWidget *output1,*output2;

output1=lookup_widget(objet,"label_hgchmdf");
output2=lookup_widget(objet,"label_hgsmmdf");

gtk_widget_hide(output1);
gtk_widget_show (output2);

}


void
on_button_hgvlmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;
  FILE *f;
  GtkWidget *Fenetremdfeqag;
  GtkWidget *id;
  GtkWidget *input2, *input3, *input4;
  GtkWidget *output1,*output2;
    char matricule1[20];
    char marque1[20];
    char fournisseur1[20];
    char ref1[20];
    char type1[20];
  

Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
id=lookup_widget(objet,"combobox_hgrefmdf");
input2=lookup_widget(objet,"entry_hgmtmdf");
input3=lookup_widget(objet,"entry_hgmrmdf");
input4=lookup_widget(objet,"entry_hgfsmdf");
output1=lookup_widget(objet,"label_hgchmdf");
output2=lookup_widget(objet,"label_hgsmmdf");


strcpy(ref1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("liste_des_equipements_agricoles.txt","r");
while (fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d \n",n.reference,n.matricule,n.type,n.marque,n.fournisseur,n.etat_fonctionnement,n.garantie,n.disponibilite,&n.date_mise_fct.jour,&n.date_mise_fct.mois,&n.date_mise_fct.annee)!=EOF)
{
if(strcmp(n.reference,ref1)==0)
{ 
strcpy(matricule1,n.matricule);
strcpy(marque1,n.marque);
strcpy(fournisseur1,n.fournisseur);
}
}
fclose(f);

gtk_entry_set_text(input2,matricule1);
gtk_entry_set_text(input3,marque1);
gtk_entry_set_text(input4,fournisseur1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_radiobutton_hgnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *output1,*output2,*output3;

Fenetresuppeq=lookup_widget(objet,"suppeqag");
output1=lookup_widget(objet,"label_hgalrsp");
output2=lookup_widget(objet,"label_hgflsp");
output3=lookup_widget(objet,"label_hgcnfsp");
z=0;

gtk_widget_hide(output1);
}


void
on_radiobutton_hgosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *output1;
   GtkWidget *ref;

ref=lookup_widget(objet,"entry_hgrefsupp");
Fenetresuppeq=lookup_widget(objet,"suppeqag");
output1=lookup_widget(objet,"label_hgalrsp");
z=1;


    gtk_widget_show (output1);
}


void
on_button_okajeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqagr;
    GtkWidget *Fenetrescajeq;
    GtkWidget *treeview_leqag;
    Fenetrescajeq=lookup_widget(objet,"scajeq");
    gtk_widget_destroy(Fenetrescajeq);
    Fenetregeqagr=create_geqagr();
    gtk_widget_show(Fenetregeqagr);
treeview_leqag=lookup_widget(Fenetregeqagr,"treeview_leqag");

afficher(treeview_leqag);
}


void
on_button_okmdfeq_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqagr;
    GtkWidget *Fenetrescmdfeq;
    GtkWidget *treeview_leqag;
    Fenetrescmdfeq=lookup_widget(objet,"scmdfeq");
    gtk_widget_destroy(Fenetrescmdfeq);
    Fenetregeqagr=create_geqagr();
    gtk_widget_show(Fenetregeqagr);
treeview_leqag=lookup_widget(Fenetregeqagr,"treeview_leqag");

afficher(treeview_leqag);
}


void
on_button_okspeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetregeqagr;
    GtkWidget *Fenetrescspeq;
    GtkWidget *treeview_leqag;
    Fenetrescspeq=lookup_widget(objet,"scspeq");
    gtk_widget_destroy(Fenetrescspeq);
    Fenetregeqagr=create_geqagr();
    gtk_widget_show(Fenetregeqagr);
treeview_leqag=lookup_widget(Fenetregeqagr,"treeview_leqag");

afficher(treeview_leqag);
}

