#include <gtk/gtk.h>


void
on_treeview_leqag_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ajteq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_suppeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_recheq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retgeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hgcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hganlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_hgoaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_hgnaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_hgouiaj_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_hgcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hganlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_hgouimdf_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_hgomdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_hgnmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview_hgtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_hgretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hgcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_cnfsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_anlsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hgchmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hganlchmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hgvlmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_hgnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_hgosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfeq_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okspeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);
