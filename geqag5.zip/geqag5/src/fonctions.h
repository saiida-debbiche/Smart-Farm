#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}date;

typedef struct
{
    char matricule[20];
    char type[20];
    char marque[20];
    char fournisseur[20];
    char garantie[20];
    date date_mise_fct;
    char reference[20];
    char disponibilite[20];
    char etat_fonctionnement[20];
}equi_agr;


void ajouter(equi_agr n);
void afficher(GtkWidget *liste);
void supprimer(char refsp[]);
void modifier(equi_agr n);
void chercher(GtkWidget *liste, char ref[]);
int verif(char ref[]);
void filtrecritere(GtkWidget *liste, char critere[], char filtre[]);
void supprimertree(equi_agr n1);
int verifrech(char crt[]);




