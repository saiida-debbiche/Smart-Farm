#include <gtk/gtk.h>
typedef struct
{
    int jour;
    int mois;
    int annee;
}dtkd;

typedef struct
{
char identifiant[30];
char type[30];
dtkd naissance;
dtkd vaccin;
char genre[30];
char etat[30];
} troupeaux;

void ajoutertrp(troupeaux t );
void affichertrp(GtkWidget *liste);
void cherchertrp(GtkWidget *liste, char idrech[]);
void supprimertrp(char idsp[]);
void modifiertrp(troupeaux n);
int veriftrp(char id[]);
void filtrecriteretrp(GtkWidget *liste, char critere[], char filtre[]);
int verifrechtrp(char crt[]);
void cherchertypetrp(GtkWidget *liste, char typerech[]);
int count(char type[]);

