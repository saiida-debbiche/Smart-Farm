#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "troupeaux.h"
#include <gtk/gtk.h>

enum
{
    EIDENTIFIANT,
    ETYPE,
    EGENRE,
    EETAT_SANITAIRE,
    EJOUR_DN,
    EMOIS_DN,
    EANNEE_DN,
    EJOUR_VC,
    EMOIS_VC,
    EANNEE_VC,
    
    COLUMNS,
};
void ajoutertrp(troupeaux t)
{
FILE*f=NULL; 
f=fopen("liste_troupeaux.txt","a");
fprintf(f,"%s %s %s %s %d %d %d %d %d %d\n",t.identifiant,t.type,t.genre,t.etat,t.naissance.jour,t.naissance.mois,t.naissance.annee,t.vaccin.jour,t.vaccin.mois,t.vaccin.annee);
fclose(f);
}

void affichertrp(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char type[20];
char genre[20];
char etat_sanitaire[20];
char jour_dn[20];
char mois_dn[20];
char annee_dn[20];
char jour_vc[20];
char mois_vc[20];
char annee_vc[20];



store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("genre",renderer,"text",EGENRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("etat_sanitaire",renderer,"text",EETAT_SANITAIRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_dn",renderer,"text",EJOUR_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_dn",renderer,"text",EMOIS_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_dn",renderer,"text",EANNEE_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_vc",renderer,"text",EJOUR_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_vc",renderer,"text",EMOIS_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_vc",renderer,"text",EANNEE_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("liste_troupeaux.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_troupeaux.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",identifiant,type,genre,etat_sanitaire,jour_dn,mois_dn,annee_dn,jour_vc,mois_vc,annee_vc)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

void cherchertrp(GtkWidget *liste, char idrech[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char type[20];
char genre[20];
char etat_sanitaire[20];
char jour_dn[20];
char mois_dn[20];
char annee_dn[20];
char jour_vc[20];
char mois_vc[20];
char annee_vc[20];



store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("genre",renderer,"text",EGENRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("etat_sanitaire",renderer,"text",EETAT_SANITAIRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_dn",renderer,"text",EJOUR_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_dn",renderer,"text",EMOIS_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_dn",renderer,"text",EANNEE_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_vc",renderer,"text",EJOUR_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_vc",renderer,"text",EMOIS_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_vc",renderer,"text",EANNEE_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("liste_troupeaux.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_troupeaux.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",identifiant,type,genre,etat_sanitaire,jour_dn,mois_dn,annee_dn,jour_vc,mois_vc,annee_vc)!=EOF)
		{
                  if(strcmp(identifiant,idrech)==0)
                { 
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
		}
                }
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

void supprimertrp(char idsp[])
{
FILE *f;
FILE *f1;
troupeaux n;
f=fopen("liste_troupeaux.txt","r");
f1=fopen("doc.txt","a+");
while (fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",n.identifiant,n.type,n.genre,n.etat,&n.naissance.jour,&n.naissance.mois,&n.naissance.annee,&n.vaccin.jour,&n.vaccin.mois,&n.vaccin.annee)
!=EOF)
{
	if (strcmp(n.identifiant,idsp)!=0)	
	fprintf(f1,"%s %s %s %s %d %d %d %d %d %d\n",n.identifiant,n.type,n.genre,n.etat,n.naissance.jour,n.naissance.mois,n.naissance.annee,n.vaccin.jour,n.vaccin.mois,n.vaccin.annee);

}
fclose(f);
fclose(f1);
remove("liste_troupeaux.txt");
rename("doc.txt","liste_troupeaux.txt");
}

void modifiertrp(troupeaux n)
{
char id1[20];
char type1[20];
char genre1[20];
char etat_sanitaire1[20];
int jour_dn;
int mois_dn;
int annee_dn;
int jour_vc;
int mois_vc;
int annee_vc;
	

FILE *f;
FILE *f1;

f=fopen("liste_troupeaux.txt","r");
f1=fopen("modif.txt","a+");
while (fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",id1,type1,genre1,etat_sanitaire1,&jour_dn,&mois_dn,&annee_dn,&jour_vc,&mois_vc,&annee_vc)!=EOF)
{
if (strcmp(n.identifiant,id1)==0)
	fprintf(f1,"%s %s %s %s %d %d %d %d %d %d\n",n.identifiant,n.type,n.genre,n.etat,n.naissance.jour,n.naissance.mois,n.naissance.annee,n.vaccin.jour,n.vaccin.mois,n.vaccin.annee);

else
	fprintf(f1,"%s %s %s %s %d %d %d %d %d %d\n",id1,type1,genre1,etat_sanitaire1,jour_dn,mois_dn,annee_dn,jour_vc,mois_vc,annee_vc);
}
fclose(f);
fclose(f1);
remove("liste_troupeaux.txt.txt");
rename("modif.txt","liste_troupeaux.txt");
}

int veriftrp(char id[])
{
    
    FILE *f=NULL;
    troupeaux t;
    int test;
    f=fopen("liste_troupeaux.txt","r");
    test=0;
    if(f!=NULL)
    {
       while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",t.identifiant,t.type,t.genre,t.etat,&t.naissance.jour,&t.naissance.mois,&t.naissance.annee,&t.vaccin.jour,&t.vaccin.mois,&t.vaccin.annee)!=EOF)
       {
         if(strcmp(t.identifiant,id)==0)
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}


void filtrecriteretrp(GtkWidget *liste, char critere[], char filtre[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char type[20];
char genre[20];
char etat_sanitaire[20];
char jour_dn[20];
char mois_dn[20];
char annee_dn[20];
char jour_vc[20];
char mois_vc[20];
char annee_vc[20];



store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("genre",renderer,"text",EGENRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("etat_sanitaire",renderer,"text",EETAT_SANITAIRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_dn",renderer,"text",EJOUR_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_dn",renderer,"text",EMOIS_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_dn",renderer,"text",EANNEE_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_vc",renderer,"text",EJOUR_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_vc",renderer,"text",EMOIS_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_vc",renderer,"text",EANNEE_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("liste_troupeaux.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_troupeaux.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",identifiant,type,genre,etat_sanitaire,jour_dn,mois_dn,annee_dn,jour_vc,mois_vc,annee_vc)!=EOF)
		{
            if(strcmp(critere,"identifiant")==0)
{
         if(strcmp(filtre,identifiant)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
}
}
            if(strcmp(critere,"type")==0)
{
         if(strcmp(filtre,type)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
}
}
            if(strcmp(critere,"genre")==0)
{
         if(strcmp(filtre,genre)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
}
}
            if(strcmp(critere,"etat_sanitaire")==0)
{
         if(strcmp(filtre,etat_sanitaire)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
}
}
            if(strcmp(critere,"annee_naissance")==0)
{
         if(strcmp(filtre,annee_dn)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
}
}
            if(strcmp(critere,"annee_vaccin")==0)
{
         if(strcmp(filtre,annee_vc)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
}
}
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}


int verifrechtrp(char crt[])
{
    
    FILE *f=NULL;
char identifiant[20];
char type[20];
char genre[20];
char etat_sanitaire[20];
char jour_dn[20];
char mois_dn[20];
char annee_dn[20];
char jour_vc[20];
char mois_vc[20];
char annee_vc[20];
    int test;
    f=fopen("liste_troupeaux.txt","r");
    test=0;
    if(f!=NULL)
    {
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",identifiant,type,genre,etat_sanitaire,jour_dn,mois_dn,annee_dn,jour_vc,mois_vc,annee_vc)!=EOF)
       {
         if(strcmp(identifiant,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(type,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(genre,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(etat_sanitaire,crt)==0)
        {
          test=1;
          break;
        }
       if(strcmp(annee_dn,crt)==0)
        {
          test=1;
          break;
        }
       if(strcmp(annee_vc,crt)==0)
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}


int count(char type[])
{
    int nombre=0;

    FILE *f=NULL;
    troupeaux t;
    f=fopen("liste_troupeaux.txt","r");
    if(f!=NULL)
    {
       while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",t.identifiant,t.type,t.genre,t.etat,&t.naissance.jour,&t.naissance.mois,&t.naissance.annee,&t.vaccin.jour,&t.vaccin.mois,&t.vaccin.annee)!=EOF)
       {
         if(strcmp(type,t.type)==0 )
        {
          nombre+=1;

        }

       }
        fclose(f);
        }
    return(nombre);
}

void cherchertypetrp(GtkWidget *liste, char typerech[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char type[20];
char genre[20];
char etat_sanitaire[20];
char jour_dn[20];
char mois_dn[20];
char annee_dn[20];
char jour_vc[20];
char mois_vc[20];
char annee_vc[20];



store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("genre",renderer,"text",EGENRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("etat_sanitaire",renderer,"text",EETAT_SANITAIRE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_dn",renderer,"text",EJOUR_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_dn",renderer,"text",EMOIS_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_dn",renderer,"text",EANNEE_DN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_vc",renderer,"text",EJOUR_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_vc",renderer,"text",EMOIS_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_vc",renderer,"text",EANNEE_VC,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("liste_troupeaux.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_troupeaux.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s\n",identifiant,type,genre,etat_sanitaire,jour_dn,mois_dn,annee_dn,jour_vc,mois_vc,annee_vc)!=EOF)
		{
                  if(strcmp(type,typerech)==0)
                { 
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ETYPE,type,EGENRE,genre,EETAT_SANITAIRE,etat_sanitaire,EJOUR_DN,jour_dn,EMOIS_DN,mois_dn,EANNEE_DN,annee_dn,EJOUR_VC,jour_vc,EMOIS_VC,mois_vc,EANNEE_VC,annee_vc,-1);
		}
                }
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}


