#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}date;

typedef struct
{
    char identifiant[20];
    char val[20];
    date date_fct;

    
}fctcapteur;


void temperature(fctcapteur n);
void humidite(fctcapteur n);
void modifierhmd(fctcapteur n);
void modifiertmp(fctcapteur n);
void affichercapt(GtkWidget *liste);
void affichercaph(GtkWidget *liste);
void rechcapt(GtkWidget *liste, char id[], char moisaff[], char anneeaff[]);
void rechcaph(GtkWidget *liste, char id[], char moisaff[], char anneeaff[]);
void supprimertmp(char idsp[]);
void supprimerhmd(char idsp[]);
int verifdatet(char idfct[], int j, int m, int a);
int verifdateh(char idfct[], int j, int m, int a);
int annee_seche(int tab_an[],float tab_temp[]);
int valeur_max(float tab[],int n);
int val();
void ajoutercapdef(int id,char c[],int t);
int defectueux(int min,int max,int annee,char fichier[],char tab_marque[50][50],int tab_nb[],char type_cap[]);
int  annee_dispo(int tab[],char fichier[]);




