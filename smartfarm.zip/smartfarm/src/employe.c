#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "employe.h"
#include <gtk/gtk.h>

enum
{
    EIDENTIFIANT,
    ENOM,
    EPRENOM,
    EMDP,
    EEMAIL,
    ETEL,
    EJOUR_I,
    EMOIS_I,
    EANNEE_I,
    
    COLUMNS,
};


void ajouter_employe( employe c)
{
FILE*f=NULL;
f=fopen("liste_employes.txt","a+");
fprintf(f,"%s %s %s %s %s %s %d %d %d\n",c.identifiant,c.nom,c.prenom,c.mdp,c.email,c.tel,c.date_ins.jour,c.date_ins.mois,c.date_ins.annee);
fclose(f);
}


int exist_employee(char id[])
{
    FILE *f=NULL;
    employe c;
    int test;
    f=fopen("liste_employes.txt","r");
    test=0;
    if(f!=NULL)
    {
       while(fscanf(f,"%s %s %s %s %s %s %d %d %d\n",c.identifiant,c.nom,c.prenom,c.mdp,c.email,c.tel,&c.date_ins.jour,&c.date_ins.mois,&c.date_ins.annee)!=EOF)
       {
         if(strcmp(c.identifiant,id)==0)
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}

void supprimer_employe(char id[])
{
FILE*f=NULL;
FILE*f1=NULL;
 employe c;
f=fopen("liste_employes.txt","r");

f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %s %s %d %d %d\n",c.identifiant,c.nom,c.prenom,c.mdp,c.email,c.tel,&c.date_ins.jour,&c.date_ins.mois,&c.date_ins.annee)!=EOF)
{
if(strcmp(id,c.identifiant)!=0)
{
fprintf(f1,"%s %s %s %s %s %s %d %d %d\n",c.identifiant,c.nom,c.prenom,c.mdp,c.email,c.tel,c.date_ins.jour,c.date_ins.mois,c.date_ins.annee);

}
}
fclose(f);
fclose(f1);
remove("liste_employes.txt");
rename("ancien.txt","liste_employes.txt");
}

void afficher_employe(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char nom[20];
char prenom[20];
char mdp[20];
char email[50];
char tel[20];
char jour_insription[20];
char mois_insription[20];
char annee_insription[20];


store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mpd",renderer,"text",EMDP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EEMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("tel",renderer,"text",ETEL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	



renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_insription",renderer,"text",EJOUR_I,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_insription",renderer,"text",EMOIS_I,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_insription",renderer,"text",EANNEE_I,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("liste_employes.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("liste_employes.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s  \n",identifiant,nom,prenom,mdp,email,tel,jour_insription,mois_insription,annee_insription)!=EOF)
		{
          

			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,ENOM,nom,EPRENOM,prenom,EMDP,mdp,EEMAIL,email,ETEL,tel,EJOUR_I,jour_insription,EMOIS_I,mois_insription,EANNEE_I,annee_insription,-1);

		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

int verifemp(char log[],char pw[])
{
int trouve=-1;
FILE *f=NULL;
 employe c;
f=fopen("liste_employes.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %d %d %d\n",c.identifiant,c.nom,c.prenom,c.mdp,c.email,c.tel,&c.date_ins.jour,&c.date_ins.mois,&c.date_ins.annee)!=EOF)
{
if((strcmp(c.identifiant,log)==0)&&(strcmp(c.mdp,pw)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}


