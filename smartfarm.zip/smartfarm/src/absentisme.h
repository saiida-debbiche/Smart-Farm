#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}dates;

typedef struct
{
    char identifiant[20];
    int abs;
    dates date_abs;

    
}ouv;


void absentisme(ouv n);
void modifierabs(ouv n);
void afficherabs(GtkWidget *liste);
void rechabs(GtkWidget *liste, char id[], char moisabs[], char anneeabs[]);
void supprimerabs(char idsp[]);
int verifdate(char idabs[], int j, int m, int a);
void taux(float T[],int annee,int nb,char *fichier);
int valeur(char *fichier);
int valeur_min(int tab[],int n);
int meilleur_ouv(int tab_id[],int tab_abs[],int annee);

