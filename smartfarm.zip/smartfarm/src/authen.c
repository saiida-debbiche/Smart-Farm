#include "authen.h"
#include<stdio.h>
#include<string.h>
int verifprop(char log[],char pw[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
f=fopen("proprietaire.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s ",ch1,ch2)!=EOF)
{
if((strcmp(ch1,log)==0)&&(strcmp(ch2,pw)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}

/*int verifemp(char log[],char pw[])
{
int trouve=-1;
FILE *f=NULL;
char ch1[20];
char ch2[20];
f=fopen("employes.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s \n",ch1,ch2)!=EOF)
{
if((strcmp(ch1,log)==0)&&(strcmp(ch2,pw)==0))
trouve=1;
}
fclose(f);
}
return (trouve);
}*/
