#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capteur.h"
#include <gtk/gtk.h>

enum
{
    EIDENTIFIANT,
    EJ,
    EM,
    EA,
    EVAL,
    
    COLUMNS,
};

void temperature(fctcapteur n)
{
 FILE *f;
 f=fopen("temperature.txt","a+");
 if(f!=NULL)
 {
   fprintf(f,"%s %d %d %d %s\n",n.identifiant,n.date_fct.jour,n.date_fct.mois,n.date_fct.annee,n.val);
fclose(f);
}
}

void humidite(fctcapteur n)
{
 FILE *f;
 f=fopen("humidite.txt","a+");
 if(f!=NULL)
 {
   fprintf(f,"%s %d %d %d %s\n",n.identifiant,n.date_fct.jour,n.date_fct.mois,n.date_fct.annee,n.val);
fclose(f);
}
}

void modifiertmp(fctcapteur n)
{
char id1[20];
char val1[20];
    int jda;
    int mda;
    int ada;
    	

FILE *f;
FILE *f1;

f=fopen("temperature.txt","r");
f1=fopen("modif.txt","a+");
while (fscanf(f,"%s %d %d %d %s \n",id1,&jda,&mda,&ada,val1)!=EOF)
{
if ((strcmp(n.identifiant,id1)==0)&&(n.date_fct.jour==jda)&&(n.date_fct.mois==mda)&&(n.date_fct.annee==ada))
	fprintf(f1,"%s %d %d %d %s\n",n.identifiant,n.date_fct.jour,n.date_fct.mois,n.date_fct.annee,n.val);

else
	fprintf(f1,"%s %d %d %d %s\n",id1,jda,mda,ada,val1);

}
fclose(f);
fclose(f1);
remove("temperature.txt");
rename("modif.txt","temperature.txt");
}

void modifierhmd(fctcapteur n)
{
char id1[20];
char val1[20];
    int jda;
    int mda;
    int ada;
    	

FILE *f;
FILE *f1;

f=fopen("humidite.txt","r");
f1=fopen("modif.txt","a+");
while (fscanf(f,"%s %d %d %d %s \n",id1,&jda,&mda,&ada,val1)!=EOF)
{
if ((strcmp(n.identifiant,id1)==0)&&(n.date_fct.jour==jda)&&(n.date_fct.mois==mda)&&(n.date_fct.annee==ada))
	fprintf(f1,"%s %d %d %d %s\n",n.identifiant,n.date_fct.jour,n.date_fct.mois,n.date_fct.annee,n.val);

else
	fprintf(f1,"%s %d %d %d %s\n",id1,jda,mda,ada,val1);

}
fclose(f);
fclose(f1);
remove("humidite.txt");
rename("modif.txt","humidite.txt");
}

void supprimertmp(char idsp[])
{
FILE *f;
FILE *f1;
fctcapteur n;
f=fopen("temperature.txt","r");
f1=fopen("doc.txt","a+");
while (fscanf(f,"%s %d %d %d %s \n",n.identifiant,&n.date_fct.jour,&n.date_fct.mois,&n.date_fct.annee,n.val)!=EOF)
{
	if (strcmp(n.identifiant,idsp)!=0)	
	fprintf(f1,"%s %d %d %d %s\n",n.identifiant,n.date_fct.jour,n.date_fct.mois,n.date_fct.annee,n.val);

}
fclose(f);
fclose(f1);
remove("temperature.txt");
rename("doc.txt","temperature.txt");
}

void supprimerhmd(char idsp[])
{
FILE *f;
FILE *f1;
fctcapteur n;
f=fopen("humidite.txt","r");
f1=fopen("doc.txt","a+");
while (fscanf(f,"%s %d %d %d %s \n",n.identifiant,&n.date_fct.jour,&n.date_fct.mois,&n.date_fct.annee,&n.val)!=EOF)
{
	if (strcmp(n.identifiant,idsp)!=0)	
	fprintf(f1,"%s %d %d %d %s\n",n.identifiant,n.date_fct.jour,n.date_fct.mois,n.date_fct.annee,n.val);

}
fclose(f);
fclose(f1);
remove("humidite.txt");
rename("doc.txt","humidite.txt");
}

void affichercapt(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char jour[20];
char mois[20];
char annee[20];
char val[20];

store =NULL;

FILE *f1;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("val",renderer,"text",EVAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f1=fopen("temperature.txt","r");

	if(f1==NULL)
	{
		return;
	}
	else 
	{ 
	f1=fopen("temperature.txt","a+");
		while(fscanf(f1,"%s %s %s %s %s \n",identifiant,jour,mois,annee,val)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,EJ,jour,EM,mois,EA,annee,EVAL,val,-1);

		}
	   fclose(f1);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	   }
 
}

}

void rechcapt(GtkWidget *liste, char id[], char moisaff[], char anneeaff[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char jour[20];
char mois[20];
char annee[20];
char val[20];

store =NULL;

FILE *f1;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("val",renderer,"text",EVAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f1=fopen("temperature.txt","r");

	if(f1==NULL)
	{
		return;
	}
	else
	
	{ 
	f1=fopen("temperature.txt","a+");
		while(fscanf(f1,"%s %s %s %s %s \n",identifiant,jour,mois,annee,val)!=EOF)
		{
if(strcmp(identifiant,id)==0&&strcmp(mois,moisaff)==0&&strcmp(annee,anneeaff)==0)
{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,EJ,jour,EM,mois,EA,annee,EVAL,val,-1);
}
		}
	   fclose(f1);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	   }
}

}

void affichercaph(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char jour[20];
char mois[20];
char annee[20];
char val[20];

store =NULL;

FILE *f1;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("val",renderer,"text",EVAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f1=fopen("humidite.txt","r");

	if(f1==NULL)
	{
		return;
	}
	else 
	{ 
	f1=fopen("humidite.txt","a+");
		while(fscanf(f1,"%s %s %s %s %s \n",identifiant,jour,mois,annee,val)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,EJ,jour,EM,mois,EA,annee,EVAL,val,-1);

		}
	   fclose(f1);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	   }
 
}

}


void rechcaph(GtkWidget *liste, char id[], char moisaff[], char anneeaff[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char jour[20];
char mois[20];
char annee[20];
char val[20];

store =NULL;

FILE *f1;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("val",renderer,"text",EVAL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f1=fopen("humidite.txt","r");

	if(f1==NULL)
	{
		return;
	}
	else
	
	{ 
	f1=fopen("humidite.txt","a+");
		while(fscanf(f1,"%s %s %s %s %s \n",identifiant,jour,mois,annee,val)!=EOF)
		{
            if(strcmp(identifiant,id)==0&&strcmp(mois,moisaff)==0&&strcmp(annee,anneeaff)==0)
{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,EJ,jour,EM,mois,EA,annee,EVAL,val,-1);
}
		}
	   fclose(f1);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	   }
}

}

int verifdatet(char idfct[], int j, int m, int a)
{
    
    FILE *f=NULL;
fctcapteur n;
    int test;
    f=fopen("temperature.txt","r");
    test=0;
    if(f!=NULL)
    {
       while (fscanf(f,"%s %d %d %d %s \n",n.identifiant,&n.date_fct.jour,&n.date_fct.mois,&n.date_fct.annee,n.val)!=EOF)
       {
         if((strcmp(n.identifiant,idfct)==0) && (n.date_fct.jour==j)&&(n.date_fct.mois==m)&&(n.date_fct.annee==a))
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}


int verifdateh(char idfct[], int j, int m, int a)
{
    
    FILE *f=NULL;
fctcapteur n;
    int test;
    f=fopen("humidite.txt","r");
    test=0;
    if(f!=NULL)
    {
       while (fscanf(f,"%s %d %d %d %s \n",n.identifiant,&n.date_fct.jour,&n.date_fct.mois,&n.date_fct.annee,n.val)!=EOF)
       {
         if((strcmp(n.identifiant,idfct)==0) && (n.date_fct.jour==j)&&(n.date_fct.mois==m)&&(n.date_fct.annee==a))
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}

int annee_seche(int tab_an[],float tab_temp[])
{
    FILE *f;
    int i, n=0;
    int id,j,m,a;
    float temp;
    f=fopen("temperature.txt","r");
    if(f!=NULL)

    {
        while(fscanf(f,"%d %d %d %d %f",&id,&j,&m,&a,&temp)!=EOF)
           {i=0;
        while(a!=tab_an[i]&&i<n)
                        i++;
if (i==n)
{tab_an[i]=a;
       n++; }
   }


n=i;

for(i=0;i<n;i++)
    while(fscanf(f,"%d %d %d %d %f",&id,&j,&m,&a,&temp)!=EOF)
{
    if(tab_an[i]==a)
        tab_temp[i]+=temp/365;
}
    }
return n;
}


int valeur_max(float tab[],int n)
{
    int i,pos;
    float max;
    max=tab[0];
    for(i=1;i<n;i++)
    {
        if(tab[i]>max)
            max=tab[i];
           pos=i;
    }
    return pos;

}


int val()
{
    FILE *f;
    int t=0;
    int id,j,m,a;
char zone[20];
char type[20];
char marque[20];
char etat[20];
    f=fopen("liste_des_capteurs.txt","r");
    if(f!=NULL)
    {
        while(fscanf(f,"%d %s %s %s %s %d %d %d\n",&id,zone,type,marque,etat,&j,&m,&a)!=EOF)
        {
            t++;
        }
    }
    fclose(f);
    return t;
}

void ajoutercapdef(int id,char c[],int t)
{
    FILE *f;
    f=fopen("deffectueuxt.txt","a");
    fprintf(f,"%d %s %d\n",id,c,t);
    fclose(f);
}


int defectueux(int min,int max,int annee,char fichier[],char tab_marque[50][50],int tab_nb[],char type_cap[])
{   
     FILE *f;
    int id,j,m,a;
char zone[20];
char type[20];
char marque[20];
char etat[20];
    int id1,t1,t2,t3;
    float valeur;
    FILE *f1,*f2;
    int i,k,test;
    f=fopen("liste_des_capteurs.txt","r");
    if(f!=NULL)
    { while(fscanf(f,"%d %s %s %s %s %d %d %d  \n",&id,zone,type,marque,etat,&j,&m,&a)!=EOF)
    {
        f1=fopen(fichier,"r");
        if(f1!=NULL)
        {while(fscanf(f1,"%d %d %d %d %f",&id1,&t1,&t2,&t3,&valeur)!=EOF)
        {
        if((valeur>max || valeur <min)&& t3==annee&& id1==id&&strcmp(type,type_cap)==0 )
                   {
               
                           ajoutercapdef(id1,marque,t3);
                          
                    }
        
        }
        }
        fclose(f1);
        }}
fclose(f);
f2=fopen("deffectueuxt.txt","r");
if(f2!=NULL){
fscanf(f2,"%d %s %d\n",&id,marque,&a);
strcpy(tab_marque[0],marque);
    i=1;
        while(fscanf(f2,"%d %s %d\n",&id,marque,&a)!=EOF)
           {test=1;
        for(k=0;k<i;k++)
    {if(strcmp(tab_marque[k],marque)==0)
    {test=0;
    break;}}
if(test)
 {strcpy(tab_marque[i],marque);
          i++;}
}
}
else 
return 0;
rewind(f2);
while(fscanf(f2,"%d %s %d\n",&id,marque,&a)!=EOF)
{for(k=0;k<i;k++)
{if(strcmp(tab_marque[k],marque)==0)
tab_nb[k]++;
}
}
fclose(f2);
return i;

}
int  annee_dispo(int tab[],char fichier[])
{int id,j,m,an,i;
float valeur;
FILE *f =fopen(fichier,"r");
if(f!=NULL)
{fscanf(f,"%d %d %d %d %f",&id,&j,&m,&an,&valeur);
tab[0]=an;
i=1;
while(fscanf(f,"%d %d %d %d %f",&id,&j,&m,&an,&valeur)!=EOF)
{if (an!=tab[i-1])
{tab[i]=an;
i++;}
}
}
return i;
fclose(f);}
int max_tab_nb(int tab_nb[],int n)
{
int max,i,p;
max=tab_nb[0];
for(i=0;i<n;i++)
{if(tab_nb[i]>max)
{max=tab_nb[i];
p=i;}
}
return p;}


