#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "plantation.h"
#include <gtk/gtk.h>


enum
{
    EID,
    ENOM,
    ETYPE,
    EQUA,
    EJOUR_pl,
    EMOIS_pl,
    EANNEE_pl,
    EJOUR_ir,
    EMOIS_ir,
    EANNEE_ir,
    ETEM,
    EHUM,
    EZONE,
    COLUMNS,
};


void ajouterpl(plantation n)
{

 FILE *f;
 f=fopen("plantation.txt","a+");
 if(f!=NULL)
 {
 fprintf(f,"%s %s %s %s %d %d %d %d %d %d %s %s %s\n",n.identifiant,n.nom,n.type,n.quantite,n.date_plantation.jour,n.date_plantation.mois,n.date_plantation.annee,n.date_irrigation.jour,n.date_irrigation.mois,n.date_irrigation.annee,n.temperature,n.humidite,n.zone);

 fclose(f);
 }

}

void afficherpl(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char nom[20];
char type[20];
char quantite[20];
char jour_pl[20];
char mois_pl[20];
char annee_pl[20];
char jour_ir[20];
char mois_ir[20];
char annee_ir[20];;
char temperature[20];
char humidite[20];
char zone[20];


store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_pl",renderer,"text",EJOUR_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_pl",renderer,"text",EMOIS_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_pl",renderer,"text",EANNEE_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_ir",renderer,"text",EJOUR_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_ir",renderer,"text",EMOIS_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_ir",renderer,"text",EANNEE_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("temperature",renderer,"text",ETEM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("humidite",renderer,"text",EHUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("zone",renderer,"text",EZONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,
G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("plantation.txt","r");

	if(f==NULL)
	{
		return;
	}
	else

	{ 
	f=fopen("plantation.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s \n",identifiant,nom,type,quantite,jour_pl,mois_pl,annee_pl,jour_ir,mois_ir,annee_ir,temperature,humidite,zone)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}


void modifierpl(plantation n)
{
   char identifiant1[20];
   char nom1[20];
   char type1[20];
   char quantite1[20];
   int jpl;
   int mpl;
   int apl;
   int jir;
   int mir;
   int air;
   char temperature1[20];
   char humidite1[20];
   char zone1[20];   
	

FILE *f;
FILE *f1;

f=fopen("plantation.txt","r");
f1=fopen("modif.txt","a+");
while (fscanf(f,"%s %s %s %s %d %d %d %d %d %d %s %s %s \n",identifiant1,nom1,type1,quantite1,&jpl,&mpl,&apl,&jir,&mir,&air,temperature1,humidite1,zone1)!=EOF)
{
if (strcmp(n.identifiant,identifiant1)==0)
	fprintf(f1,"%s %s %s %s %d %d %d %d %d %d %s %s %s  \n",n.identifiant,n.nom,n.type,n.quantite,n.date_plantation.jour,n.date_plantation.mois,n.date_plantation.annee,n.date_irrigation.jour,n.date_irrigation.mois,n.date_irrigation.annee,n.temperature,n.humidite,n.zone);

else
	fprintf(f1,"%s %s %s %s %d %d %d %d %d %d %s %s %s  \n",identifiant1,nom1,type1,quantite1,jpl,mpl,apl,jir,mir,air,temperature1,humidite1,zone1);

}
fclose(f);
fclose(f1);
remove("plantation.txt");
rename("modif.txt","plantation.txt");
}

void supprimerpl(char idsup[])
{
FILE *f;
FILE *f1;
plantation n;
f=fopen("plantation.txt","r");
f1=fopen("doc.txt","a+");
while (fscanf(f,"%s %s %s %s %d %d %d %d %d %d %s %s %s \n",n.identifiant,n.nom,n.type,n.quantite,&n.date_plantation.jour,&n.date_plantation.mois,&n.date_plantation.annee,&n.date_irrigation.jour,&n.date_irrigation.mois,&n.date_irrigation.annee,n.temperature,n.humidite,n.zone)!=EOF)
{
	if (strcmp(n.identifiant,idsup)!=0)	
	fprintf(f1,"%s %s %s %s %d %d %d %d %d %d %s %s %s \n",n.identifiant,n.nom,n.type,n.quantite,n.date_plantation.jour,n.date_plantation.mois,n.date_plantation.annee,n.date_irrigation.jour,n.date_irrigation.mois,n.date_irrigation.annee,n.temperature,n.humidite,n.zone);

}
fclose(f);
fclose(f1);
remove("plantation.txt");
rename("doc.txt","plantation.txt");
}


void chercherpl(GtkWidget *liste , char annee[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char nom[20];
char type[20];
char quantite[20];
char jour_pl[20];
char mois_pl[20];
char annee_pl[20];
char jour_ir[20];
char mois_ir[20];
char annee_ir[20];
char temperature[20];
char humidite[20];
char zone[20];   

store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_pl",renderer,"text",EJOUR_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_pl",renderer,"text",EMOIS_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_pl",renderer,"text",EANNEE_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_ir",renderer,"text",EJOUR_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_ir",renderer,"text",EMOIS_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_ir",renderer,"text",EANNEE_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("temperature",renderer,"text",ETEM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("humidite",renderer,"text",EHUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("zone",renderer,"text",EZONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,
G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING); 


	f=fopen("plantation.txt","r");    

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("plantation.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s \n",identifiant,nom,type,quantite,jour_pl,mois_pl,annee_pl,jour_ir,mois_ir,annee_ir,temperature,humidite,zone)!=EOF)
		{
                  if(strcmp(annee_pl,annee)==0)
                {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
		}
                }
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}



int verifpl(char id[])
{
    
    FILE *f=NULL;
    plantation n;
    int test;
    f=fopen("plantation.txt","r");
    test=0;
    if(f!=NULL)
    {

        while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d %s %s %s \n",n.identifiant,n.nom,n.type,n.quantite,&n.date_plantation.jour,&n.date_plantation.mois,&n.date_plantation.annee,&n.date_irrigation.jour,&n.date_irrigation.mois,&n.date_irrigation.annee,n.temperature,n.humidite,n.zone)!=EOF)
       {
         if(strcmp(n.identifiant,id)==0)
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}


void filtrecriterepl(GtkWidget *liste, char critere[], char filtre[])
{
    
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char nom[20];
char type[20];
char quantite[20];
char jour_pl[20];
char mois_pl[20];
char annee_pl[20];
char jour_ir[20];
char mois_ir[20];
char annee_ir[20];
char temperature[20];
char humidite[20];
char zone[20]; 

store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",EQUA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	


renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_pl",renderer,"text",EJOUR_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_pl",renderer,"text",EMOIS_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_pl",renderer,"text",EANNEE_pl,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour_ir",renderer,"text",EJOUR_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois_ir",renderer,"text",EMOIS_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee_ir",renderer,"text",EANNEE_ir,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("temperature",renderer,"text",ETEM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("humidite",renderer,"text",EHUM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("zone",renderer,"text",EZONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,
G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING); 

f=fopen("plantation.txt","r");    

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("plantation.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s \n",identifiant,nom,type,quantite,jour_pl,mois_pl,annee_pl,jour_ir,mois_ir,annee_ir,temperature,humidite,zone)!=EOF)
		{
            if(strcmp(critere,"identifiant")==0)
{
         if(strcmp(filtre,identifiant)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
}
}
            if(strcmp(critere,"nom")==0)
{
         if(strcmp(filtre,nom)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
}
}
            if(strcmp(critere,"periode_plantation")==0)
{
         if(strcmp(filtre,annee_pl)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
}
}
            if(strcmp(critere,"quantite")==0)
{
         if(strcmp(filtre,quantite)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
}
}
            if(strcmp(critere,"zone")==0)
{
         if(strcmp(filtre,zone)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
}
}
            if(strcmp(critere,"periode_irrigation")==0)
{
         if(strcmp(filtre,annee_ir)==0)
      {
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EID,identifiant,ENOM,nom,ETYPE,type,EQUA,quantite,EJOUR_pl,jour_pl,EMOIS_pl,mois_pl,EANNEE_pl,annee_pl,    EJOUR_ir,jour_ir,EMOIS_ir,mois_ir,EANNEE_ir,annee_ir,ETEM,temperature,EHUM,humidite,EZONE,zone,-1);
}
}
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
}
}

int verifrechpl(char crt[])
{
    
    FILE *f=NULL;
char identifiant[20];
char nom[20];
char type[20];
char quantite[20];
char jour_pl[20];
char mois_pl[20];
char annee_pl[20];
char jour_ir[20];
char mois_ir[20];
char annee_ir[20];
char temperature[20];
char humidite[20];
char zone[20]; 

    int test;
    f=fopen("plantation.txt","r");
    test=0;
    if(f!=NULL)
    {
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s \n",identifiant,nom,type,quantite,jour_pl,mois_pl,annee_pl,jour_ir,mois_ir,annee_ir,temperature,humidite,zone)!=EOF)
       {
         if(strcmp(identifiant,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(nom,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(quantite,crt)==0)
        {
          test=1;
          break;
        }
        if(strcmp(annee_pl,crt)==0)
        {
          test=1;
          break;
        }
       if(strcmp(annee_ir,crt)==0)
        {
          test=1;
          break;
        }
       if(strcmp(zone,crt)==0)
        {
          test=1;
          break;
        }
       }
     fclose(f);
     }
return(test);
}





