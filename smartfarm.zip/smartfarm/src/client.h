#ifndef HEADER_H
#define HEADER_H
#include <string.h>
#include <gtk/gtk.h>
typedef struct
{
int j;
int m;
int a;
}datecl;

typedef struct
{
char id[20];
char prenom[30];
char nom[30];
char sexe[20];
char numtel[20];
char email[40];
char fidelite[20];
datecl da;
datecl dn;
}client;

void ajoutercl(client c);
void supprimercl(char idsp[]);
void recherchercl(GtkWidget *liste,char idrech[]);
void modifiercl(client c);
void affichercl(GtkWidget *liste);
int verifcl(char id[]);
void filtrecriterecl(GtkWidget *liste, char critere[], char filtre[]);
int verifrechcl(char crt[]);


#endif // HEADER_H
