#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}datefcteq;

typedef struct
{
    char matricule[20];
    char type[20];
    char marque[20];
    char fournisseur[20];
    char garantie[20];
    datefcteq date_mise_fct;
    char reference[20];
    char disponibilite[20];
    char etat_fonctionnement[20];
}equi_agr;


void ajoutereq(equi_agr n);
void affichereq(GtkWidget *liste);
void supprimereq(char refsp[]);
void modifiereq(equi_agr n);
void cherchereq(GtkWidget *liste, char ref[]);
int verifeq(char ref[]);
void filtrecritereeq(GtkWidget *liste, char critere[], char filtre[]);
void supprimertreeeq(equi_agr n1);
int verifrecheq(char crt[]);




