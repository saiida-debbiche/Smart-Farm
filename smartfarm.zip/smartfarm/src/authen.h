int verifprop(char log[],char pw[]);
//int verifemp(char log[],char pw[]);

