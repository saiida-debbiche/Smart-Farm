#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}datecplv;

typedef struct
{
    char identifiant[20];
    char nom[20];
    char type[20];
    char quantite[20];
    datecplv date_plantation;
    datecplv date_irrigation;
    char temperature[20];
    char humidite[20];
    char zone[20];
}plantation;


void ajouterpl(plantation n);
void afficherpl(GtkWidget *liste);
void supprimerpl(char idsup[]);
void modifierpl(plantation n);
void chercherpl(GtkWidget *liste , char annee[]);
int verifpl(char id[]);
void filtrecriterepl(GtkWidget *liste, char critere[], char filtre[]);
int verifrechpl(char crt[]);


