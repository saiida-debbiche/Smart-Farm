#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}dtn;

typedef struct
{
    char identifiant[20];
    char nom[20];
    char prenom[20];
    char sexe[20];
    dtn date_naissance;
    char ss[20];
    char tache[30];
    
}ouvrier;


void ajouterouv(ouvrier n);
void afficherouv(GtkWidget *liste);
void supprimerouv(char idsp[]);
void modifierouv(ouvrier n);
void chercherouv(GtkWidget *liste, char id[]);
int verifouv(char id[]);
void filtrecritereouv(GtkWidget *liste, char critere[], char filtre[]);
int verifrechouv(char crt[]);


