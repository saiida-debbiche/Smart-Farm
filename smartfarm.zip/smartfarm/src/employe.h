#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}dtis;

typedef struct
{
    char nom[20];
    char prenom[20];
    char identifiant[20];
    char mdp[20];
    char email[50];
    char tel[20];
    
    dtis date_ins;

    
}employe;

void ajouter_employe( employe c);
int exist_employee(char id[]);
void supprimer_employe(char id[]);
void afficher_employe(GtkWidget *liste);
int verifemp(char log[],char pw[]);


