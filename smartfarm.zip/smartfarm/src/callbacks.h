#include <gtk/gtk.h>


void
on_button_cnxemp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retlgemp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_decemp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retespemp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_geq_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gplv_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gcap_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gouv_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gcl_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_gtoup_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_acprop_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_acemp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retespprop_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_cnfajemp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rcdnemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_cnfmdfemp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_chidemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_listemploye_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_afflemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nonspemp_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_ouispemp_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_spemp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_affmouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afftabs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affcapalr_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_capalrt_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_capalrh_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_capdeft_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_capdefh_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_affcapdef_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_affnbrtrp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affansc_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_affansc_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_retcnxpro_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_cnxprop_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfemp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okspemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okspcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ok_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msretfct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mscnffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msmdffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msspfcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msafffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mstfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mshfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mschidfct_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_mscapfct_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_mscnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_msosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_msnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_mstxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_mscnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mscnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_msofctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_msnfctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mschidmdf_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mshmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mscnfidmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msanlidmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mstmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mscnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mstajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mshaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_msofctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_msnfctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_ajtcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_suppcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retgcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_msfctcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_lcap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_affcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajtcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_suppcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retgcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_lcl_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_nmcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nmmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_nmfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_nmfdajt_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_nmcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_nmfdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_nmmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_nmfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_nmvldch_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmchidmdf_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_nmtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_nmcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmanlrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nmcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nmnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_nmosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfclt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_scspclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajteq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_suppeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_recheq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_leqag_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_retgeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hgcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hganlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_hgoaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_hgnaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_hgouiaj_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_hgcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hganlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_hgouimdf_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_hgomdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_hgnmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_hgvlmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hganlchmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hgchmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_hgtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_hgretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_hgcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_cnfsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_anlsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_hgosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_hgnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfeq_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okspeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajtouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_suppouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbabs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_louv_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_mbcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mbfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mbmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mbcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mbmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_mbfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mbvldchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_mbtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_mbretabs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_mbabs_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_mbtabs_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbcnfabs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbmdfabs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbspabs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_mboabs_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_mbchidabs_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mbanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mbnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_mbosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfouv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okspouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_lplv_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_retplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rechplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afflplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdfplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_spplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_sdzaaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzbaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzcaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzdaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_sdcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton_sdzamdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzbmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzcmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sdzdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_sdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdvlchid_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_sdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_sdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_rechplv_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_sdidrech_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_sdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okajplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdfplv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okspplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajtrp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mdftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdgrch_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retgtrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_ltrp_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_kdmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_kdfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_kdanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_kdmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_kdfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_kdvldchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_kdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_kdtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_kdcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_khcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_khanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_kdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_kdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okscajtrp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_okmdftrp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_oksptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_lcapdef_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ouispfctcap_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nonspfctcap_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ouispabsouv_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_nonspabsouv_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);
