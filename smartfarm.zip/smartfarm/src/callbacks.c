#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteurs.h"
#include "capteur.h"
#include "absentisme.h"
#include "ouvrier.h"
#include "troupeaux.h"
#include "authen.h"
#include "employe.h"
#include "plantation.h"
#include "client.h"
#include "equipement.h"

int a,b,d,e,g,i,j,p,q,s,t,u,v,x,y,z;
int A,B,C,D,E,F;
int l=0;
int m=0;
int f=0;
int o=0;
int w=0;
int tab_an[100];
float tab_temp[100]={0};
int T1[2]={0,0};
int T2[2]={0,0};
char idcap[20];
char idouv[20];
void
on_button_cnxemp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrelogin;
    GtkWidget *Fenetrebienvenue;
    GtkWidget *id,*mdp,*output;
    char identifiant[20];
    char pw[20];
    int v;

    Fenetrelogin=lookup_widget(objet,"login");
id=lookup_widget(objet,"entry_idemp");
mdp=lookup_widget(objet,"entry_mdpemp");
output=lookup_widget(objet,"label_altcnxemp");

strcpy(identifiant,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(pw,gtk_entry_get_text(GTK_ENTRY(mdp)));
v=verifemp(identifiant,pw);

if(v!=1)
{
gtk_widget_show (output);
}
else
{
    gtk_widget_destroy(Fenetrelogin);
    Fenetrebienvenue=create_bienvenue();
    gtk_widget_show(Fenetrebienvenue);
}
}


void
on_button_retlgemp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrelogin;
    GtkWidget *FenetrereAuthen;
    Fenetrelogin=lookup_widget(objet,"login");
    gtk_widget_destroy(Fenetrelogin);
    FenetrereAuthen=create_Authen();
    gtk_widget_show(FenetrereAuthen);
}


void
on_button_decemp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrelogin;
    GtkWidget *Fenetrerebienvenue;
    Fenetrerebienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(Fenetrerebienvenue);
    Fenetrelogin=create_login();
    gtk_widget_show(Fenetrelogin);
}


void
on_button_retespemp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrerebienvenue;
    GtkWidget *FenetrereAuthen;
    Fenetrerebienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(Fenetrerebienvenue);
    FenetrereAuthen=create_Authen();
    gtk_widget_show(FenetrereAuthen);
}


void
on_button_geq_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *bienvenue;
    GtkWidget *Fenetreregeqagr;
    bienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(bienvenue);
    Fenetreregeqagr=create_geqagr();
    gtk_widget_show(Fenetreregeqagr);
}


void
on_button_gplv_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *bienvenue;
    GtkWidget *Fenetreregpl;
    bienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(bienvenue);
    Fenetreregpl=create_gpl();
    gtk_widget_show(Fenetreregpl);
}


void
on_button_gcap_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *bienvenue;
    GtkWidget *Fenetreregcap;
    bienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(bienvenue);
    Fenetreregcap=create_gcap();
    gtk_widget_show(Fenetreregcap);
}


void
on_button_gouv_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *bienvenue;
    GtkWidget *Fenetreregouv;
    bienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(bienvenue);
    Fenetreregouv=create_gouv();
    gtk_widget_show(Fenetreregouv);
}


void
on_button_gcl_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *bienvenue;
    GtkWidget *Fenetreregclt;
    bienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(bienvenue);
    Fenetreregclt=create_gclt();
    gtk_widget_show(Fenetreregclt);
}


void
on_button_gtoup_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *bienvenue;
    GtkWidget *Fenetreregtroup;
    bienvenue=lookup_widget(objet,"bienvenue");
    gtk_widget_destroy(bienvenue);
    Fenetreregtroup=create_gtroup();
    gtk_widget_show(Fenetreregtroup);
}


void
on_button_acprop_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrelogin2;
    GtkWidget *FenetrereAuthen;
    FenetrereAuthen=lookup_widget(objet,"Authen");
    gtk_widget_destroy(FenetrereAuthen);
    Fenetrelogin2=create_login2();
    gtk_widget_show(Fenetrelogin2);
}


void
on_button_acemp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrelogin;
    GtkWidget *FenetrereAuthen;
    FenetrereAuthen=lookup_widget(objet,"Authen");
    gtk_widget_destroy(FenetrereAuthen);
    Fenetrelogin=create_login();
    gtk_widget_show(Fenetrelogin);
}


void
on_button_retespprop_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregprop;
    GtkWidget *FenetrereAuthen;
    Fenetregprop=lookup_widget(objet,"Esp_prop");
    gtk_widget_destroy(Fenetregprop);
    FenetrereAuthen=create_Authen();
    gtk_widget_show(FenetrereAuthen);
}


void
on_button_cnfajemp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
employe c;
GtkWidget *Espprop;
GtkWidget *Fenetrescajemp;
GtkWidget *id,*nom,*prenom,*mdp,*email,*tel,*jour,*mois,*annee;
GtkWidget *output1,*output2,*output3,*output4,*output5,*output6,*output7;
int b=1,v;
char idaj[20];

Espprop=lookup_widget(objet,"Esp_prop");
id=lookup_widget(objet,"entry_idemp");
nom=lookup_widget(objet,"entry_nomemp");
prenom=lookup_widget(objet,"entry_preemp");
mdp=lookup_widget(objet,"entry_mdpemp");
email=lookup_widget(objet,"entry_memp");
tel=lookup_widget(objet,"entry_telemp");
jour=lookup_widget(objet,"spinbutton_jinsemp");
mois=lookup_widget(objet,"spinbutton_minsemp");
annee=lookup_widget(objet,"spinbutton_ainsemp");
output1=lookup_widget(objet,"label_sidemp");
output2=lookup_widget(objet,"label_snomemp");
output3=lookup_widget(objet,"label_spremp");
output4=lookup_widget(objet,"label_smdpemp");
output5=lookup_widget(objet,"label_saeemp");
output6=lookup_widget(objet,"label_snumemp");
output7=lookup_widget(objet,"label_altemp");

strcpy(idaj,gtk_entry_get_text(GTK_ENTRY(id) ) );
strcpy(c.identifiant,gtk_entry_get_text(GTK_ENTRY(id) ) );
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(nom) ) );
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(prenom) ) );
strcpy(c.mdp,gtk_entry_get_text(GTK_ENTRY(mdp) ) );
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(email) ) );
strcpy(c.tel,gtk_entry_get_text(GTK_ENTRY(tel) ) );
c.date_ins.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
c.date_ins.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c.date_ins.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

if(strcmp(c.identifiant,"")==0){
		  gtk_widget_show (output1);
b=0;
}
else {
		  gtk_widget_hide(output1);
}

if(strcmp(c.nom,"")==0){
		  gtk_widget_show (output2);
b=0;
}
else {
		  gtk_widget_hide(output2);
}
if(strcmp(c.prenom,"")==0){
		  gtk_widget_show (output3);
b=0;
}
else {
		  gtk_widget_hide(output3);
}
if(strcmp(c.mdp,"")==0){
		  gtk_widget_show (output4);
b=0;
}
else {
		  gtk_widget_hide(output4);
}
if(strcmp(c.email,"")==0){
		  gtk_widget_show (output5);
b=0;
}
else {
		  gtk_widget_hide(output5);
}
if(strcmp(c.tel,"")==0){
		  gtk_widget_show (output6);
b=0;
}
else {
		  gtk_widget_hide(output6);
}

v=exist_employee(idaj);
if (v==1)
{
gtk_widget_show (output7);
}
else
{
  if(b==1)
{
ajouter_employe(c);
    gtk_widget_destroy(Espprop);
    Fenetrescajemp=create_scajemp();
    gtk_widget_show(Fenetrescajemp);
}
}
}


void
on_button_rcdnemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  employe c;
  FILE *f;
  GtkWidget *Fenetregprop;
  GtkWidget *id;
  GtkWidget *input1, *input2, *input3, *input4, *input5;
    char nom1[20];
    char prenom1[20];
    char mdp1[20];
    char email1[50];
    char tel1[20];
    char id1[20];
  

Fenetregprop=lookup_widget(objet,"Esp_prop");
id=lookup_widget(objet,"combobox_idmdf");
input1=lookup_widget(objet,"entry_nommdf");
input2=lookup_widget(objet,"entry_premdf");
input3=lookup_widget(objet,"entry_mdpmdf");
input4=lookup_widget(objet,"entry_aemdf");
input5=lookup_widget(objet,"entry_nummdf");


strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("liste_employes.txt","r");
      while(fscanf(f,"%s %s %s %s %s %s %d %d %d\n",c.identifiant,c.nom,c.prenom,c.mdp,c.email,c.tel,&c.date_ins.jour,&c.date_ins.mois,&c.date_ins.annee)!=EOF)
{
if(strcmp(c.identifiant,id1)==0)
{ 
strcpy(nom1,c.nom);
strcpy(prenom1,c.prenom);
strcpy(mdp1,c.mdp);
strcpy(email1,c.email);
strcpy(tel1,c.tel);
}
}
fclose(f);

gtk_entry_set_text(input1,nom1);
gtk_entry_set_text(input2,prenom1);
gtk_entry_set_text(input3,mdp1);
gtk_entry_set_text(input4,email1);
gtk_entry_set_text(input5,tel1);

}


void
on_button_cnfmdfemp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
employe c;
GtkWidget *Espprop;
GtkWidget *Fenetrescmdfemp;
GtkWidget *id,*nom,*prenom,*mdp,*email,*tel,*jour,*mois,*annee;
char idmdf[20];
Espprop=lookup_widget(objet,"Esp_prop");
id=lookup_widget(objet,"combobox_idmdf");
nom=lookup_widget(objet,"entry_nommdf");
prenom=lookup_widget(objet,"entry_premdf");
mdp=lookup_widget(objet,"entry_mdpmdf");
email=lookup_widget(objet,"entry_aemdf");
tel=lookup_widget(objet,"entry_nummdf");
jour=lookup_widget(objet,"spinbutton_jimdf");
mois=lookup_widget(objet,"spinbutton_mimdf");
annee=lookup_widget(objet,"spinbutton_aimdf");

strcpy(idmdf,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id) ) );
strcpy(c.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id) ) );
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(nom) ) );
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(prenom) ) );
strcpy(c.mdp,gtk_entry_get_text(GTK_ENTRY(mdp) ) );
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(email) ) );
strcpy(c.tel,gtk_entry_get_text(GTK_ENTRY(tel) ) );
c.date_ins.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
c.date_ins.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c.date_ins.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

supprimer_employe(idmdf);
ajouter_employe(c);

    gtk_widget_destroy(Espprop);
    Fenetrescmdfemp=create_scmdfemp();
    gtk_widget_show(Fenetrescmdfemp);
}


void
on_button_chidemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  employe c;
  FILE *f;
  GtkWidget *Fenetregprop;
  GtkWidget *id;
  

Fenetregprop=lookup_widget(objet,"Esp_prop");
id=lookup_widget(objet,"combobox_idmdf");

f=fopen("liste_employes.txt","r");
      while(fscanf(f,"%s %s %s %s %s %s %d %d %d\n",c.identifiant,c.nom,c.prenom,c.mdp,c.email,c.tel,&c.date_ins.jour,&c.date_ins.mois,&c.date_ins.annee)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(c.identifiant));
}

fclose(f);
}


void
on_treeview_listemploye_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button_afflemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregprop;
    GtkWidget *treeview_lemp,*aff;
   

Fenetregprop=lookup_widget(objet,"Esp_prop");
treeview_lemp=lookup_widget(Fenetregprop,"treeview_listemploye");
aff=lookup_widget(Fenetregprop,"scrolledwindow_lemp");

gtk_widget_show (aff);
afficher_employe(treeview_lemp);
}


void
on_radiobutton_nonspemp_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *output1;

Fenetresuppeq=lookup_widget(objet,"Esp_prop");
output1=lookup_widget(objet,"label_msgspemp");

z=0;

gtk_widget_hide(output1);
}


void
on_radiobutton_ouispemp_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *output1;

Fenetresuppeq=lookup_widget(objet,"Esp_prop");
output1=lookup_widget(objet,"label_msgspemp");
z=1;


    gtk_widget_show (output1);
}


void
on_button_spemp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetregprop;
   GtkWidget *Fenetrescspemp;
   GtkWidget *id;
   GtkWidget *output1,*output2;
   char idsp[20];
   int t;
Fenetregprop=lookup_widget(objet,"Esp_prop");
id=lookup_widget(objet,"entry_spidemp");
output1=lookup_widget(objet,"label_msgspemp");
output2=lookup_widget(objet,"label_altspemp");

strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));

t=exist_employee(idsp);
if(t!=1)
{
    gtk_widget_show (output2);
}
else
{
if(z==1)
{
supprimer_employe(idsp);
    gtk_widget_destroy(Fenetregprop);
    Fenetrescspemp=create_scspemp();
    gtk_widget_show(Fenetrescspemp);
}
}
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* prenom;
	gchar* sexe;
	gchar* tache;
	gchar* securite_sociale;
	gchar* jour_dn;
        gchar* mois_dn;
        gchar* annee_dn;

	ouvrier n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &prenom , 3, &sexe, 4, &tache, 5, &securite_sociale , 6, &jour_dn , 7, &mois_dn , 8, &annee_dn ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.prenom,prenom);
                strcpy(n.sexe,sexe);
		strcpy(n.tache,tache);
		strcpy(n.ss,securite_sociale);
                n.date_naissance.jour=jour_dn;
                n.date_naissance.mois=mois_dn;
                n.date_naissance.annee=annee_dn;
                
                
                afficherouv(treeview);
}
}


void
on_button_affmouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetregprop;
  GtkWidget *output,*input;
  GtkWidget *treeview;
int annee,n=0;
char idmouv[20];

    FILE *f;
 

Fenetregprop=lookup_widget(objet,"Esp_prop");
output=lookup_widget(objet,"label_affichagemouvann");
input=lookup_widget(objet,"spinbutton_chamouv");
treeview=lookup_widget(objet,"treeview2");
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input));

int tab_id[100],tab_abs[100]={0};
char texte[100]="";
n=meilleur_ouv(tab_id,tab_abs,annee);

sprintf(texte,"Le meilleur ouvrier est celui ayant l'id %d",tab_id[valeur_min(tab_abs,n)]);
sprintf(idmouv,"%d",tab_id[valeur_min(tab_abs,n)]);
gtk_label_set_text(GTK_LABEL(output),texte);
chercherouv(treeview,idmouv);
gtk_widget_show(treeview);
}


void
on_button_afftabs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *entryaouvta;
GtkWidget *labeltauxabsafta;
GtkWidget *windowtauxabsta;


int i;
int annee,nb;
float Tab[50],T[50],x;
char s1[20],s2[20],s3[20],s4[300];
windowtauxabsta=lookup_widget(objet,"Esp_prop");

labeltauxabsafta=lookup_widget(objet,"label_tabsaff");
entryaouvta=lookup_widget(objet,"spinbutton_chantabs");
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryaouvta));

nb=valeur("liste_des_ouvriers.txt");
taux(T,annee,nb,"tableau_absentisme.txt");

strcpy(s4,"");
for(i=1;i<13;i++)
{
x=T[i];
sprintf(s1, "%d", i);
sprintf(s2, "%.3f", x);
strcpy(s3,"TauxMois[");
strcat(s3,s1);
strcat(s3,"]= ");
strcat(s3,s2);
strcat(s3,"%\n");
strcat(s4,s3);
}
gtk_label_set_text(GTK_LABEL(labeltauxabsafta),s4);
}


void
on_button_affcapalr_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
if(a==1)
{
int max1,min1,max2,min2;
int id ,n=0 ,i, j , a,mo,nt,ct [50];
float val;
char texte [200]="";
GtkWidget *output;
GtkWidget *mn1, *mx1,*mn2, *mx2;

mn1=lookup_widget(objet, "spinbutton_min1");
mn2=lookup_widget(objet, "spinbutton_min2");
mx1=lookup_widget(objet, "spinbutton_max1");
mx2=lookup_widget(objet, "spinbutton_max2");

min1= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mn1));
min2= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mn2));
max1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mx1));
max2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mx2));

FILE *f; 
f= fopen ("temperature.txt","r");
if (f!=NULL) {
while(fscanf (f,"%d %d %d %d %f",&id,&j,&mo ,&a, &val)!=EOF){
	if ((val<max1 && val>min1)||(val<max2 && val>min2)) {
		i =0;
while ((i <n) && (ct[i]!=id ))
i++;
if (i==n) {ct[i]=id ; n++ ;}} }
sprintf (texte," %d capteurs de temperature alarmentes ",n);
output=lookup_widget(objet,("label_affcapalrs"));
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
return (n);}
}
else
if(a==2)
{
float max1,min1,max2,min2;
int id ,n=0 ,i, j , a,mo,nh,ch [50];
float val;
char texte [200]="";
GtkWidget *output;
GtkWidget *mn1, *mx1,*mn2, *mx2;

mn1=lookup_widget(objet, "spinbutton_min1");
mn2=lookup_widget(objet, "spinbutton_min2");
mx1=lookup_widget(objet, "spinbutton_max1");
mx2=lookup_widget(objet, "spinbutton_max2");

min1= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mn1));
min2= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mn2));
max1 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mx1));
max2 = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mx2));
FILE *f; 
f= fopen ("humidite.txt","r");
if (f!=NULL) {
while(fscanf (f,"%d %d %d %d %f",&id,&j,&mo ,&a, &val)!=EOF){
	if ((val<max1 && val>min1)||(val<max2 && val>min2)) {
		i =0;
while ((i <n) && (ch[i]!=id ))
i++;
if (i==n) {ch[i]=id ; n++ ;}} }
sprintf (texte," %d capteurs de humidité alarmentes ",n);
output=lookup_widget(objet,("label_affcapalrs"));
gtk_label_set_text(GTK_LABEL(output),texte);
fclose (f);
return (n);}
}
}


void
on_radiobutton_capalrt_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a=1;
}
}


void
on_radiobutton_capalrh_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
a=2;
}
}


void
on_radiobutton_capdeft_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
b=1;
}
}


void
on_radiobutton_capdefh_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
b=2;
}
}


void
on_button_affcapdef_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetregprop;
  GtkWidget *min,*max,*annee,*msg,*aff;
GtkWidget *treeview,*scl;
 int mindef,maxdef,anneedef;
    char y[50];
    int i=0;
    int tab_annee[50];
    int t;
    int id;
    int k;
    int test=0,n,nb,vide=0;
    char tab_marque[50][50];
	int  tab_nb[50]={0};
 

Fenetregprop=lookup_widget(objet,"Esp_prop");
min=lookup_widget(objet,"spinbutton_mincdef");
max=lookup_widget(objet,"spinbutton_maxcdef");
annee=lookup_widget(objet,"spinbutton_chacapdef");
msg=lookup_widget(objet,"entry_resmarquedeff");
aff=lookup_widget(objet,"label_mrdef");
treeview=lookup_widget(objet,"treeview_lcapdef");
scl=lookup_widget(objet,"scrolledwindow_mrdef");

mindef= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
maxdef= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));
anneedef= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
gtk_widget_show (aff);
if(b==1)
{nb=defectueux(mindef,maxdef,anneedef,"temperature.txt",tab_marque,tab_nb,"temperature");
if(!nb)
vide=1;
n=annee_dispo(tab_annee,"temperature.txt");
for(k=0;k<n;k++)
{if(tab_annee[k]==anneedef)
{test=1;
break;}}
}
else
{nb=defectueux(mindef,maxdef,anneedef,"humidite.txt",tab_marque,tab_nb,"humidite");
if(!nb)
vide=1;
n=annee_dispo(tab_annee,"humidite.txt");
for(k=0;k<n;k++)
{if(tab_annee[k]==anneedef)
{test=1;
break;}}
}
if(test&&!vide)
{t=max_tab_nb(tab_nb,nb);
gtk_label_set_text(GTK_LABEL(aff),"La marque la plus deffectueuse est :");
gtk_entry_set_text(msg,tab_marque[t]);
gtk_widget_show (msg);
cherchercap(treeview, tab_marque[t]);
gtk_widget_show (scl);
}
else if(!test)
{gtk_label_set_text(GTK_LABEL(aff),"L'année saisie n'est pas prise en\nconsidération");
gtk_widget_hide(msg);}
else if(vide)
{gtk_label_set_text(GTK_LABEL(aff),"Pas de capteur défectueux \npour cette année");
gtk_widget_hide(msg);}



remove("deffectueuxt.txt"); 
 

}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* type;
	gchar* genre;
	gchar* etat_sanitaire;
	gchar* j_naissance;
	gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_vaccin;
        gchar* m_vaccin;
	gchar* a_vaccin;

	troupeaux n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &type, 2, &genre , 3, &etat_sanitaire, 4, &j_naissance, 5, &m_naissance , 6, &a_naissance , 7, &j_vaccin , 8, &m_vaccin , 9, &a_vaccin ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.type,type);
                strcpy(n.genre,genre);
		strcpy(n.etat,etat_sanitaire);
		n.naissance.jour=j_naissance;
                n.naissance.mois=m_naissance;
                n.naissance.annee=a_naissance;
                n.vaccin.jour=j_vaccin;
                n.vaccin.mois=m_vaccin;
                n.vaccin.annee=a_vaccin;
                
                
                affichertrp(treeview);
}
}


void
on_button_affnbrtrp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetregprop;
  GtkWidget *type,*nbr;
  GtkWidget *treeview3,*aff;
  char Type[20];
  char Nbr[20];
  int nbrtp;

Fenetregprop=lookup_widget(objet,"Esp_prop");
type=lookup_widget(objet,"combobox_tptrp");
treeview3=lookup_widget(objet,"treeview3");
nbr=lookup_widget(objet,"label_kdnbr");
aff=lookup_widget(objet,"scrolledwindow_nbrtrp");

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));

nbrtp=count(Type);
sprintf(Nbr,"%d",nbrtp);
gtk_label_set_text(GTK_LABEL(nbr),Nbr);
if(nbrtp!=0)
{
gtk_widget_show (aff);
cherchertypetrp(treeview3,Type);
}
else
if(nbrtp==0)
{
gtk_widget_hide (aff);
}
}


void
on_button_affansc_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *output,*cr;
GtkWidget *treeview_affansc,*affichage;
int i;
int pos;
int n;
char ch1[100]="";
char ch2[100]="";
char aff[1000];
char crans[100];
n=annee_seche(tab_an,tab_temp);
pos=valeur_max(tab_temp,n);
output=lookup_widget(objet,"label_anneeseche");
treeview_affansc=lookup_widget(objet,"treeview_affansc");
affichage=lookup_widget(objet,"scrolledwindow_anseche");
cr=lookup_widget(objet,"label_cran");
for(i=0;i<=n;i++)
{sprintf(ch2,"%d\n",tab_an[i]);
strcat(ch1,ch2);}
sprintf(aff,"Les annees de plantations sont:\n%s \n L'annee la plus seche est %d ",ch1,tab_an[pos]);
gtk_label_set_text(GTK_LABEL(output),aff);
sprintf(crans,"%d",tab_an[pos]);
gtk_widget_show (affichage);
gtk_widget_show (cr);
chercherpl(treeview_affansc,crans);
}


void
on_treeview_affansc_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* type;
	gchar* quantite;
	gchar* jour_pl;
        gchar* mois_pl;
        gchar* annee_pl;
	gchar* jour_ir;
        gchar* mois_ir;
        gchar* annee_ir;
	gchar* temperature;
	gchar* humidite;
	gchar* zone;
	plantation n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &type , 3, &quantite , 4, &jour_pl, 5, &mois_pl, 6, &annee_pl , 7, &jour_ir , 8, &mois_ir , 9, &annee_ir , 10, &temperature, 11, &humidite , 12, &zone ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.type,type);
                strcpy(n.quantite,quantite);
                n.date_plantation.jour=jour_pl;
                n.date_plantation.mois=mois_pl;
                n.date_plantation.annee=annee_pl;
                n.date_irrigation.jour=jour_ir;
                n.date_irrigation.mois=mois_ir;
                n.date_irrigation.annee=annee_ir;
		strcpy(n.temperature,temperature);
                strcpy(n.humidite,humidite);
                strcpy(n.zone,zone);


                
                afficherpl(treeview);
}
}


void
on_button_retcnxpro_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrelogin2;
    GtkWidget *FenetrereAuthen;
    Fenetrelogin2=lookup_widget(objet,"login2");
    gtk_widget_destroy(Fenetrelogin2);
    FenetrereAuthen=create_Authen();
    gtk_widget_show(FenetrereAuthen);
}


void
on_button_cnxprop_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrelogin2;
    GtkWidget *Fenetrebienvenue;
    GtkWidget *id,*mdp,*output;
    char identifiant[20];
    char pw[20];
    int v;

    Fenetrelogin2=lookup_widget(objet,"login2");
id=lookup_widget(objet,"entry_idprop");
mdp=lookup_widget(objet,"entry_mdpprop");
output=lookup_widget(objet,"label_altcnxprop");

strcpy(identifiant,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(pw,gtk_entry_get_text(GTK_ENTRY(mdp)));
v=verifprop(identifiant,pw);

if(v!=1)
{
gtk_widget_show (output);
}
else
{
    gtk_widget_destroy(Fenetrelogin2);
    Fenetrebienvenue=create_Esp_prop();
    gtk_widget_show(Fenetrebienvenue);
}
}


void
on_button_okajemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregprop;
    GtkWidget *Fenetrescajemp;
    GtkWidget *treeview_lemp,*aff,*liste;
    Fenetrescajemp=lookup_widget(objet,"scajemp");
    gtk_widget_destroy(Fenetrescajemp);
    Fenetregprop=create_Esp_prop();
    gtk_widget_show(Fenetregprop);
treeview_lemp=lookup_widget(Fenetregprop,"treeview_listemploye");
aff=lookup_widget(Fenetregprop,"scrolledwindow_lemp");
liste=lookup_widget(Fenetregprop,"label_lcap");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficher_employe(treeview_lemp);
}


void
on_button_okmdfemp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregprop;
    GtkWidget *Fenetrescmdfemp;
    GtkWidget *treeview_lemp,*aff;
    Fenetrescmdfemp=lookup_widget(objet,"scmdfemp");
    gtk_widget_destroy(Fenetrescmdfemp);
    Fenetregprop=create_Esp_prop();
    gtk_widget_show(Fenetregprop);
treeview_lemp=lookup_widget(Fenetregprop,"treeview_listemploye");
aff=lookup_widget(Fenetregprop,"scrolledwindow_lemp");

gtk_widget_show (aff);
afficher_employe(treeview_lemp);
}


void
on_button_okspemp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregprop;
    GtkWidget *Fenetrescspemp;
    GtkWidget *treeview_lemp,*aff,*liste;
    Fenetrescspemp=lookup_widget(objet,"scspemp");
    gtk_widget_destroy(Fenetrescspemp);
    Fenetregprop=create_Esp_prop();
    gtk_widget_show(Fenetregprop);
treeview_lemp=lookup_widget(Fenetregprop,"treeview_listemploye");
aff=lookup_widget(Fenetregprop,"scrolledwindow_lemp");

gtk_widget_show (aff);
afficher_employe(treeview_lemp);
}


void
on_button_okspcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrespcap;
    GtkWidget *treeviewlcap,*aff,*liste;
    Fenetrespcap=lookup_widget(objet,"scspcap");
    gtk_widget_destroy(Fenetrespcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
    treeviewlcap=lookup_widget(Fenetregcap,"treeview_lcap");
aff=lookup_widget(Fenetregcap,"scrolledwindowlcap");
liste=lookup_widget(Fenetregcap,"label_lcap");

gtk_widget_show (liste);
gtk_widget_show (aff);


affichercap(treeviewlcap);
}


void
on_button_okmdfcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrescmdfcap;
    GtkWidget *treeviewlcap,*aff,*liste;
    Fenetrescmdfcap=lookup_widget(objet,"scmdfcap");
    gtk_widget_destroy(Fenetrescmdfcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
    treeviewlcap=lookup_widget(Fenetregcap,"treeview_lcap");
aff=lookup_widget(Fenetregcap,"scrolledwindowlcap");
liste=lookup_widget(Fenetregcap,"label_lcap");

gtk_widget_show (liste);

gtk_widget_show (aff);
affichercap(treeviewlcap);
}


void
on_button_ok_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrescajcap;
    GtkWidget *treeviewlcap,*aff,*liste;
    Fenetrescajcap=lookup_widget(objet,"scajcap");
    gtk_widget_destroy(Fenetrescajcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
    treeviewlcap=lookup_widget(Fenetregcap,"treeview_lcap");
aff=lookup_widget(Fenetregcap,"scrolledwindowlcap");
liste=lookup_widget(Fenetregcap,"label_lcap");

gtk_widget_show (liste);
gtk_widget_show (aff);
affichercap(treeviewlcap);
}


void
on_button_msretfct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrefctcap;
    Fenetrefctcap=lookup_widget(objet,"fctcap");
    gtk_widget_destroy(Fenetrefctcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_button_mscnffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    fctcapteur n;
    GtkWidget *Fenetrefctcap;
    GtkWidget *treeviewfct;
    GtkWidget *id,*jour,*mois,*annee,*val,*aff,*moisaffct,*anneeaffct;
    GtkWidget *output1,*output2,*output3,*output4,*output5;
    int b=1;
    int t,h,j,m,a;
    char idfct[20];
    char moisaff[20];
    char anneeaff[20];

Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"combobox_idfct");
val=lookup_widget(objet,"spinbutton_msvalfct");
jour=lookup_widget(objet,"spinbutton_msjdfct");
mois=lookup_widget(objet,"spinbutton_msmdfct");
annee=lookup_widget(objet,"spinbutton_msadfct");
output1=lookup_widget(objet,"label_msajfct");
output2=lookup_widget(objet,"label_msmdffct");
output3=lookup_widget(objet,"label_msspfct");
output4=lookup_widget(objet,"label_mssvalfct");
output5=lookup_widget(objet,"label_msvrdt");
treeviewfct=lookup_widget(Fenetrefctcap,"treeview_mscapfct");
aff=lookup_widget(Fenetrefctcap,"scrolledwindow_fctcap");
moisaffct=lookup_widget(objet,"spinbutton_msmafffct");
anneeaffct=lookup_widget(objet,"spinbutton_msaafffct");


sprintf(moisaff,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisaffct)));
sprintf(anneeaff,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneeaffct)));


strcpy(n.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(idfct,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
sprintf(n.val,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val)));
if(strcmp(n.val,"")==0)
{
gtk_widget_show (output4);
b=0;
}
n.date_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(g==1)
{
if (b==1)
{
t=verifdatet(idfct,j,m,a);
  if(t==1)
 {
 gtk_widget_show (output5);
 gtk_widget_hide (output1);
 }
else
 {
temperature(n);
affichercapt(treeviewfct);
rechcapt(treeviewfct, idfct, moisaff, anneeaff);
gtk_widget_show (output1);
gtk_widget_hide (output4);
gtk_widget_hide (output5);
 }
}
}
else
if(g==2)
{
if (b==1)
{
h=verifdateh(idfct,j,m,a);
  if(h==1)
 {
  gtk_widget_show (output5);
 gtk_widget_hide (output1);
 }
else
 {
humidite(n);
affichercaph(treeviewfct);
rechcaph(treeviewfct, idfct, moisaff, anneeaff);
gtk_widget_show (output1);
gtk_widget_hide (output4);
gtk_widget_hide (output5);
 }
}
}
gtk_widget_hide (output2);
gtk_widget_hide (output3);

gtk_widget_hide (aff);
}


void
on_button_msmdffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    fctcapteur n;
    GtkWidget *Fenetrefctcap;
    GtkWidget *treeviewfct;
    GtkWidget *id,*jour,*mois,*annee,*val,*aff,*moisaffct,*anneeaffct;
    GtkWidget *output1,*output2,*output3,*output4,*output5;
    int b=1;
    char idcap[20];
    char moisaff[20];
    char anneeaff[20];

Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"combobox_idfct");
val=lookup_widget(objet,"spinbutton_msvalfct");
jour=lookup_widget(objet,"spinbutton_msjdfct");
mois=lookup_widget(objet,"spinbutton_msmdfct");
annee=lookup_widget(objet,"spinbutton_msadfct");
output1=lookup_widget(objet,"label_msajfct");
output2=lookup_widget(objet,"label_msmdffct");
output3=lookup_widget(objet,"label_msspfct");
output4=lookup_widget(objet,"label_mssvalfct");
output5=lookup_widget(objet,"label_msvrdt");
treeviewfct=lookup_widget(Fenetrefctcap,"treeview_mscapfct");
moisaffct=lookup_widget(objet,"spinbutton_msmafffct");
anneeaffct=lookup_widget(objet,"spinbutton_msaafffct");
aff=lookup_widget(Fenetrefctcap,"scrolledwindow_fctcap");

sprintf(moisaff,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois)));
sprintf(anneeaff,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee)));


strcpy(n.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(idcap,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
sprintf(n.val,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val)));
if(strcmp(n.val,"")==0)
{
gtk_widget_show (output5);
b=0;
}
n.date_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(g==1)
{
if (b==1)
{
modifiertmp(n);
affichercapt(treeviewfct);                
rechcapt(treeviewfct, idcap, moisaff, anneeaff);
gtk_widget_show (output2);
gtk_widget_hide (output5);
}
}
else if(g==2)
{
if (b==1)
{
modifierhmd(n);
rechcaph(treeviewfct, idcap, moisaff, anneeaff);
affichercaph(treeviewfct);
gtk_widget_show (output2);
gtk_widget_hide (output5);
}
}
gtk_widget_hide (output1);
gtk_widget_hide (output3);
gtk_widget_hide (output4);
gtk_widget_hide (aff);
}


void
on_button_msspfcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrefctcap,*Fenetresp;
   GtkWidget *id,*aff;
GtkWidget *output1,*output2,*output3;

    Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"combobox_idfct");
output1=lookup_widget(objet,"label_msajfct");
output2=lookup_widget(objet,"label_msmdffct");
output3=lookup_widget(objet,"label_msspfct");
aff=lookup_widget(Fenetrefctcap,"scrolledwindow_fctcap");

strcpy(idcap,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
    gtk_widget_destroy(Fenetrefctcap);
    Fenetresp=create_chspfctcap();
    gtk_widget_show(Fenetresp);
}


void
on_button_msafffct_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    fctcapteur n;
    GtkWidget *Fenetrefctcap;
    GtkWidget *id,*mois,*annee;
    GtkWidget *treeviewfct,*aff;
    char idcap[20];
    char moisaff[20];
    char anneeaff[20];

Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"combobox_idfct");
treeviewfct=lookup_widget(Fenetrefctcap,"treeview_mscapfct");
mois=lookup_widget(objet,"spinbutton_msmafffct");
annee=lookup_widget(objet,"spinbutton_msaafffct");
aff=lookup_widget(Fenetrefctcap,"scrolledwindow_fctcap");

strcpy(idcap,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
sprintf(moisaff,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois)));
sprintf(anneeaff,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee)));

if(g==1)
{rechcapt(treeviewfct, idcap, moisaff, anneeaff);
gtk_widget_show (aff);}
else
if(g==2)
{rechcaph(treeviewfct, idcap, moisaff , anneeaff);
gtk_widget_show (aff);}

}


void
on_radiobutton_mstfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
g=1;
}
}


void
on_radiobutton_mshfct_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
g=2;
}
}


void
on_button_mschidfct_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    capteur c;
    FILE *f;
    GtkWidget *Fenetrefctcap;
    GtkWidget *id;
  char text1[20]="temperature";
  char text2[20]="humidite";

Fenetrefctcap=lookup_widget(objet,"fctcap");
id=lookup_widget(objet,"combobox_idfct");

if(g==1)
{
f=fopen("liste_des_capteurs.txt","r");
       while(fscanf(f,"%s %s %s %s %s %d %d %d\n",c.idcapteur,c.zone_ajout,c.type,c.marque,c.etat_fonctionnement,&c.date_mise_fct.jour,&c.date_mise_fct.mois,&c.date_mise_fct.annee)!=EOF)
       {
if(strcmp(c.type,text1)==0)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(c.idcapteur));
}
       }
fclose(f);
}

if(g==2)
{
f=fopen("liste_des_capteurs.txt","r");
       while(fscanf(f,"%s %s %s %s %s %d %d %d\n",c.idcapteur,c.zone_ajout,c.type,c.marque,c.etat_fonctionnement,&c.date_mise_fct.jour,&c.date_mise_fct.mois,&c.date_mise_fct.annee)!=EOF)
       {
if(strcmp(c.type,text2)==0)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(c.idcapteur));
}
       }
fclose(f);
}

}


void
on_treeview_mscapfct_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* val;	

	fctcapteur n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &jour, 2, &mois , 3, &annee, 4, &val ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.val,val);
                n.date_fct.jour=jour;
                n.date_fct.mois=mois;
                n.date_fct.annee=annee;
                affichercapt(treeview);
                affichercaph(treeview);
}  
}


void
on_button_mscnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrespcap;
    GtkWidget *Fenetresuppcap;
    GtkWidget *id;
    GtkWidget *output;
    char idsp[20];
    int v;

Fenetresuppcap=lookup_widget(objet,"suppcap");
id=lookup_widget(objet,"entry_msidsp");
output=lookup_widget(objet,"label_msaltsp");
strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));

v=verifcap(idsp);

if(v!=1)
{
    gtk_widget_show (output);
}
else
{
 if(A==1)
{
supprimercap(idsp);

    gtk_widget_destroy(Fenetresuppcap);
    Fenetrespcap=create_scspcap();
    gtk_widget_show(Fenetrespcap);
}
}
}


void
on_button_msanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetresuppcap;
    Fenetresuppcap=lookup_widget(objet,"suppcap");
    gtk_widget_destroy(Fenetresuppcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_radiobutton_msosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppcap;
   GtkWidget *output1;
   GtkWidget *id;

Fenetresuppcap=lookup_widget(objet,"suppcap");
output1=lookup_widget(objet,"label_msmsgsp");
A=1;

    gtk_widget_show (output1);
}


void
on_radiobutton_msnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppcap;
   GtkWidget *output1;
   GtkWidget *id;

Fenetresuppcap=lookup_widget(objet,"suppcap");
output1=lookup_widget(objet,"label_msmsgsp");
A=0;

    gtk_widget_hide (output1);

}


void
on_button_msretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrerechcap;
    Fenetrerechcap=lookup_widget(objet,"rechcap");
    gtk_widget_destroy(Fenetrerechcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_treeview_mstxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* identifiant;
	gchar* zone;
	gchar* type;
	gchar* marque;
	gchar* etat_fct;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;

	capteur n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &zone, 2, &type , 3, &marque, 4, &etat_fct, 5, &jour_fct , 6, &mois_fct , 7, &annee_fct , -1);
  		strcpy(n.idcapteur,identifiant);
		strcpy(n.zone_ajout,zone);
		strcpy(n.type,type);
                strcpy(n.marque,marque);
		strcpy(n.etat_fonctionnement,etat_fct);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;
                
                
                affichercap(treeview);
                
}
}


void
on_button_mscnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerechcap;
   GtkWidget *id,*crt;
   GtkWidget *treeviewrech,*aff;
   GtkWidget *output1,*output2;
   char filtre[20];
   char critere[30];
   int v;

Fenetrerechcap=lookup_widget(objet,"rechcap");
id=lookup_widget(objet,"entry_msidrech");
treeviewrech=lookup_widget(objet,"treeview_mstxtrech");
output1=lookup_widget(objet,"label_mstxtrech");
output2=lookup_widget(objet,"label_msidaltrech");
crt=lookup_widget(objet,"combobox_mscrrech");
aff=lookup_widget(objet,"scrolledwindow_rechcap");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

v=verifrechcap(filtre);
if(v!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
gtk_widget_hide (aff);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
gtk_widget_show (aff);
filtrecriterecap(treeviewrech, critere, filtre);
}
}


void
on_button_mscnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  capteur n;
    GtkWidget *Fenetrescmdfcap;
    GtkWidget *Fenetremdfcap;
  GtkWidget *input1, *input2;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *zone;
  char text1[20]="temperature";
  char text2[20]="humidite";


Fenetremdfcap=lookup_widget(objet,"mdfcap");
input1=lookup_widget(objet,"combobox_msidmdf");
input2=lookup_widget(objet,"entry_msmrmdf");
zone=lookup_widget(objet,"combobox_msempmdf");
jour=lookup_widget(objet,"spinbutton_msjdimdf");
mois=lookup_widget(objet,"spinbutton_msmdimdf");
annee=lookup_widget(objet,"spinbutton_msadimdf");

strcpy(n.idcapteur,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.zone_ajout,gtk_combo_box_get_active_text(GTK_COMBO_BOX(zone)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(e==1)
{strcpy(n.type,text1);}
else
if(e==2)
{strcpy(n.type,text2);}

if(T2[0]==1)
{strcpy(n.etat_fonctionnement,"oui");}
else
if(T2[1]==1)
{strcpy(n.etat_fonctionnement,"non");}

modifiercap(n);

    gtk_widget_destroy(Fenetremdfcap);
    Fenetrescmdfcap=create_scmdfcap();
    gtk_widget_show(Fenetrescmdfcap);
}


void
on_button_msanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetremdfcap;
    Fenetremdfcap=lookup_widget(objet,"mdfcap");
    gtk_widget_destroy(Fenetremdfcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_checkbutton_msofctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T2[0]=1;
}
}


void
on_checkbutton_msnfctmdf_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T2[1]=1;
}
}


void
on_button_mschidmdf_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  capteur c;
  FILE *f;
  GtkWidget *Fenetremdfcap;
  GtkWidget *id,*cnf,*anl;
  GtkWidget *output1,*output2;
  char text1[20]="temperature";
  char text2[20]="humidite";


Fenetremdfcap=lookup_widget(objet,"mdfcap");
id=lookup_widget(objet,"combobox_msidmdf");
output1=lookup_widget(objet,"label_mschmdf");
output2=lookup_widget(objet,"label_msanlchmdf");
cnf=lookup_widget(objet,"button_mscnfidmdf");
anl=lookup_widget(objet,"button_msanlidmdf");

if(e==1)
{
f=fopen("liste_des_capteurs.txt","r");
       while(fscanf(f,"%s %s %s %s %s %d %d %d\n",c.idcapteur,c.zone_ajout,c.type,c.marque,c.etat_fonctionnement,&c.date_mise_fct.jour,&c.date_mise_fct.mois,&c.date_mise_fct.annee)!=EOF)
       {
if(strcmp(c.type,text1)==0)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(c.idcapteur));
       }
}
fclose(f);
}

if(e==2)
{
f=fopen("liste_des_capteurs.txt","r");
       while(fscanf(f,"%s %s %s %s %s %d %d %d\n",c.idcapteur,c.zone_ajout,c.type,c.marque,c.etat_fonctionnement,&c.date_mise_fct.jour,&c.date_mise_fct.mois,&c.date_mise_fct.annee)!=EOF)
       {
if(strcmp(c.type,text2)==0)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(c.idcapteur));
       }
}
fclose(f);
}

gtk_widget_hide(output2);
gtk_widget_show (output1);
gtk_widget_show (cnf);
gtk_widget_show (anl);


}


void
on_radiobutton_mshmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
e=2;
}
}


void
on_button_mscnfidmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
  capteur c;
  FILE *f;
  GtkWidget *Fenetremdfcap;
  GtkWidget *id;
  GtkWidget *input1;
  GtkWidget *output1,*output2;
    char id1[20];
    char marque1[20];

Fenetremdfcap=lookup_widget(objet,"mdfcap");
id=lookup_widget(objet,"combobox_msidmdf");
input1=lookup_widget(objet,"entry_msmrmdf");
output1=lookup_widget(objet,"label_mschmdf");
output2=lookup_widget(objet,"label_msanlchmdf");

strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("liste_des_capteurs.txt","r");
       while(fscanf(f,"%s %s %s %s %s %d %d %d\n",c.idcapteur,c.zone_ajout,c.type,c.marque,c.etat_fonctionnement,&c.date_mise_fct.jour,&c.date_mise_fct.mois,&c.date_mise_fct.annee)!=EOF)
       {
if(strcmp(c.idcapteur,id1)==0)
{ 
strcpy(marque1,c.marque);
}
       }
fclose(f);

gtk_entry_set_text(input1,marque1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_button_msanlidmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetremdfcap;
  GtkWidget *output1,*output2;

Fenetremdfcap=lookup_widget(objet,"mdfcap");
output1=lookup_widget(objet,"label_mschmdf");
output2=lookup_widget(objet,"label_msanlchmdf");

gtk_widget_hide(output1);
gtk_widget_show (output2);

}


void
on_radiobutton_mstmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
e=1;
}
}


void
on_button_mscnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  capteur n;
  GtkWidget *Fenetrescajcap;
  GtkWidget *Fenetreajcap;
  GtkWidget *input1, *input2;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *zone;
  GtkWidget *output1, *output2;
  char text1[20]="temperature";
  char text2[20]="humidite";
  char id[20];
  int b=1,v;


Fenetreajcap=lookup_widget(objet,"ajcap");
input1=lookup_widget(objet,"entry_msidaj");
input2=lookup_widget(objet,"entry_msmraj");
zone=lookup_widget(objet,"combobox_msempaj");
jour=lookup_widget(objet,"spinbutton_msjdiaj");
mois=lookup_widget(objet,"spinbutton_msmdiaj");
annee=lookup_widget(objet,"spinbutton_msadiaj");
output1=lookup_widget(objet,"label_msaltaj");
output2=lookup_widget(objet,"label_mssmraj");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.idcapteur,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input2)));

if(strcmp(n.marque,"")==0)
{
gtk_widget_show (output2);
b=0;
}

strcpy(n.zone_ajout,gtk_combo_box_get_active_text(GTK_COMBO_BOX(zone)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(d==1)
{strcpy(n.type,text1);}
else
if(d==2)
{strcpy(n.type,text2);}

if(T1[0]==1)
{strcpy(n.etat_fonctionnement,"oui");}
else
if(T1[1]==1)
{strcpy(n.etat_fonctionnement,"non");}

v=verifcap(id);
if (v==1)
{
gtk_widget_show (output1);
}
else
{
  if(b==1)
{
ajoutercap(n);

    gtk_widget_destroy(Fenetreajcap);
    Fenetrescajcap=create_scajcap();
    gtk_widget_show(Fenetrescajcap);
}
}

}


void
on_button_msanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetreajcap;
    Fenetreajcap=lookup_widget(objet,"ajcap");
    gtk_widget_destroy(Fenetreajcap);
    Fenetregcap=create_gcap();
    gtk_widget_show(Fenetregcap);
}


void
on_radiobutton_mstajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
d=1;
}
}


void
on_radiobutton_mshaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
d=2;
}
}


void
on_checkbutton_msofctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T1[0]=1;
}
}


void
on_checkbutton_msnfctaj_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
T1[1]=1;
}
}


void
on_button_ajtcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetreajcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetreajcap=create_ajcap();
    gtk_widget_show(Fenetreajcap);
}


void
on_button_mdfcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetremdfcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetremdfcap=create_mdfcap();
    gtk_widget_show(Fenetremdfcap);
}


void
on_button_suppcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetresuppcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetresuppcap=create_suppcap();
    gtk_widget_show(Fenetresuppcap);
}


void
on_button_retgcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrebienvenue;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetrebienvenue=create_bienvenue();
    gtk_widget_show(Fenetrebienvenue);
}


void
on_button_rechcap_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrerechcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetrerechcap=create_rechcap();
    gtk_widget_show(Fenetrerechcap);
}


void
on_button_affcap_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewlcap,*aff,*liste;
GtkWidget *Fenetregcap;

treeviewlcap=lookup_widget(objet,"treeview_lcap");
Fenetregcap=lookup_widget(objet,"gcap");
aff=lookup_widget(objet,"scrolledwindowlcap");
liste=lookup_widget(Fenetregcap,"label_lcap");

gtk_widget_show (liste);
gtk_widget_show(aff);
affichercap(treeviewlcap);
}


void
on_button_msfctcap_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregcap;
    GtkWidget *Fenetrefctcap;
    Fenetregcap=lookup_widget(objet,"gcap");
    gtk_widget_destroy(Fenetregcap);
    Fenetrefctcap=create_fctcap();
    gtk_widget_show(Fenetrefctcap);
}


void
on_treeview_lcap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* idcapteur;
	gchar* zone_ajout;
	gchar* type;
	gchar* marque;
	gchar* etat_fct;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;

	capteur c;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &idcapteur, 1, &zone_ajout, 2, &type , 3, &marque, 4, &etat_fct, 5, &jour_fct , 6, &mois_fct , 7, &annee_fct ,-1);
  		strcpy(c.idcapteur,idcapteur);
		strcpy(c.zone_ajout,zone_ajout);
		strcpy(c.type,type);
                strcpy(c.marque,marque);
		strcpy(c.etat_fonctionnement,etat_fct);
                c.date_mise_fct.jour=jour_fct;
                c.date_mise_fct.mois=mois_fct;
                c.date_mise_fct.annee=annee_fct;
                
                affichercap(treeview);
                
}
}


void
on_button_affcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview_lcl,*aff,*liste;
GtkWidget *Fenetregclt;

Fenetregclt=lookup_widget(objet,"gclt");
treeview_lcl=lookup_widget(Fenetregclt,"treeview_lcl");
aff=lookup_widget(Fenetregclt,"scrolledwindow_lclt");
liste=lookup_widget(Fenetregclt,"label_lclt");

gtk_widget_show(liste);
gtk_widget_show(aff);
affichercl(treeview_lcl);
}


void
on_button_ajtcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetreajtcl;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetreajtcl=create_ajtcl();
    gtk_widget_show(Fenetreajtcl);
}


void
on_button_mdfcl_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetremdfcl;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetremdfcl=create_mdfcl();
    gtk_widget_show(Fenetremdfcl);
}


void
on_button_suppcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetresuppclt;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetresuppclt=create_suppclt();
    gtk_widget_show(Fenetresuppclt);
}


void
on_button_retgcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrebienvenue;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetrebienvenue=create_bienvenue();
    gtk_widget_show(Fenetrebienvenue);
}


void
on_button_rechcl_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrerechclt;
    Fenetregclt=lookup_widget(objet,"gclt");
    gtk_widget_destroy(Fenetregclt);
    Fenetrerechclt=create_rechcl();
    gtk_widget_show(Fenetrerechclt);
}


void
on_treeview_lcl_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* sexe;
	gchar* email;
	gchar* tel;
	gchar* fidelite;
        gchar* j_naissance;
        gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_inscri;
        gchar* m_inscri;
	gchar* a_inscri;

	client n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &id, 1, &nom, 2, &prenom , 3, &sexe, 4, &email, 5, &tel , 6, &fidelite , 7, &j_naissance , 8, &m_naissance , 9, &a_naissance , 10, &j_inscri , 11, &m_inscri , 12, &a_inscri ,-1);
  		strcpy(n.id,id);
		strcpy(n.nom,nom);
		strcpy(n.prenom,prenom);
                strcpy(n.sexe,sexe);
		strcpy(n.email,email);
                strcpy(n.numtel,tel);
                strcpy(n.fidelite,fidelite);
                n.dn.j=j_naissance;
                n.dn.m=m_naissance;
                n.dn.a=a_naissance;
                n.da.j=j_inscri;
                n.da.m=m_inscri;
                n.da.a=a_inscri;
                
                
                affichercl(treeview);
}
}


void
on_button_nmcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    client n;
    GtkWidget *Fenetresajclt;
    GtkWidget *Fenetreajtcl;
    GtkWidget *input1, *input2, *input3, *input4 , *input5;
    GtkWidget *jdn,*mdn,*adn,*jdi,*mdi,*adi;
    GtkWidget *output1, *output2, *output3, *output4, *output5;
    int b=1,v;
    char id[20];
    
Fenetreajtcl=lookup_widget(objet,"ajtcl");
input1=lookup_widget(objet,"entry_nmnomajt");
input2=lookup_widget(objet,"entry_nmpreajt");
input3=lookup_widget(objet,"entry_nmaeajt");
input4=lookup_widget(objet,"entry_nmidajt");
input5=lookup_widget(objet,"entry_nmtelajt");
jdn=lookup_widget(objet,"spinbuttonnmjdnajt");
mdn=lookup_widget(objet,"spinbutton_nmmdnajt");
adn=lookup_widget(objet,"spinbutton_nmadnajt");
jdi=lookup_widget(objet,"spinbutton_nmjdiajt");
mdi=lookup_widget(objet,"spinbutton_nmmdiajt");
adi=lookup_widget(objet,"spinbutton_nmadiajt");
output1=lookup_widget(objet,"label_nmsnomaj");
output2=lookup_widget(objet,"label_nmspreaj");
output3=lookup_widget(objet,"label_nmsaeaj");
output4=lookup_widget(objet,"label_nmspraj");
output5=lookup_widget(objet,"label_nmaltaj");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
if(strcmp(n.nom,"")==0)
{
gtk_widget_show (output1);
b=0;
}
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
if(strcmp(n.prenom,"")==0)
{
gtk_widget_show (output2);
b=0;
}
strcpy(n.email,gtk_entry_get_text(GTK_ENTRY(input3)));
if(strcmp(n.email,"")==0)
{
gtk_widget_show (output3);
b=0;
}
strcpy(n.id,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(n.numtel,gtk_entry_get_text(GTK_ENTRY(input5)));
if(strcmp(n.numtel,"")==0)
{
gtk_widget_show (output4);
b=0;
}
n.dn.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdn));
n.dn.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdn));
n.dn.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adn));
n.da.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdi));
n.da.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdi));
n.da.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adi));

if(i==1)
{strcpy(n.sexe,"Masculin");}
else
if(i==2)
{strcpy(n.sexe,"Feminin");}

if(l==1)
{strcpy(n.fidelite,"oui");}
else
if(l==0)
{strcpy(n.fidelite,"non");}

v=verifcl(id);
if (v==1)
{
gtk_widget_show (output5);
}
else
{
  if(b==1)
{
ajoutercl(n);

    gtk_widget_destroy(Fenetreajtcl);
    Fenetresajclt=create_sajclt();
    gtk_widget_show(Fenetresajclt);
}
}
}


void
on_button_nmanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetreajtcl;
    Fenetreajtcl=lookup_widget(objet,"ajtcl");
    gtk_widget_destroy(Fenetreajtcl);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_radiobutton_nmmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
i=1;
}
}


void
on_radiobutton_nmfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
i=2;
}
}


void
on_checkbutton_nmfdajt_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
l=1;
}
}


void
on_button_nmcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
   client n;
    GtkWidget *Fenetrescmdfclt;
    GtkWidget *Fenetremdfcl;
    GtkWidget *input1, *input2, *input3, *input4 , *input5;
    GtkWidget *jdn,*mdn,*adn,*jdi,*mdi,*adi;

    Fenetremdfcl=lookup_widget(objet,"mdfcl");

input1=lookup_widget(objet,"entry_nmnommdf");
input2=lookup_widget(objet,"entry_nmpremdf");
input3=lookup_widget(objet,"entry_nmaemdf");
input4=lookup_widget(objet,"combobox_nmidmdf");
input5=lookup_widget(objet,"entry_nmtelmdf");
jdn=lookup_widget(objet,"spinbutton_nmjdnmdf");
mdn=lookup_widget(objet,"spinbutton_nmmdnmdf");
adn=lookup_widget(objet,"spinbutton_nmadnmdf");
jdi=lookup_widget(objet,"spinbutton_nmjdimdf");
mdi=lookup_widget(objet,"spinbutton_nmmdimdf");
adi=lookup_widget(objet,"spinbutton_nmadimdf");

strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.email,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(n.id,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy(n.numtel,gtk_entry_get_text(GTK_ENTRY(input5)));
n.dn.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdn));
n.dn.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdn));
n.dn.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adn));
n.da.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jdi));
n.da.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mdi));
n.da.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(adi));

if(j==1)
{strcpy(n.sexe,"Masculin");}
else
if(j==2)
{strcpy(n.sexe,"Feminin");}

if(m==1)
{strcpy(n.fidelite,"oui");}
else
if(m==0)
{strcpy(n.fidelite,"non");}
   
   modifiercl(n);
   
    gtk_widget_destroy(Fenetremdfcl);
    Fenetrescmdfclt=create_scmdfclt();
    gtk_widget_show(Fenetrescmdfclt);
}


void
on_button_nmanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetremdfcl;
    Fenetremdfcl=lookup_widget(objet,"mdfcl");
    gtk_widget_destroy(Fenetremdfcl);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_checkbutton_nmfdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
m=1;
}
}


void
on_radiobutton_nmmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
j=1;
}
}


void
on_radiobutton_nmfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
j=2;
}
}


void
on_button_nmvldch_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  client c;
  FILE *f;
  GtkWidget *Fenetremdfcl;
  GtkWidget *id;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *output1,*output2;
    char nom1[30];
    char prenom1[30];
    char email1[40];
    char id1[20];
    char tel1[20];

Fenetremdfcl=lookup_widget(objet,"mdfcl");
id=lookup_widget(objet,"combobox_nmidmdf");
input1=lookup_widget(objet,"entry_nmnommdf");
input2=lookup_widget(objet,"entry_nmpremdf");
input3=lookup_widget(objet,"entry_nmaemdf");
input4=lookup_widget(objet,"entry_nmtelmdf");
output1=lookup_widget(objet,"label_nmchid");
output2=lookup_widget(objet,"label_nmmsgmdf");

strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
f=fopen("liste_clients.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c.id,c.prenom,c.nom,c.email,c.numtel,c.sexe,c.fidelite,&c.dn.j,&c.dn.m,&c.dn.a,&c.da.j,&c.da.m,&c.da.a)!=EOF)
       {
if(strcmp(c.id,id1)==0)
{
strcpy(prenom1,c.prenom);
strcpy(nom1,c.nom);
strcpy(email1,c.email);
strcpy(tel1,c.numtel);
}    
        }
fclose(f);

gtk_entry_set_text(input1,nom1);
gtk_entry_set_text(input2,prenom1);
gtk_entry_set_text(input3,email1);
gtk_entry_set_text(input4,tel1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_button_nmanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetremdfcl;
  GtkWidget *output1,*output2;

Fenetremdfcl=lookup_widget(objet,"mdfcl");
output1=lookup_widget(objet,"label_nmchid");
output2=lookup_widget(objet,"label_nmmsgmdf");

gtk_widget_hide(output1);
gtk_widget_show (output2);
}


void
on_button_nmchidmdf_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  client c;
  FILE *f;
  GtkWidget *Fenetremdfcl;
  GtkWidget *id,*cnf,*anl;
  GtkWidget *output1,*output2;

Fenetremdfcl=lookup_widget(objet,"mdfcl");
id=lookup_widget(objet,"combobox_nmidmdf");
output1=lookup_widget(objet,"label_nmchid");
output2=lookup_widget(objet,"label_nmmsgmdf");
cnf=lookup_widget(objet,"button_nmvldch");
anl=lookup_widget(objet,"button_nmanlchid");

f=fopen("liste_clients.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s %d %d %d %d %d %d\n",c.id,c.prenom,c.nom,c.email,c.numtel,c.sexe,c.fidelite,&c.dn.j,&c.dn.m,&c.dn.a,&c.da.j,&c.da.m,&c.da.a)!=EOF)
       {
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(c.id));
       }
fclose(f);
gtk_widget_hide(output2);
gtk_widget_show (output1);
gtk_widget_show (cnf);
gtk_widget_show (anl);
}


void
on_button_nmretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrerechclt;
    Fenetrerechclt=lookup_widget(objet,"rechcl");
    gtk_widget_destroy(Fenetrerechclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_treeview_nmtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* sexe;
	gchar* email;
	gchar* tel;
	gchar* fidelite;
        gchar* j_naissance;
        gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_inscri;
        gchar* m_inscri;
	gchar* a_inscri;

	client n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &id, 1, &nom, 2, &prenom , 3, &sexe, 4, &email, 5, &tel , 6, &fidelite , 7, &j_naissance , 8, &m_naissance , 9, &a_naissance , 10, &j_inscri , 11, &m_inscri , 12, &a_inscri ,-1);
  		strcpy(n.id,id);
		strcpy(n.nom,nom);
		strcpy(n.prenom,prenom);
                strcpy(n.sexe,sexe);
		strcpy(n.email,email);
                strcpy(n.numtel,tel);
                strcpy(n.fidelite,fidelite);
                n.dn.j=j_naissance;
                n.dn.m=m_naissance;
                n.dn.a=a_naissance;
                n.da.j=j_inscri;
                n.da.m=m_inscri;
                n.da.a=a_inscri;
                
                
                affichercl(treeview);
}
}


void
on_button_nmcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerechclt;
   GtkWidget *id,*output1,*output2,*crt;
   GtkWidget *treeviewrech,*aff;
   char filtre[20];
   char critere[30];
   int v;
   
Fenetrerechclt=lookup_widget(objet,"rechcl");
id=lookup_widget(objet,"entry_nmidrech");
output1=lookup_widget(objet,"label_nmtxtrech");
output2=lookup_widget(objet,"label_nmaltrech");
treeviewrech=lookup_widget(objet,"treeview_nmtxtrech");
crt=lookup_widget(objet,"combobox_nmcrrech");
aff=lookup_widget(objet,"scrolledwindow_lclt");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

v=verifrechcl(filtre);
if(v!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
  gtk_widget_hide(aff);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
 gtk_widget_show(aff);
filtrecriterecl(treeviewrech, critere, filtre);
}
}


void
on_button_nmanlrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetresuppclt;
    Fenetresuppclt=lookup_widget(objet,"suppclt");
    gtk_widget_destroy(Fenetresuppclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
}


void
on_button_nmcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrescspclt;
    GtkWidget *Fenetresuppclt;
    GtkWidget *output1,*output2;
    GtkWidget *id;
    char idsp[20];
    int v;

    Fenetresuppclt=lookup_widget(objet,"suppclt");
    id=lookup_widget(objet,"entry_nmidsp");
    output1=lookup_widget(objet,"label_nmmsgsp");
    output2=lookup_widget(objet,"label_nmaltsp");
    strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));
v=verifcl(idsp);
if(v!=1)
{
    gtk_widget_show (output2);
}
else
{
if(B==1)
{
    supprimercl(idsp);
    gtk_widget_destroy(Fenetresuppclt);
    Fenetrescspclt=create_scspclt();
    gtk_widget_show(Fenetrescspclt);
}
}

}


void
on_radiobutton_nmnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetresuppclt;
    GtkWidget *output1;
    GtkWidget *id;

   Fenetresuppclt=lookup_widget(objet,"suppclt");
    output1=lookup_widget(objet,"label_nmmsgsp");
    B=0;
gtk_widget_hide(output1);
}


void
on_radiobutton_nmosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetresuppclt;
    GtkWidget *output1;

   Fenetresuppclt=lookup_widget(objet,"suppclt");
    output1=lookup_widget(objet,"label_nmmsgsp");
    B=1;

    gtk_widget_show (output1);
}


void
on_button_okmdfclt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrescmdfclt;
GtkWidget *treeview_lcl,*aff,*liste;
    Fenetrescmdfclt=lookup_widget(objet,"scmdfclt");
    gtk_widget_destroy(Fenetrescmdfclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
treeview_lcl=lookup_widget(Fenetregclt,"treeview_lcl");
aff=lookup_widget(Fenetregclt,"scrolledwindow_lclt");
liste=lookup_widget(Fenetregclt,"label_lclt");

gtk_widget_show(liste);
gtk_widget_show(aff);
affichercl(treeview_lcl);
}


void
on_button_scspclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetrescspclt;
GtkWidget *treeview_lcl,*aff,*liste;
    Fenetrescspclt=lookup_widget(objet,"scspclt");
    gtk_widget_destroy(Fenetrescspclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
treeview_lcl=lookup_widget(Fenetregclt,"treeview_lcl");
aff=lookup_widget(Fenetregclt,"scrolledwindow_lclt");
liste=lookup_widget(Fenetregclt,"label_lclt");

gtk_widget_show(liste);
gtk_widget_show(aff);
affichercl(treeview_lcl);
}


void
on_button_okajclt_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregclt;
    GtkWidget *Fenetresajclt;
GtkWidget *treeview_lcl,*aff,*liste;
    Fenetresajclt=lookup_widget(objet,"sajclt");
    gtk_widget_destroy(Fenetresajclt);
    Fenetregclt=create_gclt();
    gtk_widget_show(Fenetregclt);
treeview_lcl=lookup_widget(Fenetregclt,"treeview_lcl");
aff=lookup_widget(Fenetregclt,"scrolledwindow_lclt");
liste=lookup_widget(Fenetregclt,"label_lclt");

gtk_widget_show(liste);
gtk_widget_show(aff);
affichercl(treeview_lcl);
}


void
on_button_ajteq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetreajeqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetreajeqag=create_ajeqag();
    gtk_widget_show(Fenetreajeqag);
}


void
on_button_mdfeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetremdfeqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetremdfeqag=create_mdfeqag();
    gtk_widget_show(Fenetremdfeqag);

}


void
on_button_suppeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetresuppeqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetresuppeqag=create_suppeqag();
    gtk_widget_show(Fenetresuppeqag);

}


void
on_button_recheq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetrerecheqag;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetrerecheqag=create_recheqag();
    gtk_widget_show(Fenetrerecheqag);
}


void
on_button_affeq_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_leqag,*aff,*liste;
    GtkWidget *Fenetregeqag;
   

Fenetregeqag=lookup_widget(objet,"geqagr");
treeview_leqag=lookup_widget(Fenetregeqag,"treeview_leqag");
aff=lookup_widget(Fenetregeqag,"scrolledwindowgeqag");
liste=lookup_widget(Fenetregeqag,"label_leqag");

gtk_widget_show (liste);
gtk_widget_show (aff);
affichereq(treeview_leqag);
}


void
on_treeview_leqag_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* reference;
	gchar* matricule;
	gchar* type;
	gchar* marque;
	gchar* fournisseur;
	gchar* etat_fct;
	gchar* garantie;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;
	gchar* disponibilite;

	equi_agr n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &reference, 1, &matricule, 2, &type , 3, &marque, 4, &fournisseur, 5, &etat_fct , 6, &garantie , 7, &disponibilite , 8, &jour_fct , 9, &mois_fct , 10, &annee_fct ,-1);
  		strcpy(n.reference,reference);
		strcpy(n.matricule,matricule);
		strcpy(n.type,type);
                strcpy(n.marque,marque);
		strcpy(n.fournisseur,fournisseur);
		strcpy(n.etat_fonctionnement,etat_fct);
                strcpy(n.garantie,garantie);
                strcpy(n.disponibilite,disponibilite);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;
                
             
                affichereq(treeview);
                
}
}


void
on_button_retgeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetrebienvenue;
    Fenetregeqag=lookup_widget(objet,"geqagr");
    gtk_widget_destroy(Fenetregeqag);
    Fenetrebienvenue=create_bienvenue();
    gtk_widget_show(Fenetrebienvenue);
}


void
on_button_hgcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;

  GtkWidget *Fenetreajeqag;
  GtkWidget *Fenetrescajeq;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *output1, *output2, *output3, *output6;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *type,*etat_fct;
  char ref[20];
  int b=1,v;

Fenetreajeqag=lookup_widget(objet,"ajeqag");
input1=lookup_widget(objet,"entry_hgrefaj");
input2=lookup_widget(objet,"entry_hgmtaj");
input3=lookup_widget(objet,"entry_hgmraj");
input4=lookup_widget(objet,"entry_hgfsaj");
type=lookup_widget(objet,"combobox_hgtpaj");
etat_fct=lookup_widget(objet,"combobox_hgefctaj");
jour=lookup_widget(objet,"spinbutton_hgjdfaj");
mois=lookup_widget(objet,"spinbutton_hgmdfaj");
annee=lookup_widget(objet,"spinbutton_hgadfaj");
output1=lookup_widget(objet,"label_hgsmataj");
output2=lookup_widget(objet,"label_hgsmraj");
output3=lookup_widget(objet,"label_hgsfsaj");
output6=lookup_widget(objet,"label_hgajsc");

strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.reference,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(n.matricule,gtk_entry_get_text(GTK_ENTRY(input2)));

if(strcmp(n.matricule,"")==0)
{
gtk_widget_show (output1);
b=0;
}

strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input3)));

if(strcmp(n.marque,"")==0)
{
gtk_widget_show (output2);
b=0;
}

strcpy(n.fournisseur,gtk_entry_get_text(GTK_ENTRY(input4)));

if(strcmp(n.fournisseur,"")==0)
{
gtk_widget_show (output3);
b=0;
}

strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat_fonctionnement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat_fct)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(p==1)
{strcpy(n.disponibilite,"oui");}
else
if(p==2)
{strcpy(n.disponibilite,"non");}

if(f==1)
{strcpy(n.garantie,"oui");}
else
if(f==0)
{strcpy(n.garantie,"non");}

v=verifeq(ref);


if (v==1)
{
gtk_widget_show (output6);
}
else
{
  if(b==1)
{
    ajoutereq(n);
    gtk_widget_destroy(Fenetreajeqag);
    Fenetrescajeq=create_scajeq();
    gtk_widget_show(Fenetrescajeq);
}
}

}


void
on_button_hganlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetreajeqag;
    Fenetreajeqag=lookup_widget(objet,"ajeqag");
    gtk_widget_destroy(Fenetreajeqag);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);

}


void
on_radiobutton_hgoaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
p=1;
}
}


void
on_radiobutton_hgnaj_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
p=2;
}
}


void
on_checkbutton_hgouiaj_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
f=1;
}
}


void
on_button_hgcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;

  GtkWidget *Fenetremdfeqag;
  GtkWidget *Fenetrescmdfeq;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *type,*etat_fct;


Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
input1=lookup_widget(objet,"combobox_hgrefmdf");
input2=lookup_widget(objet,"entry_hgmtmdf");
input3=lookup_widget(objet,"entry_hgmrmdf");
input4=lookup_widget(objet,"entry_hgfsmdf");
type=lookup_widget(objet,"combobox_hgtpmdf");
etat_fct=lookup_widget(objet,"combobox_hgefctmdf");
jour=lookup_widget(objet,"spinbutton_hgjdfmdf");
mois=lookup_widget(objet,"spinbutton_hgmdfmdf");
annee=lookup_widget(objet,"spinbutton_hgadfmdf");


strcpy(n.reference,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(n.matricule,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.marque,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(n.fournisseur,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat_fonctionnement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat_fct)));
n.date_mise_fct.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_mise_fct.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_mise_fct.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(q==1)
{strcpy(n.disponibilite,"oui");}
else
if(q==2)
{strcpy(n.disponibilite,"non");}

if(o==1)
{strcpy(n.garantie,"oui");}
else
if(o==0)
{strcpy(n.garantie,"non");}

modifiereq(n);


    gtk_widget_destroy(Fenetremdfeqag);
    Fenetrescmdfeq=create_scmdfeq();
    gtk_widget_show(Fenetrescmdfeq);
}


void
on_button_hganlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetremdfeqag;
    Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
    gtk_widget_destroy(Fenetremdfeqag);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);
}


void
on_checkbutton_hgouimdf_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
o=1;
}
}


void
on_radiobutton_hgomdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
q=1;
}
}


void
on_radiobutton_hgnmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
q=2;
}
}


void
on_button_hgvlmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;
  FILE *f;
  GtkWidget *Fenetremdfeqag;
  GtkWidget *id;
  GtkWidget *input2, *input3, *input4;
  GtkWidget *output1,*output2;
    char matricule1[20];
    char marque1[20];
    char fournisseur1[20];
    char ref1[20];
    char type1[20];
  

Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
id=lookup_widget(objet,"combobox_hgrefmdf");
input2=lookup_widget(objet,"entry_hgmtmdf");
input3=lookup_widget(objet,"entry_hgmrmdf");
input4=lookup_widget(objet,"entry_hgfsmdf");
output1=lookup_widget(objet,"label_hgchmdf");
output2=lookup_widget(objet,"label_hgsmmdf");


strcpy(ref1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("liste_des_equipements_agricoles.txt","r");
while (fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d \n",n.reference,n.matricule,n.type,n.marque,n.fournisseur,n.etat_fonctionnement,n.garantie,n.disponibilite,&n.date_mise_fct.jour,&n.date_mise_fct.mois,&n.date_mise_fct.annee)!=EOF)
{
if(strcmp(n.reference,ref1)==0)
{ 
strcpy(matricule1,n.matricule);
strcpy(marque1,n.marque);
strcpy(fournisseur1,n.fournisseur);
}
}
fclose(f);

gtk_entry_set_text(input2,matricule1);
gtk_entry_set_text(input3,marque1);
gtk_entry_set_text(input4,fournisseur1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_button_hganlchmdf_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetremdfeqag;
  GtkWidget *output1,*output2;

output1=lookup_widget(objet,"label_hgchmdf");
output2=lookup_widget(objet,"label_hgsmmdf");

gtk_widget_hide(output1);
gtk_widget_show (output2);

}


void
on_button_hgchmdf_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
  equi_agr n;
  FILE *f;
  GtkWidget *Fenetremdfeqag;
  GtkWidget *id;
  GtkWidget *output1,*output2,*cnf,*anl;
  

Fenetremdfeqag=lookup_widget(objet,"mdfeqag");
id=lookup_widget(objet,"combobox_hgrefmdf");
output1=lookup_widget(objet,"label_hgchmdf");
output2=lookup_widget(objet,"label_hgsmmdf");
cnf=lookup_widget(objet,"button_hgvlmdf");
anl=lookup_widget(objet,"button_hganlchmdf");


f=fopen("liste_des_equipements_agricoles.txt","r");
while (fscanf(f,"%s %s %s %s %s %s %s %s %d %d %d \n",n.reference,n.matricule,n.type,n.marque,n.fournisseur,n.etat_fonctionnement,n.garantie,n.disponibilite,&n.date_mise_fct.jour,&n.date_mise_fct.mois,&n.date_mise_fct.annee)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(n.reference));
}

fclose(f);

gtk_widget_hide(output2);
gtk_widget_show (output1);
gtk_widget_show (cnf);
gtk_widget_show (anl);
}


void
on_treeview_hgtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* reference;
	gchar* matricule;
	gchar* type;
	gchar* marque;
	gchar* fournisseur;
	gchar* etat_fct;
	gchar* garantie;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;
	gchar* disponibilite;

	equi_agr n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &reference, 1, &matricule, 2, &type , 3, &marque, 4, &fournisseur, 5, &etat_fct , 6, &garantie , 7, &disponibilite , 8, &jour_fct , 9, &mois_fct , 10, &annee_fct ,-1);
  		strcpy(n.reference,reference);
		strcpy(n.matricule,matricule);
		strcpy(n.type,type);
                strcpy(n.marque,marque);
		strcpy(n.fournisseur,fournisseur);
		strcpy(n.etat_fonctionnement,etat_fct);
                strcpy(n.garantie,garantie);
                strcpy(n.disponibilite,disponibilite);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;


         affichereq(treeview);
          }
}


void
on_button_hgretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetrerecheqag;
    Fenetrerecheqag=lookup_widget(objet,"recheqag");
    gtk_widget_destroy(Fenetrerecheqag);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);
}


void
on_button_hgcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerecheqag;
   GtkWidget *ref,*output1,*output2,*crt;
   GtkWidget *treeviewrech,*aff;
   char filtre[20];
   char critere[30];
   int t;

Fenetrerecheqag=lookup_widget(objet,"recheqag");
ref=lookup_widget(objet,"entry_hgrefrech");
output1=lookup_widget(objet,"label_hgtxtrech");
output2=lookup_widget(objet,"label_hgaltrech");
treeviewrech=lookup_widget(objet,"treeview_hgtxtrech");
crt=lookup_widget(objet,"combobox_hgcrrech");
aff=lookup_widget(objet,"scrolledwindowrecheqag");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(ref)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

t=verifrecheq(filtre);
if(t!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
   gtk_widget_hide (aff);
}
else
{
gtk_widget_show (aff);

   gtk_widget_hide(output2);
   gtk_widget_show (output1);
filtrecritereeq(treeviewrech, critere, filtre);
}
}


void
on_button_cnfsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *Fenetrescspeq;
   GtkWidget *ref;
   GtkWidget *output1,*output2,*output3;
   char refsp[20];
   int t;
Fenetresuppeq=lookup_widget(objet,"suppeqag");
ref=lookup_widget(objet,"entry_hgrefsupp");
output1=lookup_widget(objet,"label_hgalrsp");
output2=lookup_widget(objet,"label_hgflsp");
output3=lookup_widget(objet,"label_hgcnfsp");

strcpy(refsp,gtk_entry_get_text(GTK_ENTRY(ref)));

t=verifeq(refsp);
if(t!=1)
{
    gtk_widget_show (output2);
}
else
{
if(C==1)
{
    supprimereq(refsp);
    gtk_widget_show (output3);
    gtk_widget_destroy(Fenetresuppeq);
    Fenetrescspeq=create_scspeq();
    gtk_widget_show(Fenetrescspeq);
}
}
}


void
on_button_anlsuppeq_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqag;
    GtkWidget *Fenetresuppeq;

Fenetresuppeq=lookup_widget(objet,"suppeqag");

    gtk_widget_destroy(Fenetresuppeq);
    Fenetregeqag=create_geqagr();
    gtk_widget_show(Fenetregeqag);
}


void
on_radiobutton_hgosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *output1;
   GtkWidget *ref;

ref=lookup_widget(objet,"entry_hgrefsupp");
Fenetresuppeq=lookup_widget(objet,"suppeqag");
output1=lookup_widget(objet,"label_hgalrsp");
C=1;


    gtk_widget_show (output1);
}


void
on_radiobutton_hgnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppeq;
   GtkWidget *output1,*output2,*output3;

Fenetresuppeq=lookup_widget(objet,"suppeqag");
output1=lookup_widget(objet,"label_hgalrsp");
output2=lookup_widget(objet,"label_hgflsp");
output3=lookup_widget(objet,"label_hgcnfsp");
C=0;

gtk_widget_hide(output1);
}


void
on_button_okajeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqagr;
    GtkWidget *Fenetrescajeq;
    GtkWidget *treeview_leqag,*aff,*liste;
    Fenetrescajeq=lookup_widget(objet,"scajeq");
    gtk_widget_destroy(Fenetrescajeq);
    Fenetregeqagr=create_geqagr();
    gtk_widget_show(Fenetregeqagr);
treeview_leqag=lookup_widget(Fenetregeqagr,"treeview_leqag");
aff=lookup_widget(Fenetregeqagr,"scrolledwindowgeqag");
liste=lookup_widget(Fenetregeqagr,"label_leqag");

gtk_widget_show (liste);
gtk_widget_show (aff);

affichereq(treeview_leqag);
}


void
on_button_okmdfeq_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregeqagr;
    GtkWidget *Fenetrescmdfeq;
    GtkWidget *treeview_leqag,*aff,*liste;
    Fenetrescmdfeq=lookup_widget(objet,"scmdfeq");
    gtk_widget_destroy(Fenetrescmdfeq);
    Fenetregeqagr=create_geqagr();
    gtk_widget_show(Fenetregeqagr);
treeview_leqag=lookup_widget(Fenetregeqagr,"treeview_leqag");
aff=lookup_widget(Fenetregeqagr,"scrolledwindowgeqag");
liste=lookup_widget(Fenetregeqagr,"label_leqag");

gtk_widget_show (liste);
gtk_widget_show (aff);

affichereq(treeview_leqag);
}


void
on_button_okspeq_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetregeqagr;
    GtkWidget *Fenetrescspeq;
    GtkWidget *treeview_leqag,*aff,*liste;
    Fenetrescspeq=lookup_widget(objet,"scspeq");
    gtk_widget_destroy(Fenetrescspeq);
    Fenetregeqagr=create_geqagr();
    gtk_widget_show(Fenetregeqagr);
treeview_leqag=lookup_widget(Fenetregeqagr,"treeview_leqag");
aff=lookup_widget(Fenetregeqagr,"scrolledwindowgeqag");
liste=lookup_widget(Fenetregeqagr,"label_leqag");

gtk_widget_show (liste);
gtk_widget_show (aff);

affichereq(treeview_leqag);
}


void
on_button_ajtouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetreajtouv;
    Fenetregouv=lookup_widget(objet,"gouv");
    gtk_widget_destroy(Fenetregouv);
    Fenetreajtouv=create_ajtouv();
    gtk_widget_show(Fenetreajtouv);
}


void
on_button_mdfouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetremdfouv;
    Fenetregouv=lookup_widget(objet,"gouv");
    gtk_widget_destroy(Fenetregouv);
    Fenetremdfouv=create_mdfouv();
    gtk_widget_show(Fenetremdfouv);
}


void
on_button_suppouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetresuppouv;
    Fenetregouv=lookup_widget(objet,"gouv");
    gtk_widget_destroy(Fenetregouv);
    Fenetresuppouv=create_suppouv();
    gtk_widget_show(Fenetresuppouv);
}


void
on_button_affouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview_louv,*aff,*liste;
GtkWidget *Fenetregouv;
Fenetregouv=lookup_widget(objet,"gouv");
treeview_louv=lookup_widget(Fenetregouv,"treeview_louv");
aff=lookup_widget(Fenetregouv,"scrolledwindow_louv");
liste=lookup_widget(Fenetregouv,"label_mblouv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherouv(treeview_louv);
}


void
on_button_retouv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetrebienvenue;
    Fenetregouv=lookup_widget(objet,"gouv");
    gtk_widget_destroy(Fenetregouv);
    Fenetrebienvenue=create_bienvenue();
    gtk_widget_show(Fenetrebienvenue);
}


void
on_button_rechouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetrerechouv;
    Fenetregouv=lookup_widget(objet,"gouv");
    gtk_widget_destroy(Fenetregouv);
    Fenetrerechouv=create_rechouv();
    gtk_widget_show(Fenetrerechouv);
}


void
on_button_mbabs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetreabsouv;
    Fenetregouv=lookup_widget(objet,"gouv");
    gtk_widget_destroy(Fenetregouv);
    Fenetreabsouv=create_absouv();
    gtk_widget_show(Fenetreabsouv);
}


void
on_treeview_louv_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* prenom;
	gchar* sexe;
	gchar* tache;
	gchar* securite_sociale;
	gchar* jour_dn;
        gchar* mois_dn;
        gchar* annee_dn;

	ouvrier n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &prenom , 3, &sexe, 4, &tache, 5, &securite_sociale , 6, &jour_dn , 7, &mois_dn , 8, &annee_dn ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.prenom,prenom);
                strcpy(n.sexe,sexe);
		strcpy(n.tache,tache);
		strcpy(n.ss,securite_sociale);
                n.date_naissance.jour=jour_dn;
                n.date_naissance.mois=mois_dn;
                n.date_naissance.annee=annee_dn;
                
                
                afficherouv(treeview);
}
}


void
on_button_mbcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    ouvrier n ;
    GtkWidget *Fenetrescajouv;
    GtkWidget *Fenetreajtouv;
    GtkWidget *input1, *input2, *input3, *input4;
    GtkWidget *jour,*mois,*annee;
    GtkWidget *tache;
    GtkWidget *output1, *output2,*output3,*output4;
    int b=1,v;
    char id[20];

Fenetreajtouv=lookup_widget(objet,"ajtouv");
input1=lookup_widget(objet,"entry_mbidajt");
input2=lookup_widget(objet,"entry_mbnomajt");
input3=lookup_widget(objet,"entry_mbpreajt");
input4=lookup_widget(objet,"entry_mbssajt");
tache=lookup_widget(objet,"combobox_mbtfaj");
jour=lookup_widget(objet,"spinbutton_mbjdnajt");
mois=lookup_widget(objet,"spinbutton_mbmdnajt");
annee=lookup_widget(objet,"spinbutton_mbadnajt");
output1=lookup_widget(objet,"label_mbsnomaj");
output2=lookup_widget(objet,"label_mbspreaj");
output3=lookup_widget(objet,"label_mbsnsaj");
output4=lookup_widget(objet,"label_mbaltaj");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
if(strcmp(n.nom,"")==0)
{
gtk_widget_show (output1);
b=0;
}
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
if(strcmp(n.prenom,"")==0)
{
gtk_widget_show (output2);
b=0;
}
strcpy(n.ss,gtk_entry_get_text(GTK_ENTRY(input4)));
if(strcmp(n.ss,"")==0)
{
gtk_widget_show (output3);
b=0;
}
strcpy(n.tache,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tache)));
n.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(t==1)
{strcpy(n.sexe,"Masculin");}
else
if(t==2)
{strcpy(n.sexe,"Feminin");}

v=verifouv(id);
if (v==1)
{
gtk_widget_show (output4);
}
else
{
  if(b==1)
{
ajouterouv(n);

    gtk_widget_destroy(Fenetreajtouv);
    Fenetrescajouv=create_scajouv();
    gtk_widget_show(Fenetrescajouv);
}
}
}


void
on_button_mbanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetreajtouv;
    Fenetreajtouv=lookup_widget(objet,"ajtouv");
    gtk_widget_destroy(Fenetreajtouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
}


void
on_radiobutton_mbfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
t=2;
}
}


void
on_radiobutton_mbmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
t=1;
}
}


void
on_button_mbcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  ouvrier n;

  GtkWidget *Fenetremdfouv;
  GtkWidget *Fenetrescmdfouv;
  GtkWidget *input1, *input2, *input3, *input4;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *tf;

Fenetremdfouv=lookup_widget(objet,"mdfouv");
input1=lookup_widget(objet,"combobox_mbidmdf");
input2=lookup_widget(objet,"entry_mbnommdf");
input3=lookup_widget(objet,"entry_mbpremdf");
input4=lookup_widget(objet,"entry_mbssmdf");
tf=lookup_widget(objet,"combobox_mbtamdf");
jour=lookup_widget(objet,"spinbutton_mbjdnmdf");
mois=lookup_widget(objet,"spinbutton_mbmdnmdf");
annee=lookup_widget(objet,"spinbutton_mbadnmdf");

strcpy(n.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(n.ss,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.tache,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tf)));
n.date_naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(u==1)
{strcpy(n.sexe,"Masculin");}
else
if(u==2)
{strcpy(n.sexe,"Feminin");}

modifierouv(n);

    gtk_widget_destroy(Fenetremdfouv);
    Fenetrescmdfouv=create_scmdfouv();
    gtk_widget_show(Fenetrescmdfouv);
}


void
on_button_mbanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetremdfouv;
    Fenetremdfouv=lookup_widget(objet,"mdfouv");
    gtk_widget_destroy(Fenetremdfouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
}


void
on_radiobutton_mbmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
u=1;
}
}


void
on_radiobutton_mbfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
u=2;
}
}


void
on_button_mbvldchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  ouvrier n;
  FILE *f;
  GtkWidget *Fenetremdfouv;
  GtkWidget *id;
  GtkWidget *output1,*output2;
  GtkWidget *input1,*input2,*input3;
   char id1[20];
   char nom1[20];
   char prenom1[20];
   char ss1[20];

Fenetremdfouv=lookup_widget(objet,"mdfouv");
id=lookup_widget(objet,"combobox_mbidmdf");
output1=lookup_widget(objet,"label_mbvldch");
output2=lookup_widget(objet,"label_mbanlchid");
input1=lookup_widget(objet,"entry_mbnommdf");
input2=lookup_widget(objet,"entry_mbpremdf");
input3=lookup_widget(objet,"entry_mbssmdf");

strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
f=fopen("liste_des_ouvriers.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n",n.identifiant,n.nom,n.prenom,n.sexe,n.ss,n.tache,&n.date_naissance.jour,&n.date_naissance.mois,&n.date_naissance.annee)!=EOF)
{
if(strcmp(n.identifiant,id1)==0)
{
strcpy(nom1,n.nom);
strcpy(prenom1,n.prenom);
strcpy(ss1,n.ss);
}
}
fclose(f);

gtk_entry_set_text(input1,nom1);
gtk_entry_set_text(input2,prenom1);
gtk_entry_set_text(input3,ss1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_button_mbanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *Fenetremdfouv;
  GtkWidget *output1,*output2;

Fenetremdfouv=lookup_widget(objet,"mdfouv");
output1=lookup_widget(objet,"label_mbvldch");
output2=lookup_widget(objet,"label_mbanlchid");

gtk_widget_hide(output1);
gtk_widget_show (output2);
}


void
on_button_mbchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
  ouvrier n;
  FILE *f;
  GtkWidget *Fenetremdfouv;
  GtkWidget *id,*cnf,*anl;
  GtkWidget *output1,*output2;

Fenetremdfouv=lookup_widget(objet,"mdfouv");
id=lookup_widget(objet,"combobox_mbidmdf");
output1=lookup_widget(objet,"label_mbvldch");
output2=lookup_widget(objet,"label_mbanlchid");
cnf=lookup_widget(objet,"button_mbvldchid");
anl=lookup_widget(objet,"button_mbanlchid");

f=fopen("liste_des_ouvriers.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n",n.identifiant,n.nom,n.prenom,n.sexe,n.ss,n.tache,&n.date_naissance.jour,&n.date_naissance.mois,&n.date_naissance.annee)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(n.identifiant));
}
fclose(f);

gtk_widget_hide(output2);
gtk_widget_show (output1);
gtk_widget_show (cnf);
gtk_widget_show (anl);
}


void
on_button_mbretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetrerechouv;
    Fenetrerechouv=lookup_widget(objet,"rechouv");
    gtk_widget_destroy(Fenetrerechouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
}


void
on_button_mbcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerechouv;
   GtkWidget *id,*crt;
   GtkWidget *treeviewrech,*aff;
   GtkWidget *output1,*output2;
   char filtre[20];
   char critere[20];
   int v;
   
Fenetrerechouv=lookup_widget(objet,"rechouv");
id=lookup_widget(objet,"entry_mbidrech");
treeviewrech=lookup_widget(objet,"treeview_mbtxtrech");
output1=lookup_widget(objet,"label_mbtxtrech");
output2=lookup_widget(objet,"label_mbaltrech");
crt=lookup_widget(objet,"combobox_mbcrrech");
aff=lookup_widget(objet,"scrolledwindow_rechouv");


strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

v=verifrechouv(filtre);
if(v!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
gtk_widget_hide (aff);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
gtk_widget_show (aff);
filtrecritereouv(treeviewrech, critere, filtre);
}
}


void
on_treeview_mbtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* prenom;
	gchar* sexe;
	gchar* tache;
	gchar* securite_sociale;
	gchar* jour_dn;
        gchar* mois_dn;
        gchar* annee_dn;

	ouvrier n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &prenom , 3, &sexe, 4, &tache, 5, &securite_sociale , 6, &jour_dn , 7, &mois_dn , 8, &annee_dn ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.prenom,prenom);
                strcpy(n.sexe,sexe);
		strcpy(n.tache,tache);
		strcpy(n.ss,securite_sociale);
                n.date_naissance.jour=jour_dn;
                n.date_naissance.mois=mois_dn;
                n.date_naissance.annee=annee_dn;
                
                
                afficherouv(treeview);
}
}


void
on_button_mbretabs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetreabsouv;
    Fenetreabsouv=lookup_widget(objet,"absouv");
    gtk_widget_destroy(Fenetreabsouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
}


void
on_treeview_mbabs_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* abs;	

	ouv n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &jour, 2, &mois , 3, &annee, 4, &abs ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.abs,abs);
                n.date_abs.jour=jour;
                n.date_abs.mois=mois;
                n.date_abs.annee=annee;
                afficherabs(treeview);
}  
}


void
on_button_mbtabs_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
   ouv n;
   GtkWidget *Fenetreabsouv;
   GtkWidget *id;
   GtkWidget *treeviewabs,*aff;
   GtkWidget *mois,*annee;
   GtkWidget *output1,*output2,*output3;
   char idouv[20];
   char moisabs[20],anneeabs[20];

Fenetreabsouv=lookup_widget(objet,"absouv");
id=lookup_widget(objet,"combobox_mbidabs");
treeviewabs=lookup_widget(objet,"treeview_mbabs");
mois=lookup_widget(objet,"spinbutton1_mbmaffabs");
annee=lookup_widget(objet,"spinbutton_mbaaffabs");
output1=lookup_widget(objet,"label_mbscajabs");
output2=lookup_widget(objet,"label_mbscmdfabs");
output3=lookup_widget(objet,"label_mbscspabs");
aff=lookup_widget(Fenetreabsouv,"scrolledwindow_tabsouv");

strcpy(idouv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
sprintf(moisabs,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois)));
sprintf(anneeabs,"%d",gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee)));

rechabs(treeviewabs, idouv, moisabs, anneeabs);
gtk_widget_hide (output1);
gtk_widget_hide (output2);
gtk_widget_hide (output3);
gtk_widget_show (aff);
}


void
on_button_mbcnfabs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    ouv n;
    GtkWidget *Fenetreabsouv;
    GtkWidget *id,*jour,*mois,*annee,*aff;
    GtkWidget *output1,*output2,*output3,*output4;
    char idouv[20];
    int v,j,m,a;

Fenetreabsouv=lookup_widget(objet,"absouv");
id=lookup_widget(objet,"combobox_mbidabs");
jour=lookup_widget(objet,"spinbutton_mbjabs");
mois=lookup_widget(objet,"spinbutton_mbmabs");
annee=lookup_widget(objet,"spinbutton_mbaabs");
output1=lookup_widget(objet,"label_mbscajabs");
output2=lookup_widget(objet,"label_mbscmdfabs");
output3=lookup_widget(objet,"label_mbscspabs");
output4=lookup_widget(objet,"label_mbvrdate");
aff=lookup_widget(Fenetreabsouv,"scrolledwindow_tabsouv");

strcpy(idouv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(n.identifiant,idouv);
n.date_abs.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_abs.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_abs.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(w==0)
{n.abs=0;}
else
if(w==1)
{n.abs=1;}

v=verifdate(idouv,j,m,a);
if(v==1)
  {
gtk_widget_show (output4);
gtk_widget_hide (output1);
  }
else
  {
absentisme(n);

gtk_widget_show (output1);
gtk_widget_hide (output2);
gtk_widget_hide (output3);
gtk_widget_hide (output4);
  }
gtk_widget_hide (aff);
}


void
on_button_mbmdfabs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    ouv n;
    GtkWidget *Fenetreabsouv;
    GtkWidget *id,*jour,*mois,*annee,*aff;
    GtkWidget *output1,*output2,*output3,*output4;
    char idouv[20];

Fenetreabsouv=lookup_widget(objet,"absouv");
id=lookup_widget(objet,"combobox_mbidabs");
jour=lookup_widget(objet,"spinbutton_mbjabs");
mois=lookup_widget(objet,"spinbutton_mbmabs");
annee=lookup_widget(objet,"spinbutton_mbaabs");
output1=lookup_widget(objet,"label_mbscajabs");
output2=lookup_widget(objet,"label_mbscmdfabs");
output3=lookup_widget(objet,"label_mbscspabs");
output4=lookup_widget(objet,"label_mbvrdate");
aff=lookup_widget(Fenetreabsouv,"scrolledwindow_tabsouv");

strcpy(idouv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
strcpy(n.identifiant,idouv);
n.date_abs.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_abs.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_abs.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
if(w==0)
{n.abs=0;}
else
if(w==1)
{n.abs=1;}

modifierabs(n);

gtk_widget_show (output2);
gtk_widget_hide (output1);
gtk_widget_hide (output3);
gtk_widget_hide (output4);
gtk_widget_hide (aff);
}


void
on_button_mbspabs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetreabsouv;
    GtkWidget *Fenetresp;
   GtkWidget *id;
   GtkWidget *output1,*output2,*output3,*output4,*aff;

    Fenetreabsouv=lookup_widget(objet,"absouv");
id=lookup_widget(objet,"combobox_mbidabs");
output1=lookup_widget(objet,"label_mbscajabs");
output2=lookup_widget(objet,"label_mbscmdfabs");
output3=lookup_widget(objet,"label_mbscspabs");
output4=lookup_widget(objet,"label_mbvrdate");
aff=lookup_widget(Fenetreabsouv,"scrolledwindow_tabsouv");

strcpy(idouv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

    gtk_widget_destroy(Fenetreabsouv);
    Fenetresp=create_chspabsouv();
    gtk_widget_show(Fenetresp);
}


void
on_checkbutton_mboabs_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
w=1;
}
}


void
on_button_mbchidabs_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  ouvrier n;
  FILE *f;
  GtkWidget *Fenetreabsouv;
  GtkWidget *id;

Fenetreabsouv=lookup_widget(objet,"absouv");
id=lookup_widget(objet,"combobox_mbidabs");

f=fopen("liste_des_ouvriers.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %d %d %d \n",n.identifiant,n.nom,n.prenom,n.sexe,n.ss,n.tache,&n.date_naissance.jour,&n.date_naissance.mois,&n.date_naissance.annee)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(n.identifiant));
}
fclose(f);
}


void
on_button_mbcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrescspouv;
    GtkWidget *Fenetresuppouv;
    GtkWidget *id;
    GtkWidget *output;
   char idsp[20];
   int t;

    Fenetresuppouv=lookup_widget(objet,"suppouv");
id=lookup_widget(objet,"entry_mbidsp");
output=lookup_widget(objet,"label_mbaltsp");
strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));

t=verifouv(idsp);

if(t!=1)
{
    gtk_widget_show (output);
}
else
{
 if(D==1)
{
supprimerouv(idsp);

    gtk_widget_destroy(Fenetresuppouv);
    Fenetrescspouv=create_scspouv();
    gtk_widget_show(Fenetrescspouv);
}
}
}


void
on_button_mbanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetresuppouv;
    Fenetresuppouv=lookup_widget(objet,"suppouv");
    gtk_widget_destroy(Fenetresuppouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
}


void
on_radiobutton_mbnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppouv;
   GtkWidget *output1;

Fenetresuppouv=lookup_widget(objet,"suppouv");
output1=lookup_widget(objet,"label_mbcnfsp");
D=0;

    gtk_widget_hide (output1);
}


void
on_radiobutton_mbosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresuppouv;
   GtkWidget *output1;

Fenetresuppouv=lookup_widget(objet,"suppouv");
output1=lookup_widget(objet,"label_mbcnfsp");
D=1;

    gtk_widget_show (output1);
}


void
on_button_okajouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetrescajouv;
    GtkWidget *treeview_louv,*aff,*liste;
    Fenetrescajouv=lookup_widget(objet,"scajouv");
    gtk_widget_destroy(Fenetrescajouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
    treeview_louv=lookup_widget(Fenetregouv,"treeview_louv");
aff=lookup_widget(Fenetregouv,"scrolledwindow_louv");
liste=lookup_widget(Fenetregouv,"label_mblouv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherouv(treeview_louv);
}


void
on_button_okmdfouv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetrescmdfouv;
    GtkWidget *treeview_louv,*aff,*liste;
    Fenetrescmdfouv=lookup_widget(objet,"scmdfouv");
    gtk_widget_destroy(Fenetrescmdfouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
    treeview_louv=lookup_widget(Fenetregouv,"treeview_louv");
aff=lookup_widget(Fenetregouv,"scrolledwindow_louv");
liste=lookup_widget(Fenetregouv,"label_mblouv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherouv(treeview_louv);
}


void
on_button_okspouv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregouv;
    GtkWidget *Fenetrescspouv;
    GtkWidget *treeview_louv,*aff,*liste;
    Fenetrescspouv=lookup_widget(objet,"scspouv");
    gtk_widget_destroy(Fenetrescspouv);
    Fenetregouv=create_gouv();
    gtk_widget_show(Fenetregouv);
treeview_louv=lookup_widget(Fenetregouv,"treeview_louv");
aff=lookup_widget(Fenetregouv,"scrolledwindow_louv");
liste=lookup_widget(Fenetregouv,"label_mblouv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherouv(treeview_louv);
}


void
on_treeview_lplv_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* type;
	gchar* quantite;
	gchar* jour_pl;
        gchar* mois_pl;
        gchar* annee_pl;
	gchar* jour_ir;
        gchar* mois_ir;
        gchar* annee_ir;
	gchar* temperature;
	gchar* humidite;
	gchar* zone;
	plantation n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &type , 3, &quantite , 4, &jour_pl, 5, &mois_pl, 6, &annee_pl , 7, &jour_ir , 8, &mois_ir , 9, &annee_ir , 10, &temperature, 11, &humidite , 12, &zone ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.type,type);
                strcpy(n.quantite,quantite);
                n.date_plantation.jour=jour_pl;
                n.date_plantation.mois=mois_pl;
                n.date_plantation.annee=annee_pl;
                n.date_irrigation.jour=jour_ir;
                n.date_irrigation.mois=mois_ir;
                n.date_irrigation.annee=annee_ir;
		strcpy(n.temperature,temperature);
                strcpy(n.humidite,humidite);
                strcpy(n.zone,zone);


                
                afficherpl(treeview);
}
}


void
on_button_retplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window2;
    window1=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window1);
    window2=create_bienvenue();
    gtk_widget_show(window2);
}


void
on_button_rechplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window2;
    window1=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window1);
    window2=create_rechplv();
    gtk_widget_show(window2);
}


void
on_button_afflplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview1,*aff,*liste;
    GtkWidget *window1;

window1=lookup_widget(objet,"gpl");
treeview1=lookup_widget(window1,"treeview_lplv");
aff=lookup_widget(window1,"scrolledwindow_gplv");
liste=lookup_widget(window1,"label_nbrplv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherpl(treeview1);
}


void
on_button_ajplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window2;
    window1=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window1);
    window2=create_ajplv();
    gtk_widget_show(window2);
}


void
on_button_mdfplv_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window3;
    window3=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window3);
    window1=create_mdfplv();
    gtk_widget_show(window1);
}


void
on_button_spplv_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *windowsp;
    window1=lookup_widget(objet,"gpl");
    gtk_widget_destroy(window1);
    windowsp=create_spplv();
    gtk_widget_show(windowsp);
}


void
on_checkbutton_sdzaaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=1;
}
}


void
on_checkbutton_sdzbaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=2;
}
}


void
on_checkbutton_sdzcaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=3;
}
}


void
on_checkbutton_sdzdaj_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
x=4;
}
}


void
on_button_sdcnfaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
 plantation n;

  GtkWidget *window2;
  GtkWidget *window1;
  GtkWidget *input1, *input2, *input3, *input5, *input6;
  GtkWidget *output1, *output2, *output4, *output5, *output6;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *jir,*mir,*air;
  GtkWidget *type;
  char id[20];
  int b=1,v;

  window2=lookup_widget(objet,"ajplv");
  input1=lookup_widget(objet,"entry_sdidaj");
  input2=lookup_widget(objet,"entry_sdnomaj");
  type=lookup_widget(objet,"combobox_sdtpaj");
  input3=lookup_widget(objet,"entry_sdqnaj");
  jour=lookup_widget(objet,"spinbutton_sdjdpaj");
  mois=lookup_widget(objet,"spinbutton_sdmdpaj");
  annee=lookup_widget(objet,"spinbutton_sdadpaj");
  jir=lookup_widget(objet,"spinbutton_sdjdiaj");
  mir=lookup_widget(objet,"spinbutton_sdmdiaj");
  air=lookup_widget(objet,"spinbutton_sdadiaj");
  input5=lookup_widget(objet,"entry_sdtmaj");
  input6=lookup_widget(objet,"entry_sdhmaj");
output1=lookup_widget(objet,"label_sdsnomaj");
output2=lookup_widget(objet,"label_sdsqnaj");
output4=lookup_widget(objet,"label_sdstmaj");
output5=lookup_widget(objet,"label_sdshmaj");
output6=lookup_widget(objet,"label_sdaltaj");

strcpy(n.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
if(strcmp(n.nom,"")==0)
{
gtk_widget_show (output1);
b=0;
}
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));

if(strcmp(n.quantite,"")==0)
{
gtk_widget_show (output2);
b=0;
}

n.date_plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_plantation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
n.date_irrigation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jir));
n.date_irrigation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mir));
n.date_irrigation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(air));

strcpy(n.temperature,gtk_entry_get_text(GTK_ENTRY(input5)));
if(strcmp(n.temperature,"")==0)
{
gtk_widget_show (output4);
b=0;
}

strcpy(n.humidite,gtk_entry_get_text(GTK_ENTRY(input6)));
if(strcmp(n.humidite,"")==0)
{
gtk_widget_show (output5);
b=0;
}

if(x==1)
{strcpy(n.zone,"zone-A");}
else
if(x==2)
{strcpy(n.zone,"zone-B");}
else
if(x==3)
{strcpy(n.zone,"zone-C");}
else
if(x==4)
{strcpy(n.zone,"zone-D");}


v=verifpl(id);


if (v==1)
{
gtk_widget_show (output6);
}
else
{
  if(b==1)
{
ajouterpl(n);

    gtk_widget_destroy(window2);
    window1=create_scajplv();
    gtk_widget_show(window1);

}
}

}


void
on_button_sdanlaj_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window2;
    window2=lookup_widget(objet,"ajplv");
    gtk_widget_destroy(window2);
    window1=create_gpl();
    gtk_widget_show(window1);
}


void
on_checkbutton_sdzamdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=1;
}
}


void
on_checkbutton_sdzbmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=2;
}
}


void
on_checkbutton_sdzcmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=3;
}
}


void
on_checkbutton_sdzdmdf_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{
y=4;
}
}


void
on_button_sdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
  plantation n;
  FILE *f;
  GtkWidget *window3;
  GtkWidget *id,*cnf,*anl;
  GtkWidget *output1,*output2;
  

window3=lookup_widget(objet,"mdfplv");
id=lookup_widget(objet,"combobox_sdidmdf");
output1=lookup_widget(objet,"label_sdmsgchid");
output2=lookup_widget(objet,"label_sdanlchid");
cnf=lookup_widget(objet,"button_sdvlchid");
anl=lookup_widget(objet,"button_sdanlchid");

f=fopen("plantation.txt","r");
while (fscanf(f,"%s %s %s %s %d %d %d  %d %d %d %s %s %s \n",n.identifiant,n.nom,n.type,n.quantite,&n.date_plantation.jour,&n.date_plantation.mois,&n.date_plantation.annee,&n.date_irrigation.jour,&n.date_irrigation.mois,&n.date_irrigation.annee,n.temperature,n.humidite,n.zone)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(n.identifiant));
}

fclose(f);

gtk_widget_hide(output2);
gtk_widget_show (output1);
gtk_widget_show (anl);
gtk_widget_show (cnf);
}


void
on_button_sdvlchid_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  plantation n;
  FILE *f;
  GtkWidget *window3;
  GtkWidget *id;
  GtkWidget *input2, *input3, *input4, *input5;
  GtkWidget *output1,*output2;
    char nom1[20];
    char quantite1[20];
    char temperature1[20];
    char humidite1[20];
    char id1[20];
  

window3=lookup_widget(objet,"mdfplv");
id=lookup_widget(objet,"combobox_sdidmdf");
input2=lookup_widget(objet,"entry_sdnommdf");
input3=lookup_widget(objet,"entry_sdqnmdf");
input4=lookup_widget(objet,"entry_sdtmmdf");
input5=lookup_widget(objet,"entry_sdhmmdf");
output1=lookup_widget(objet,"label_sdmsgchid");
output2=lookup_widget(objet,"label_sdanlchid");

strcpy(id1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("plantation.txt","r");
while (fscanf(f,"%s %s %s %s %d %d %d  %d %d %d %s %s %s \n",n.identifiant,n.nom,n.type,n.quantite,&n.date_plantation.jour,&n.date_plantation.mois,&n.date_plantation.annee,&n.date_irrigation.jour,&n.date_irrigation.mois,&n.date_irrigation.annee,n.temperature,n.humidite,n.zone)!=EOF)
{
if(strcmp(n.identifiant,id1)==0)
{ 
strcpy(nom1,n.nom);
strcpy(quantite1,n.quantite);
strcpy(temperature1,n.temperature);
strcpy(humidite1,n.humidite);
}
}
fclose(f);

gtk_entry_set_text(input2,nom1);
gtk_entry_set_text(input3,quantite1);
gtk_entry_set_text(input4,temperature1);
gtk_entry_set_text(input5,humidite1);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_button_sdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  GtkWidget *window3;
  GtkWidget *output1,*output2;
output1=lookup_widget(objet,"label_sdmsgchid");
output2=lookup_widget(objet,"label_sdanlchid");

gtk_widget_hide(output1);
gtk_widget_show (output2);

}


void
on_button_sdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  plantation n;

  GtkWidget *window3;
  GtkWidget *window1;
  GtkWidget *input1, *input2, *input3, *input4, *input5;
  GtkWidget *jour,*mois,*annee;
  GtkWidget *jir,*mir,*air;
  GtkWidget *type;

window3=lookup_widget(objet,"mdfplv");
input1=lookup_widget(objet,"combobox_sdidmdf");
input2=lookup_widget(objet,"entry_sdnommdf");
type=lookup_widget(objet,"combobox_sdtpmdf");
input3=lookup_widget(objet,"entry_sdqnmdf");
jour=lookup_widget(objet,"spinbutton_sdjdpmdf");
mois=lookup_widget(objet,"spinbutton_sdmdpmdf");
annee=lookup_widget(objet,"spinbutton_sdadpmdf");
jir=lookup_widget(objet,"spinbutton_sdjdimdf");
mir=lookup_widget(objet,"spinbutton_sdmdimdf");
air=lookup_widget(objet,"spinbutton_sdadimdf");
input4=lookup_widget(objet,"entry_sdtmmdf");
input5=lookup_widget(objet,"entry_sdhmmdf");
strcpy(n.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(n.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.quantite,gtk_entry_get_text(GTK_ENTRY(input3)));
n.date_plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
n.date_plantation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
n.date_plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
n.date_irrigation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jir));
n.date_irrigation.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mir));
n.date_irrigation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(air));
strcpy(n.temperature,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(n.humidite,gtk_entry_get_text(GTK_ENTRY(input5)));
if(y==1)
{strcpy(n.zone,"zone-A");}
else
if(y==2)
{strcpy(n.zone,"zone-B");}
else
if(y==3)
{strcpy(n.zone,"zone-C");}
else
if(y==3)
{strcpy(n.zone,"zone-D");}

modifierpl(n);

    gtk_widget_destroy(window3);
    window1=create_scmdfplv();
    gtk_widget_show(window1);
}


void
on_button_sdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    window4=lookup_widget(objet,"mdfplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
}


void
on_button_sdcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *window4;
   GtkWidget *window1;
   GtkWidget *id;
   GtkWidget *output1,*output2;
   char idsup[20];
   int t;

window4=lookup_widget(objet,"spplv");
id=lookup_widget(objet,"entry_sdidsp");
output1=lookup_widget(objet,"label_sdmsgsp");
output2=lookup_widget(objet,"label_sdaltsp");
strcpy(idsup,gtk_entry_get_text(GTK_ENTRY(id)));
t=verifpl(idsup);
if(t!=1)
{
    gtk_widget_show (output2);
}
else
{
if(E==1)
{
supprimerpl(idsup);
    gtk_widget_destroy(window4);
    window1=create_scspplv();
    gtk_widget_show(window1);
}


}
}


void
on_button_sdanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    window4=lookup_widget(objet,"spplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
}


void
on_radiobutton_sdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *window4;
   GtkWidget *output1,*output2,*output3;

window4=lookup_widget(objet,"spplv");
output1=lookup_widget(objet,"label_sdmsgsp");
E=0;

gtk_widget_hide(output1);
}


void
on_radiobutton_sdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window4;
   GtkWidget *output1;

window4=lookup_widget(objet,"spplv");
output1=lookup_widget(objet,"label_sdmsgsp");
E=1;

   gtk_widget_show (output1);
}


void
on_treeview_rechplv_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	gchar* nom;
	gchar* type;
	gchar* quantite;
	gchar* jour_pl;
        gchar* mois_pl;
        gchar* annee_pl;
	gchar* jour_ir;
        gchar* mois_ir;
        gchar* annee_ir;
	gchar* temperature;
	gchar* humidite;
	gchar* zone;
	plantation n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &nom, 2, &type , 3, &quantite , 4, &jour_pl, 5, &mois_pl, 6, &annee_pl , 7, &jour_ir , 8, &mois_ir , 9, &annee_ir , 10, &temperature, 11, &humidite , 12, &zone ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.nom,nom);
		strcpy(n.type,type);
                strcpy(n.quantite,quantite);
                n.date_plantation.jour=jour_pl;
                n.date_plantation.mois=mois_pl;
                n.date_plantation.annee=annee_pl;
                n.date_irrigation.jour=jour_ir;
                n.date_irrigation.mois=mois_ir;
                n.date_irrigation.annee=annee_ir;
		strcpy(n.temperature,temperature);
                strcpy(n.humidite,humidite);
                strcpy(n.zone,zone);


                
                afficherpl(treeview);
}
}


void
on_button_sdidrech_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *window1;
   GtkWidget *id,*output1,*output2,*crt;
   GtkWidget *treeview_rechplv,*aff;
   char filtre[20];
   char critere[30];
   int t;

window1=lookup_widget(objet,"rechplv");
id=lookup_widget(objet,"entry_sdidrech");
output1=lookup_widget(objet,"label_sdrsrech");
output2=lookup_widget(objet,"labelsdr57");
treeview_rechplv=lookup_widget(objet,"treeview_rechplv");
crt=lookup_widget(objet,"combobox_sdcrrech");
aff=lookup_widget(objet,"scrolledwindow_rechplv");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

t=verifrechpl(filtre);
if(t!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
gtk_widget_hide (aff);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
   gtk_widget_show (aff);
filtrecriterepl(treeview_rechplv, critere, filtre);
}
}


void
on_button_sdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window5;
    GtkWidget *window1;
    window5=lookup_widget(objet,"rechplv");
    gtk_widget_destroy(window5);
    window1=create_gpl();
    gtk_widget_show(window1);
}


void
on_button_okajplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    GtkWidget *treeview_lplv,*aff,*liste;
    window4=lookup_widget(objet,"scajplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
treeview_lplv=lookup_widget(window1,"treeview_lplv");
aff=lookup_widget(window1,"scrolledwindow_gplv");
liste=lookup_widget(window1,"label_nbrplv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherpl(treeview_lplv);
}


void
on_button_okmdfplv_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    GtkWidget *treeview_lplv,*aff,*liste;
    window4=lookup_widget(objet,"scmdfplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
treeview_lplv=lookup_widget(window1,"treeview_lplv");
aff=lookup_widget(window1,"scrolledwindow_gplv");
liste=lookup_widget(window1,"label_nbrplv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherpl(treeview_lplv);
}


void
on_button_okspplv_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *window1;
    GtkWidget *window4;
    GtkWidget *treeview_lplv,*aff,*liste;
    window4=lookup_widget(objet,"scspplv");
    gtk_widget_destroy(window4);
    window1=create_gpl();
    gtk_widget_show(window1);
treeview_lplv=lookup_widget(window1,"treeview_lplv");
aff=lookup_widget(window1,"scrolledwindow_gplv");
liste=lookup_widget(window1,"label_nbrplv");

gtk_widget_show (liste);
gtk_widget_show (aff);
afficherpl(treeview_lplv);
}


void
on_button_ajtrp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetreajttroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetreajttroup=create_ajttroup();
    gtk_widget_show(Fenetreajttroup);
}


void
on_button_afftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp,*aff,*liste;
    GtkWidget *Fenetregtroup;

Fenetregtroup=lookup_widget(objet,"gtroup");
treeview_ltrp=lookup_widget(Fenetregtroup,"treeview_ltrp");
aff=lookup_widget(Fenetregtroup,"scrolledwindow_gtrp");
liste=lookup_widget(Fenetregtroup,"label_ltrp");

gtk_widget_show (liste);
gtk_widget_show (aff);
affichertrp(treeview_ltrp);
}


void
on_button_mdftrp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetremdftroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetremdftroup=create_mdftroup();
    gtk_widget_show(Fenetremdftroup);
}


void
on_button_supptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetresupptroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetresupptroup=create_supptroup();
    gtk_widget_show(Fenetresupptroup);
}


void
on_button_kdgrch_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
     GtkWidget *Fenetregtroup;
    GtkWidget *Fenetrerechtroup;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    Fenetrerechtroup=create_rechtroup();
    gtk_widget_show(Fenetrerechtroup);
}


void
on_button_retgtrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *bienvenue;
    Fenetregtroup=lookup_widget(objet,"gtroup");
    gtk_widget_destroy(Fenetregtroup);
    bienvenue=create_bienvenue();
    gtk_widget_show(bienvenue);
}


void
on_treeview_ltrp_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* type;
	gchar* genre;
	gchar* etat_sanitaire;
	gchar* j_naissance;
	gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_vaccin;
        gchar* m_vaccin;
	gchar* a_vaccin;

	troupeaux n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &type, 2, &genre , 3, &etat_sanitaire, 4, &j_naissance, 5, &m_naissance , 6, &a_naissance , 7, &j_vaccin , 8, &m_vaccin , 9, &a_vaccin ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.type,type);
                strcpy(n.genre,genre);
		strcpy(n.etat,etat_sanitaire);
		n.naissance.jour=j_naissance;
                n.naissance.mois=m_naissance;
                n.naissance.annee=a_naissance;
                n.vaccin.jour=j_vaccin;
                n.vaccin.mois=m_vaccin;
                n.vaccin.annee=a_vaccin;
                
                
                affichertrp(treeview);
}
}


void
on_radiobutton_kdmajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
s=1;
}
}


void
on_radiobutton_kdfajt_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
s=2;
}
}


void
on_button_kdanlajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetreajttroup;
    Fenetreajttroup=lookup_widget(objet,"ajttroup");
    gtk_widget_destroy(Fenetreajttroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_button_kdcnfajt_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  troupeaux n;
  GtkWidget *Fenetreajttroup;
  GtkWidget *Fenetrescajtrp;
  GtkWidget *input;
  GtkWidget *jourdn,*moisdn,*anneedn,*jourvc,*moisvc,*anneevc;
  GtkWidget *type,*etat;
  GtkWidget *output1;
  int v;
  char id[20];

Fenetreajttroup=lookup_widget(objet,"ajttroup");
input=lookup_widget(objet,"entry_kdidajt");
jourdn=lookup_widget(objet,"spinbutton_kdjdnajt");
moisdn=lookup_widget(objet,"spinbutton_kdmdnajt");
anneedn=lookup_widget(objet,"spinbutton_kdadnajt");
type=lookup_widget(objet,"combobox_kdtpaj");
etat=lookup_widget(objet,"combobox_kdesaj");
jourvc=lookup_widget(objet,"spinbutton_kdjdvajt");
moisvc=lookup_widget(objet,"spinbutton_kdmdvajt");
anneevc=lookup_widget(objet,"spinbutton_kdadvajt");
output1=lookup_widget(objet,"label_kdaltaj");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(n.identifiant,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat)));
n.naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourdn));
n.naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisdn));
n.naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneedn));
n.vaccin.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourvc));
n.vaccin.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisvc));
n.vaccin.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneevc));

if(s==1)
{strcpy(n.genre,"Male");}
else
 if(s==2)
{strcpy(n.genre,"Femelle");}

v=veriftrp(id);

if (v==1)
{
gtk_widget_show (output1);
}
else
{
ajoutertrp(n);

    gtk_widget_destroy(Fenetreajttroup);
    Fenetrescajtrp=create_scajtrp();
    gtk_widget_show(Fenetrescajtrp);
}

}


void
on_button_kdanlmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetremdftroup;
    Fenetremdftroup=lookup_widget(objet,"mdftroup");
    gtk_widget_destroy(Fenetremdftroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_button_kdcnfmdf_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
  troupeaux n;
  GtkWidget *Fenetremdftroup;
  GtkWidget *Fenetrescmdftrp;
  GtkWidget *input;
  GtkWidget *jourdn,*moisdn,*anneedn,*jourvc,*moisvc,*anneevc;
  GtkWidget *type,*etat;
{
Fenetremdftroup=lookup_widget(objet,"mdftroup");
input=lookup_widget(objet,"combobox_kdidmdf");
jourdn=lookup_widget(objet,"spinbutton_kdjdnmdf");
moisdn=lookup_widget(objet,"spinbutton_kdmdnmdf");
anneedn=lookup_widget(objet,"spinbutton_kdadnmdf");
type=lookup_widget(objet,"combobox_kdtpmdf");
etat=lookup_widget(objet,"combobox_kdesmdf");
jourvc=lookup_widget(objet,"spinbutton_kdjdvmdf");
moisvc=lookup_widget(objet,"spinbutton_kdmdvmdf");
anneevc=lookup_widget(objet,"spinbutton_kdadvmdf");

strcpy(n.identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input)));
strcpy(n.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(n.etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(etat)));
n.naissance.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourdn));
n.naissance.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisdn));
n.naissance.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneedn));
n.vaccin.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourvc));
n.vaccin.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moisvc));
n.vaccin.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneevc));
} 
if(v==1)
{strcpy(n.genre,"Male");}
else
 if(v==2)
{strcpy(n.genre,"Femelle");}
 
modifiertrp(n);
 
    gtk_widget_destroy(Fenetremdftroup);
    Fenetrescmdftrp=create_scmdftrp();
    gtk_widget_show(Fenetrescmdftrp);
}


void
on_radiobutton_kdmmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
v=1;
}
}


void
on_radiobutton_kdfmdf_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{
v=2;
}
}


void
on_button_kdvldchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
  troupeaux t;
  FILE *f;
    GtkWidget *Fenetremdftroup;
    GtkWidget *output1,*output2,*id,*type;
    char identifiant[20];

Fenetremdftroup=lookup_widget(objet,"mdftroup");
output1=lookup_widget(objet,"label_kdchidmdf");
output2=lookup_widget(objet,"label_kdanlchid");
id=lookup_widget(objet,"combobox_kdidmdf");
type=lookup_widget(objet,"combobox_kdtpmdf");

strcpy(identifiant,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));

f=fopen("liste_troupeaux.txt","r");
 while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",t.identifiant,t.type,t.genre,t.etat,&t.naissance.jour,&t.naissance.mois,&t.naissance.annee,&t.vaccin.jour,&t.vaccin.mois,&t.vaccin.annee)!=EOF)
       {
if(strcmp(t.identifiant,identifiant)==0)
{ 
gtk_combo_box_append_text (GTK_COMBO_BOX(type),_(t.type));
}
}
fclose(f);

gtk_widget_hide(output2);
gtk_widget_hide(output1);
}


void
on_button_kdanlchid_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetremdftroup;
    GtkWidget *output1,*output2;

Fenetremdftroup=lookup_widget(objet,"mdftroup");
output1=lookup_widget(objet,"label_kdchidmdf");
output2=lookup_widget(objet,"label_kdanlchid");

gtk_widget_hide(output1);
gtk_widget_show (output2);
}


void
on_button_kdchid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
  troupeaux t;
  FILE *f;
  GtkWidget *Fenetremdftroup;
  GtkWidget *id,*cnf,*anl;
  GtkWidget *output1,*output2;

Fenetremdftroup=lookup_widget(objet,"mdftroup");
id=lookup_widget(objet,"combobox_kdidmdf");
output1=lookup_widget(objet,"label_kdchidmdf");
output2=lookup_widget(objet,"label_kdanlchid");
cnf=lookup_widget(objet,"button_kdvldchid");
anl=lookup_widget(objet,"button_kdanlchid");

f=fopen("liste_troupeaux.txt","r");
 while(fscanf(f,"%s %s %s %s %d %d %d %d %d %d\n",t.identifiant,t.type,t.genre,t.etat,&t.naissance.jour,&t.naissance.mois,&t.naissance.annee,&t.vaccin.jour,&t.vaccin.mois,&t.vaccin.annee)!=EOF)
       {
gtk_combo_box_append_text (GTK_COMBO_BOX(id),_(t.identifiant));
       }
fclose(f);

gtk_widget_hide(output2);
gtk_widget_show (output1);
gtk_widget_show (cnf);
gtk_widget_show (anl);
}


void
on_button_kdretrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
     GtkWidget *Fenetregtroup;
    GtkWidget *Fenetrerechtroup;
    Fenetrerechtroup=lookup_widget(objet,"rechtroup");
    gtk_widget_destroy(Fenetrerechtroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_treeview_kdtxtrech_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
       GtkTreeIter iter;
	gchar* identifiant;
	gchar* type;
	gchar* genre;
	gchar* etat_sanitaire;
	gchar* j_naissance;
	gchar* m_naissance;
	gchar* a_naissance;
        gchar* j_vaccin;
        gchar* m_vaccin;
	gchar* a_vaccin;

	troupeaux n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &type, 2, &genre , 3, &etat_sanitaire, 4, &j_naissance, 5, &m_naissance , 6, &a_naissance , 7, &j_vaccin , 8, &m_vaccin , 9, &a_vaccin ,-1);
  		strcpy(n.identifiant,identifiant);
		strcpy(n.type,type);
                strcpy(n.genre,genre);
		strcpy(n.etat,etat_sanitaire);
		n.naissance.jour=j_naissance;
                n.naissance.mois=m_naissance;
                n.naissance.annee=a_naissance;
                n.vaccin.jour=j_vaccin;
                n.vaccin.mois=m_vaccin;
                n.vaccin.annee=a_vaccin;
                
                
                affichertrp(treeview);
}
}


void
on_button_kdcnfrech_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetrerechtroup;
   GtkWidget *id,*output1,*output2,*crt;
   GtkWidget *treeviewrech,*aff;
   char filtre[20];
   char critere[20];
   int v;
   
Fenetrerechtroup=lookup_widget(objet,"rechtroup");
id=lookup_widget(objet,"entry_kdidrech");
output1=lookup_widget(objet,"label_kdtxtrech");
output2=lookup_widget(objet,"label_kdaltrech");
treeviewrech=lookup_widget(objet,"treeview_kdtxtrech");
crt=lookup_widget(objet,"combobox_kdcrrech");
aff=lookup_widget(objet,"scrolledwindow_rechtrp");

strcpy(filtre,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(crt)));

v=verifrechtrp(filtre);

if(v!=1)
{
   gtk_widget_hide(output1);
    gtk_widget_show (output2);
   gtk_widget_hide (aff);
}
else
{
   gtk_widget_hide(output2);
   gtk_widget_show (output1);
   gtk_widget_show (aff);
filtrecriteretrp(treeviewrech, critere, filtre);
}
}


void
on_button_khcnfsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresupptroup;
   GtkWidget *Fenetrescsptrp;
   GtkWidget *id;
   GtkWidget *output1,*output2;
   char idsp[20];
   int v;

Fenetresupptroup=lookup_widget(objet,"supptroup");
id=lookup_widget(objet,"entry_khidsp");
output1=lookup_widget(objet,"label_khcnfsp");
output2=lookup_widget(objet,"label_kdaltsp");

strcpy(idsp,gtk_entry_get_text(GTK_ENTRY(id)));

v=veriftrp(idsp);
if(v!=1)
{
    gtk_widget_show (output2);
}
else
{
if(F==1)
{
supprimertrp(idsp);

    gtk_widget_destroy(Fenetresupptroup);
    Fenetrescsptrp=create_scsptrp();
    gtk_widget_show(Fenetrescsptrp);
}
}

}


void
on_button_khanlsp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetregtroup;
    GtkWidget *Fenetresupptroup;
    Fenetresupptroup=lookup_widget(objet,"supptroup");
    gtk_widget_destroy(Fenetresupptroup);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);
}


void
on_radiobutton_kdnsp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresupptroup;
   GtkWidget *output1;

Fenetresupptroup=lookup_widget(objet,"supptroup");
output1=lookup_widget(objet,"label_khcnfsp");
F=0;

gtk_widget_hide(output1);
}


void
on_radiobutton_kdosp_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
   GtkWidget *Fenetresupptroup;
   GtkWidget *output1;
   GtkWidget *id;

Fenetresupptroup=lookup_widget(objet,"supptroup");
output1=lookup_widget(objet,"label_khcnfsp");
F=1;

    gtk_widget_show (output1);

}


void
on_button_okscajtrp_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp,*aff,*liste;
    GtkWidget *Fenetrescajtrp;
    GtkWidget *Fenetregtroup;


Fenetrescajtrp=lookup_widget(objet,"scajtrp");
    gtk_widget_destroy(Fenetrescajtrp);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);

treeview_ltrp=lookup_widget(Fenetregtroup,"treeview_ltrp");
aff=lookup_widget(Fenetregtroup,"scrolledwindow_gtrp");
liste=lookup_widget(Fenetregtroup,"label_ltrp");

gtk_widget_show (liste);
gtk_widget_show (aff);
affichertrp(treeview_ltrp);
}


void
on_button_okmdftrp_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp,*aff,*liste;
    GtkWidget *Fenetrescmdftrp;
    GtkWidget *Fenetregtroup;


Fenetrescmdftrp=lookup_widget(objet,"scmdftrp");
    gtk_widget_destroy(Fenetrescmdftrp);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);

treeview_ltrp=lookup_widget(Fenetregtroup,"treeview_ltrp");
aff=lookup_widget(Fenetregtroup,"scrolledwindow_gtrp");
liste=lookup_widget(Fenetregtroup,"label_ltrp");

gtk_widget_show (liste);
gtk_widget_show (aff);
affichertrp(treeview_ltrp);
}


void
on_button_oksptrp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *treeview_ltrp,*aff,*liste;
    GtkWidget *Fenetrescsptrp;
    GtkWidget *Fenetregtroup;

Fenetrescsptrp=lookup_widget(objet,"scsptrp");
    gtk_widget_destroy(Fenetrescsptrp);
    Fenetregtroup=create_gtroup();
    gtk_widget_show(Fenetregtroup);

treeview_ltrp=lookup_widget(Fenetregtroup,"treeview_ltrp");
aff=lookup_widget(Fenetregtroup,"scrolledwindow_gtrp");
liste=lookup_widget(Fenetregtroup,"label_ltrp");

gtk_widget_show (liste);
gtk_widget_show (aff);
affichertrp(treeview_ltrp);
}


void
on_treeview_lcapdef_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
        GtkTreeIter iter;
	gchar* identifiant;
	gchar* zone;
	gchar* type;
	gchar* marque;
	gchar* etat_fct;
	gchar* jour_fct;
        gchar* mois_fct;
        gchar* annee_fct;

	capteur n;
        FILE *f=NULL;
        
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter ,path))
	{
		
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &identifiant, 1, &zone, 2, &type , 3, &marque, 4, &etat_fct, 5, &jour_fct , 6, &mois_fct , 7, &annee_fct , -1);
  		strcpy(n.idcapteur,identifiant);
		strcpy(n.zone_ajout,zone);
		strcpy(n.type,type);
                strcpy(n.marque,marque);
		strcpy(n.etat_fonctionnement,etat_fct);
                n.date_mise_fct.jour=jour_fct;
                n.date_mise_fct.mois=mois_fct;
                n.date_mise_fct.annee=annee_fct;
                
                
                affichercap(treeview);
                
}
}


void
on_button_ouispfctcap_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrefctcap;
    GtkWidget *Fenetresp;
   GtkWidget *id,*aff;
GtkWidget *output1,*output2,*output3;

    Fenetresp=lookup_widget(objet,"chspfctcap");
    gtk_widget_destroy(Fenetresp);
    Fenetrefctcap=create_fctcap();
    gtk_widget_show(Fenetrefctcap);


id=lookup_widget(Fenetrefctcap,"combobox_idfct");
output1=lookup_widget(Fenetrefctcap,"label_msajfct");
output2=lookup_widget(Fenetrefctcap,"label_msmdffct");
output3=lookup_widget(Fenetrefctcap,"label_msspfct");
aff=lookup_widget(Fenetrefctcap,"scrolledwindow_fctcap");
if(g==1)
{
supprimertmp(idcap);
gtk_widget_show (output3);
}
else
if(g==2)
{
supprimerhmd(idcap);
gtk_widget_show (output3);
}
gtk_widget_hide (output1);
gtk_widget_hide (output2);
gtk_widget_hide (aff);
}


void
on_button_nonspfctcap_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetrefctcap;
    GtkWidget *Fenetresp;
    Fenetresp=lookup_widget(objet,"chspfctcap");
    gtk_widget_destroy(Fenetresp);
    Fenetrefctcap=create_fctcap();
    gtk_widget_show(Fenetrefctcap);

}


void
on_button_ouispabsouv_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetreabsouv;
    GtkWidget *Fenetresp;
   GtkWidget *id,*aff;
GtkWidget *output1,*output2,*output3,*output4;

    Fenetresp=lookup_widget(objet,"chspabsouv");
    gtk_widget_destroy(Fenetresp);
    Fenetreabsouv=create_absouv();
    gtk_widget_show(Fenetreabsouv);
id=lookup_widget(Fenetreabsouv,"combobox_mbidabs");
output1=lookup_widget(Fenetreabsouv,"label_mbscajabs");
output2=lookup_widget(Fenetreabsouv,"label_mbscmdfabs");
output3=lookup_widget(Fenetreabsouv,"label_mbscspabs");
output4=lookup_widget(Fenetreabsouv,"label_mbvrdate");
aff=lookup_widget(Fenetreabsouv,"scrolledwindow_tabsouv");

supprimerabs(idouv);

gtk_widget_show (output3);
gtk_widget_hide (output1);
gtk_widget_hide (output2);
gtk_widget_hide (output4);
gtk_widget_hide (aff);
}


void
on_button_nonspabsouv_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
    GtkWidget *Fenetreabsouv;
    GtkWidget *Fenetresp;
    Fenetresp=lookup_widget(objet,"chspabsouv");
    gtk_widget_destroy(Fenetresp);
    Fenetreabsouv=create_absouv();
    gtk_widget_show(Fenetreabsouv);
}

