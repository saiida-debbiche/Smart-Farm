#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "absentisme.h"
#include <gtk/gtk.h>
#include "ouvrier.h"

enum
{
    EIDENTIFIANT,
    EJ,
    EM,
    EA,
    EABS,
    
    COLUMNS,
};


void absentisme(ouv n)
{
 FILE *f;
 f=fopen("tableau_absentisme.txt","a+");
 if(f!=NULL)
 {
   fprintf(f,"%s %d %d %d %d \n",n.identifiant,n.date_abs.jour,n.date_abs.mois,n.date_abs.annee,n.abs);
fclose(f);
}
}

void modifierabs(ouv n)
{
char id1[20];
int abs1;
    int jda;
    int mda;
    int ada;
    	

FILE *f;
FILE *f1;

f=fopen("tableau_absentisme.txt","r");
f1=fopen("modif.txt","a+");
while (fscanf(f,"%s %d %d %d %d \n",id1,&jda,&mda,&ada,&abs1)!=EOF)
{
if ((strcmp(n.identifiant,id1)==0)&&(n.date_abs.jour==jda)&&(n.date_abs.mois==mda)&&(n.date_abs.annee==ada)==0)
	fprintf(f1,"%s %d %d %d %d\n",n.identifiant,n.date_abs.jour,n.date_abs.mois,n.date_abs.annee,n.abs);

else
	fprintf(f1,"%s %d %d %d %d\n",id1,jda,mda,ada,abs1);

}
fclose(f);
fclose(f1);
remove("tableau_absentisme.txt");
rename("modif.txt","tableau_absentisme.txt");
}

void rechabs(GtkWidget *liste, char id[], char moisabs[], char anneeabs[])
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char jour[20];
char mois[20];
char annee[20];
char abs[20];

store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("abs",renderer,"text",EABS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("tableau_absentisme.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("tableau_absentisme.txt","a+");
		while(fscanf(f,"%s %s %s %s %s \n",identifiant,jour,mois,annee,abs)!=EOF)
		{
   if(strcmp(identifiant,id)==0&&strcmp(mois,moisabs)==0&&strcmp(annee,anneeabs)==0)
{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,EJ,jour,EM,mois,EA,annee,EABS,abs,-1);
}
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	   }
}

}

void afficherabs(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char identifiant[20];
char jour[20];
char mois[20];
char annee[20];
char abs[20];

store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",EIDENTIFIANT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EA,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

renderer=gtk_cell_renderer_text_new();                column=gtk_tree_view_column_new_with_attributes("abs",renderer,"text",EABS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("tableau_absentisme.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("tableau_absentisme.txt","a+");
		while(fscanf(f,"%s %s %s %s %s \n",identifiant,jour,mois,annee,abs)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,EIDENTIFIANT,identifiant,EJ,jour,EM,mois,EA,annee,EABS,abs,-1);

		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
	   }
}

}

void supprimerabs(char idsp[])
{
FILE *f;
FILE *f1;
ouv n;
f=fopen("tableau_absentisme.txt","r");
f1=fopen("doc.txt","a+");
while (fscanf(f,"%s %d %d %d %d \n",n.identifiant,&n.date_abs.jour,&n.date_abs.mois,&n.date_abs.annee,&n.abs)!=EOF)
{
	if (strcmp(n.identifiant,idsp)!=0)	
	fprintf(f1,"%s %d %d %d %d\n",n.identifiant,n.date_abs.jour,n.date_abs.mois,n.date_abs.annee,n.abs);

}
fclose(f);
fclose(f1);
remove("tableau_absentisme.txt");
rename("doc.txt","tableau_absentisme.txt");
}

int verifdate(char idabs[], int j, int m, int a)
{
    
    FILE *f=NULL;
ouv n;
    int test;
    f=fopen("tableau_absentisme.txt","r");
    test=0;
    if(f!=NULL)
    {
 while (fscanf(f,"%s %d %d %d %d \n",n.identifiant,&n.date_abs.jour,&n.date_abs.mois,&n.date_abs.annee,&n.abs)!=EOF)
       {
         if((strcmp(n.identifiant,idabs)==0)&&(n.date_abs.jour==j)&&(n.date_abs.mois==m)&&(n.date_abs.annee==a))
        {
          test=1;
          break;
        }

       }
     fclose(f);
     }
return(test);
}

void taux(float T[],int annee,int nb,char *fichier)
{
float tab[50];
int j,m,a,id,val,i;
FILE *f;
nb=valeur(fichier);
    for (i=1;i<13;i++)
{
	T[i]=0;
	tab[i]=0;
}
f=fopen(fichier,"r");
if (f != NULL)
{
while(fscanf(f,"%d %d %d %d %d",&id,&j,&m,&a,&val)!=EOF)
{ 
if(a==annee && val==0)
{
for(i=1;i<13;i++)
{
if(m==i)
tab[i]++;
}
}  
}
}
for(i=1;i<13;i++)
T[i]=(tab[i]/(30*nb))*100;
fclose(f);
}

int valeur(char *fichier)
{
    int t=0;
    FILE *f;
    int j,m,a,id;
char nom[20];
char prenom[20];
char sexe[20];
char ss[20];
char tache[30];
    f=fopen(fichier,"r");
    if(f!=NULL)
    {
        while(fscanf(f,"%d %s %s %s %s %s %d %d %d\n",&id,nom,prenom,sexe,ss,tache,&j,&m,&a)!=EOF){

            t++;
        }
    }
    fclose(f);
    return t;
}

int valeur_min(int tab[],int n)
{
    int i,pos=0;
    int min;
    min=tab[0];
    for(i=1;i<n;i++)
    {
        if(tab[i]<min)
           { min=tab[i];
           pos=i;}
    }
    return pos;

}

int meilleur_ouv(int tab_id[],int tab_abs[],int annee)
{ int i;
FILE *f;
    int id,j,m,a,n,v;
    int test,k=0;
    f=fopen("tableau_absentisme.txt","r");
    if(f!=NULL)
	{fscanf(f,"%d %d %d %d %d \n",&id,&j,&m,&a,&v);
    tab_id[0]=id;
    i=1;
        while(fscanf(f,"%d %d %d %d %d \n",&id,&j,&m,&a,&v)!=EOF)
           {test=1;
        for(k=0;k<i;k++)
    {if(tab_id[k]==id)
    {test=0;
    break;}}
if(test)
 {tab_id[i]=id;
          i++;}
           }


n=i;
rewind(f);
    while(fscanf(f,"%d %d %d %d %d \n",&id,&j,&m,&a,&v)!=EOF)
{
    for(i=0;i<n;i++)
    {if(tab_id[i]==id&&v==0&&annee==a)
        tab_abs[i]++;}
}
}

return n;
}



