#include <gtk/gtk.h>
typedef struct
{
   int jour;
   int mois;
   int annee;
}dt;

typedef struct
{
    char idcapteur[20];
    char zone_ajout[20];
    char type[20];
    char marque[20];
    dt date_mise_fct;
    char etat_fonctionnement[20];
}capteur;


void ajoutercap(capteur c);
void affichercap(GtkWidget *liste);
void supprimercap(char idsp[]);
void modifiercap(capteur c);
void cherchercap(GtkWidget *liste, char marquedef[]);
int verifcap(char id[]);
void filtrecriterecap(GtkWidget *liste, char critere[], char filtre[]);
void supprimertreecap(capteur c1);
int verifrechcap(char crt[]);


